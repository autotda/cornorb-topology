# GitHub Repository Metadata

## Description

The following description is 348 characters, including spaces:

> Research code for keratoconus detection from rendered corneal topography using cubical persistent homology, multi-view ConvNeXt-Transformer fusion, clinical features, strict patient-level cross-validation, extreme stress testing, mask/crop sensitivity analysis, and representative topology localization. Built for transparent research reproduction.

## Suggested Topics

`keratoconus`, `corneal-topography`, `persistent-homology`, `topological-data-analysis`, `medical-imaging`, `multimodal-learning`, `pytorch`, `giotto-tda`, `robustness`, `explainable-ai`

## License Boundary

The MIT License covers only the code and repository documentation authored for this project. It does not relicense CornOrb, the Kaggle dataset, pretrained model weights, journal templates, or third-party software. Users must follow each external resource's original terms.
