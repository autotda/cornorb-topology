# Protocol and Interpretation Boundaries

## CornOrb Cohort

The original preparation workflow uses the image inventory as the canonical eye-level manifest, normalizes the known scientific-notation patient-code anomaly, aggregates repeated clinical records using numeric medians and categorical modes, and retains duplicate/conflict audit columns.

The completed local preparation produced 1407 eyes from 744 patients: 1195 eyes/632 patients in development and 212 eyes/112 patients in the locked audit cohort. These are historical observations, not hard-coded requirements for arbitrary datasets.

Patients, not eyes, are the splitting unit. The default development protocol is three repeated five-fold outer CV with four inner folds within each outer-training subset. `validate-splits` checks identity/label consistency, eye and patient isolation, partition coverage, and exactly-once validation coverage within each repeat and inner CV.

The locked cohort must not guide feature selection, hyperparameters, epoch selection, thresholds or narrative-driven model selection. Its evaluation requires parameters/epochs fixed from development-side work. The image runner requires `--locked-selected-epoch` under nested selection; TDA locked evaluation requires fixed `--locked-C` and `--locked-l1-ratio`.

## Model and Selection

The deep model uses a shared ConvNeXt-Tiny encoder, view embeddings and a Transformer fusion block. Clinical and TDA features are encoded as optional tokens. Clinical-only and TDA-only classifiers are regularized logistic regression baselines.

Use `--selection-policy nested_inner_cv` for formal image experiments. The low-level historical `RunnerConfig` default remains `legacy_outer_valid` for source compatibility; direct API users must explicitly set the nested policy. The public train/ablation CLI and supplied primary preset use nested selection. Legacy outer-validation-based epoch selection is not the formal protocol.

`seed_everything` seeds Python, NumPy and PyTorch but enables cuDNN benchmarking. This implementation does not promise bitwise determinism across hardware, drivers or library versions. Checkpoint resume logic can skip completed work; always use a fresh output root when configuration changes, otherwise old results may be mistaken for new ones.

## TDA Preprocessing Audit

Per-image preprocessing uses a central crop, resize, corneal circular mask, luminance-rank scalarization, radial-median baseline subtraction and view-dependent positive/negative anomaly fields. Filtrations represent software-rendered-map intensity structure, not raw physical elevation/thickness matrices.

**Historical CornOrb extraction:** `_vectorize_diagrams` in `orbscan_experiment/tda.py` calls `fit_transform` for vectorizers on the extraction batch. Betti/persistence-image grids and some amplitude representations can therefore depend on diagrams outside an individual training fold, even without labels. Train-fold tabular scaling alone does not resolve this. The mask/crop extractor uses the same helper.

This release deliberately preserves that implementation and the completed experiments. Do not describe it as fully fold-fitted preprocessing. A strictly inductive extension should compute/cache sample diagrams, fit data-dependent diagram vectorizers only on each inner/outer training partition, and transform validation/locked diagrams with those fitted vectorizers. Such an extension changes the experiment and requires separate reruns and result reporting.

**Kaggle extraction:** the separate extractor has an explicit `fit_split_csv` and fits vectorizers on the specified training source, then transforms other cases. Do not substitute the entire manifest as that fit source.

The mask/crop analysis is a sensitivity experiment, not proof that numbers, grid lines, color conventions or other software overlays have no influence. Clinical variables such as Kmax, pachymetry and asphericity can also be diagnostic proxies; interpret the clinical-only model accordingly.

## Stress Testing

The primary stress runner enumerates the default 15 outer folds and consumes clean-fold histories/checkpoints. Families include training-set pressure, image degradation, missing views, clinical-feature perturbation, TDA-feature perturbation and combined stress. Historical fixed-split workflows remain under `workflows/legacy`; they are not interchangeable with strict-CV stress results.

Task counts depend on model/family eligibility and filtering. Clean reference rows and stressed task rows are distinct: do not label their combined count as the number of stress-only tasks.

`metrics-only` limits persistence, not temporary disk requirements. Canonical task results support resumption. A completed progress counter or an ETA display is not itself evidence that all intended model-condition comparisons were run: inspect the task inventory and summaries.

In some branch-specific stress tests, other modalities intentionally remain intact. Include image-only, image-clinical, image-TDA and the complete model for attribution where applicable. Robustness of the complete model under image degradation alone cannot be attributed entirely to TDA.

## Representatives

HomCloud H1 localization uses library `optimal_1_cycle` and, where feasible, `optimal_volume`. H0 localization uses birth/death positions plus a thresholded connected component: it is not a library-optimized H0 cycle. The GUDHI workflow is historical birth/death-based localization, not a claim that GUDHI optimizes representative cycles here.

Representative extraction over the full cohort is descriptive, not training or model selection. Anatomical interpretation of rendered-map structures needs additional clinical validation. Specified representative IDs refer to anonymized public records; provide explicit `--sample-ids` or use HomCloud `--all-samples`.

## Statistics

The historical summary uses population standard deviation (`ddof=0`), bootstrap intervals of fold-mean metrics, and matched-fold Wilcoxon tests with Holm adjustment. Repeated-CV folds share patients and training data and are not independent replicates. Treat fold-based intervals and p-values as descriptive/exploratory, not independent-sample clinical evidence. No new patient-clustered inference has been added by this structural refactor.

## Kaggle Replication

This workflow trains/selects on the Kaggle train/validation source and tests on its independent source; CornOrb-trained models are not transferred. Suspect labels are not established binary positives and score distributions are not progression outcomes or calibrated clinical risks. Actual patient grouping cannot be inferred solely from case-directory identifiers.
