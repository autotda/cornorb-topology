# Environment Notes

The original workstation environment was not modified during the repository refactor. The following installed distribution versions were observed on 2026-09-17:

| Distribution | Observed version |
| --- | --- |
| Python (Conda metadata) | 3.12.11 |
| torch | 2.9.0+cu128 |
| torchvision | 0.24.0+cu128 |
| numpy | 2.4.3 |
| pandas | 2.3.3 |
| scipy | 1.16.3 |
| scikit-learn | 1.4.2 |
| matplotlib | 3.10.6 |
| openpyxl | 3.1.5 |
| giotto-tda | 0.6.2 |
| gudhi | 3.11.0 |
| homcloud | 5.3.0 |

These are installed-package observations, not proof of the versions used for every historical run. Do not relabel this as a complete experiment lockfile. The companion requirements observation file is for provenance only.

giotto-tda 0.6.2 declares scikit-learn==1.3.2, whereas the observed workstation has 1.4.2. The release therefore specifies 1.3.2 and conservatively constrains NumPy to 1.x for a new environment. This does not change the existing workstation or historical outputs, and the newly constrained environment still needs a full clean-install test.

The original TDA module contains a NumPy `product` compatibility alias. It is retained, but an alias is not a general compatibility guarantee for the complete scientific stack.

Install the correct PyTorch/torchvision combination for the intended device. Different CUDA builds, BLAS implementations, compilers and optimization solvers can affect runtime and numerical results. HomCloud representative routines may have additional solver/platform requirements.

Use `cornorb doctor` to print actual versions and dependency warnings. The command does not install or upgrade packages. Preserve each completed run's configuration/history alongside its results and record Python, package, hardware and driver versions for future runs.
