# Migration Map

This publication directory is separate from the working experiment directory. The original entry scripts, manifests, manuscript and formal run outputs remain in place.

The eight original `orbscan_experiment/*.py` files were copied to `src/orbscan_experiment/` without numerical changes. The original import name is retained so dataset/model/training code and checkpoint configuration references remain recognizable.

| Original entry script | New workflow under `src/cornorb_topology/workflows/` | CLI command |
| --- | --- | --- |
| prepare_experiment_manifests.py | data/prepare_cornorb.py | prepare-cornorb |
| prepare_kaggle_external.py | data/prepare_kaggle.py | prepare-kaggle |
| run_cubical_tda.py | features/extract_cubical.py | extract-tda |
| run_kaggle_cubical_tda.py | features/extract_kaggle.py | extract-kaggle-tda |
| run_strict_cv.py | training/strict_cv.py | train |
| run_clinical_strict_cv.py | training/clinical_cv.py | clinical-cv |
| run_tda_strict_cv.py | training/tda_cv.py | tda-cv |
| run_ablation_suite.py | training/ablations.py | ablations |
| run_clinical_lite_baseline.py | training/clinical_lite.py | clinical-lite |
| run_kaggle_external_validation.py | training/kaggle_replication.py | kaggle-replication |
| run_strict_cv_stress_suite.py | stress/strict_cv.py | stress-cv |
| report_extreme_stress_progress.py | stress/progress.py | legacy-stress-progress |
| run_ablation_statistics.py | analysis/ablation_statistics.py | statistics |
| build_strict_cv_total_big_table.py | analysis/stress_tables.py | stress-tables |
| run_homcloud_representatives.py | interpretability/homcloud.py | representatives |
| run_gudhi_representatives.py | interpretability/gudhi.py | gudhi-localization |
| run_tda_overlay_sensitivity.py | sensitivity/mask_crop.py | mask-crop |
| run_extreme_stress_suite.py | legacy/extreme_stress.py | legacy-extreme-stress |
| run_stress_benchmark.py | legacy/stress_benchmark.py | legacy-stress |
| build_total_summary_tables.py | legacy/stress_tables.py | legacy-stress-tables |

## Intentional Portability Changes

- CornOrb preparation takes dataset/workspace/image/CSV paths and split parameters through CLI arguments instead of workstation-specific constants.
- CornOrb preparation checks paths and refuses to overwrite existing manifest/split definitions.
- Kaggle preparation requires an explicit local dataset path instead of a personal Downloads directory.
- Two Kaggle imports now point to the packaged data workflow.
- New lazy CLI and JSON presets do not change the original training/extraction routines. Presets are starting examples, not recovered configurations for all paper runs.
- Public defaults use `kaggle_replication` and `suspect_score` terminology. To inspect historical outputs that used `external_validation` or `suspect_risk` names, pass those paths explicitly; the original formal result directory is unchanged.

Document/Word generation scripts, manuscript drafts, third-party publisher templates, downloaded papers and private experiment artifacts were intentionally excluded.
