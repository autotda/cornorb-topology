# Verification Record

Verification performed during repository preparation on 2026-09-17:

- The dependency-free unit suite passed 21 tests covering CLI behavior, source layout, portable example presets, duplicate identities, fellow-eye leakage, locked-cohort isolation, binary labels and nested partition coverage.
- `validate-splits` passed against the existing formal split tree: 1195 development eyes from 632 patients, 212 locked eyes from 112 patients, 15 outer partitions and 60 inner partitions.
- Scientific integration tests passed on synthetic data in the existing `togcn` environment: four-view Dataset loading, clinical/TDA tensor construction, Orbscan filtration, giotto-tda cubical persistence, ConvNeXt-Tiny multimodal forward pass without pretrained weights, and metric computation.
- Every registered workflow module imported in the existing scientific environment.
- A wheel was built without resolving dependencies, installed into a temporary target and its package CLI was invoked successfully.
- The release tree was scanned for absolute Windows path literals and excluded data/checkpoint/archive extensions.
- `.gitignore` behavior was checked with representative dataset, split, checkpoint, result, environment and manuscript paths.

These checks establish packaging and interface integrity. They do not establish a clean dependency install, bitwise reproducibility, complete retraining, equivalence to every historical run, or clinical validity. See `ENVIRONMENT.md` and `PROTOCOL.md`.
