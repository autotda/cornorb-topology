# Release Checklist

## Prepared

- [x] Separate publication directory; working experiments and formal results preserved.
- [x] Source organized into package and staged workflow modules.
- [x] Portable CLI, JSON examples and installation metadata.
- [x] Patient split audit, synthetic contract tests and CI workflow.
- [x] Data/artifact/credential exclusions in `.gitignore`.
- [x] Scientific claim boundaries and historical dependency mismatch documented.
- [x] Software citation metadata without invented DOI or acceptance claims.
- [x] MIT License added for project-authored code and documentation; dataset and third-party terms remain separate.

## Before Public Upload

- [ ] All authors approve public code release and software attribution.
- [ ] Review source/documents for secrets, institutional identifiers or unintended patient-level information.
- [ ] Test a clean installation in the chosen CPU/CUDA environment and record a supported dependency lockfile.
- [ ] Decide whether the historical transductive CornOrb diagram-vectorizer fitting remains a disclosed limitation or requires new fold-fitted experiments.
- [ ] Review correspondence between the manuscript's strict-preprocessing claims and `docs/PROTOCOL.md`.
- [ ] Confirm dataset license/citation requirements without redistributing datasets.
- [ ] If releasing selected aggregate results, curate them explicitly and remove patient-level rows, local paths and predictions. They are not automatically included here.

## Upload Scope

Upload the **contents of this directory**, not the parent experiment workspace. Do not upload `runs`, `experiment_setup`, downloaded datasets, Conda environments, manuscripts, checkpoint files or cache directories.

This preparation has not created a remote GitHub repository, committed changes or pushed anything. Add a remote only after choosing the account/repository and reviewing the release contents. Do not embed access tokens in code, commands saved to the repository or configuration files.

The generated code-only ZIP is a convenient transfer artifact, not a GitHub Release or evidence of license approval. Basic tests and local integration checks do not replace a full clean-environment scientific reproduction.
