"""Orbscan experiment utilities for strict patient-level CV."""
