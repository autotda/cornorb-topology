from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from gtda.diagrams import Amplitude, BettiCurve, NumberOfPoints, PersistenceEntropy, PersistenceImage
from gtda.homology import CubicalPersistence
from PIL import Image

if not hasattr(np, "product"):
    np.product = np.prod


DEFAULT_TDA_VIEWS = ("anterior", "posterior", "axial", "pachymetry")
POSITIVE_ANOMALY_VIEWS = {"anterior", "posterior", "axial"}
NEGATIVE_ANOMALY_VIEWS = {"pachymetry"}
IMAGE_PATH_COLUMNS = {view: f"image_{view}_path" for view in DEFAULT_TDA_VIEWS}


@dataclass
class CubicalTDAConfig:
    project_dir: str = "."
    metadata_csv: str = "experiment_setup/metadata_clean.csv"
    output_dir: str = "runs/cubical_tda_v1"
    views: tuple[str, ...] = DEFAULT_TDA_VIEWS
    image_size: int = 192
    crop_ratio: float = 0.84
    mask_radius_ratio: float = 0.48
    radial_bins: int = 64
    anomaly_clip_quantile: float = 0.995
    scalarization: str = "luminance_rank"
    align_left_right: bool = True
    homology_dimensions: tuple[int, ...] = (0, 1)
    coeff: int = 2
    reduced_homology: bool = True
    n_jobs: int | None = None
    betti_bins: int = 32
    persistence_image_bins: int = 16
    persistence_image_sigma: float = 0.05
    top_k_lifetimes: int = 3
    debug_samples: int = 8
    sample_limit: int | None = None


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _rank_normalize(values: np.ndarray) -> np.ndarray:
    if values.size == 0:
        return values.astype(np.float32)
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float32)
    if values.size == 1:
        ranks[order] = 0.0
    else:
        ranks[order] = np.linspace(0.0, 1.0, num=values.size, dtype=np.float32)
    return ranks


def _center_crop(image: np.ndarray, crop_ratio: float) -> np.ndarray:
    height, width = image.shape[:2]
    side = int(round(min(height, width) * crop_ratio))
    side = max(8, min(side, min(height, width)))
    top = (height - side) // 2
    left = (width - side) // 2
    return image[top : top + side, left : left + side]


def _resize_rgb(image: np.ndarray, image_size: int) -> np.ndarray:
    pil = Image.fromarray(image.astype(np.uint8), mode="RGB")
    pil = pil.resize((image_size, image_size), resample=Image.Resampling.BICUBIC)
    return np.asarray(pil, dtype=np.uint8)


def _corneal_mask(image_size: int, radius_ratio: float) -> np.ndarray:
    yy, xx = np.mgrid[:image_size, :image_size]
    cy = (image_size - 1) / 2.0
    cx = (image_size - 1) / 2.0
    radius = radius_ratio * image_size
    mask = (yy - cy) ** 2 + (xx - cx) ** 2 <= radius**2
    return mask


def _rgb_to_scalar(rgb: np.ndarray, mask: np.ndarray, scalarization: str) -> np.ndarray:
    rgb_float = rgb.astype(np.float32) / 255.0
    if scalarization in {"luminance", "luminance_rank"}:
        scalar = 0.2126 * rgb_float[..., 0] + 0.7152 * rgb_float[..., 1] + 0.0722 * rgb_float[..., 2]
    elif scalarization == "value_rank":
        scalar = rgb_float.max(axis=-1)
    else:
        raise ValueError(f"Unsupported scalarization: {scalarization}")

    scalar = scalar.astype(np.float32)
    if scalarization.endswith("_rank"):
        ranked = np.zeros_like(scalar, dtype=np.float32)
        ranked_values = _rank_normalize(scalar[mask])
        ranked[mask] = ranked_values
        scalar = ranked
    return scalar


def _radial_baseline(scalar: np.ndarray, mask: np.ndarray, radial_bins: int) -> tuple[np.ndarray, np.ndarray]:
    image_size = scalar.shape[0]
    yy, xx = np.mgrid[:image_size, :image_size]
    cy = (image_size - 1) / 2.0
    cx = (image_size - 1) / 2.0
    radius = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    max_radius = float(radius[mask].max()) if np.any(mask) else 1.0
    radius_norm = radius / max(max_radius, 1e-6)

    bin_edges = np.linspace(0.0, 1.0, num=radial_bins + 1, dtype=np.float32)
    centers: list[float] = []
    medians: list[float] = []
    for index in range(radial_bins):
        lower = bin_edges[index]
        upper = bin_edges[index + 1]
        if index == radial_bins - 1:
            bin_mask = mask & (radius_norm >= lower) & (radius_norm <= upper)
        else:
            bin_mask = mask & (radius_norm >= lower) & (radius_norm < upper)
        if not np.any(bin_mask):
            continue
        centers.append(float((lower + upper) / 2.0))
        medians.append(float(np.median(scalar[bin_mask])))

    if not centers:
        baseline = np.full_like(scalar, fill_value=float(np.median(scalar[mask])) if np.any(mask) else 0.0, dtype=np.float32)
        return baseline, radius_norm.astype(np.float32)

    baseline = np.interp(
        radius_norm.reshape(-1),
        np.asarray(centers, dtype=np.float32),
        np.asarray(medians, dtype=np.float32),
        left=medians[0],
        right=medians[-1],
    ).reshape(scalar.shape)
    return baseline.astype(np.float32), radius_norm.astype(np.float32)


def _robust_unit_interval(values: np.ndarray, mask: np.ndarray, high_quantile: float) -> np.ndarray:
    normalized = np.zeros_like(values, dtype=np.float32)
    if not np.any(mask):
        return normalized
    high = float(np.quantile(values[mask], high_quantile))
    if high <= 1e-8:
        return normalized
    normalized[mask] = np.clip(values[mask] / high, 0.0, 1.0)
    return normalized


def prepare_orbscan_filtration(
    image_path: str | Path,
    *,
    view: str,
    eye: str,
    config: CubicalTDAConfig,
) -> dict[str, np.ndarray]:
    with Image.open(image_path) as image:
        rgb = np.asarray(image.convert("RGB"), dtype=np.uint8)

    if config.align_left_right and str(eye).upper() == "OS":
        rgb = np.ascontiguousarray(np.fliplr(rgb))

    rgb = _center_crop(rgb, crop_ratio=config.crop_ratio)
    rgb = _resize_rgb(rgb, image_size=config.image_size)
    mask = _corneal_mask(image_size=config.image_size, radius_ratio=config.mask_radius_ratio)
    scalar = _rgb_to_scalar(rgb, mask=mask, scalarization=config.scalarization)
    baseline, radius_norm = _radial_baseline(scalar=scalar, mask=mask, radial_bins=config.radial_bins)
    residual = scalar - baseline

    if view in NEGATIVE_ANOMALY_VIEWS:
        anomaly = np.clip(-residual, a_min=0.0, a_max=None)
    elif view in POSITIVE_ANOMALY_VIEWS:
        anomaly = np.clip(residual, a_min=0.0, a_max=None)
    else:
        raise ValueError(f"Unknown Orbscan view: {view}")

    anomaly_norm = _robust_unit_interval(anomaly, mask=mask, high_quantile=config.anomaly_clip_quantile)
    filtration = np.full_like(anomaly_norm, fill_value=1.05, dtype=np.float32)
    filtration[mask] = 1.0 - anomaly_norm[mask]

    return {
        "rgb": rgb,
        "mask": mask.astype(np.float32),
        "scalar": scalar.astype(np.float32),
        "baseline": baseline.astype(np.float32),
        "radius_norm": radius_norm.astype(np.float32),
        "residual": residual.astype(np.float32),
        "anomaly": anomaly.astype(np.float32),
        "filtration": filtration.astype(np.float32),
    }


def _save_debug_image(array: np.ndarray, output_path: Path) -> None:
    data = np.asarray(array, dtype=np.float32)
    data = data - float(data.min())
    denom = float(data.max()) if float(data.max()) > 0 else 1.0
    image = (255.0 * data / denom).clip(0, 255).astype(np.uint8)
    Image.fromarray(image, mode="L").save(output_path)


def _save_debug_bundle(sample_id: str, view: str, arrays: dict[str, np.ndarray], output_dir: Path) -> None:
    debug_dir = output_dir / "debug" / sample_id
    _ensure_dir(debug_dir)
    Image.fromarray(arrays["rgb"], mode="RGB").save(debug_dir / f"{view}_rgb.png")
    _save_debug_image(arrays["mask"], debug_dir / f"{view}_mask.png")
    _save_debug_image(arrays["scalar"], debug_dir / f"{view}_scalar.png")
    _save_debug_image(arrays["baseline"], debug_dir / f"{view}_baseline.png")
    _save_debug_image(arrays["residual"], debug_dir / f"{view}_residual.png")
    _save_debug_image(arrays["anomaly"], debug_dir / f"{view}_anomaly.png")
    _save_debug_image(arrays["filtration"], debug_dir / f"{view}_filtration.png")


def _diagram_summary_features(diagrams: np.ndarray, homology_dimensions: tuple[int, ...], top_k: int) -> pd.DataFrame:
    rows: list[dict[str, float]] = []
    for diagram in diagrams:
        features: dict[str, float] = {}
        for dimension in homology_dimensions:
            points = diagram[diagram[:, 2] == dimension]
            lifetimes = points[:, 1] - points[:, 0]
            finite = lifetimes[np.isfinite(lifetimes)]
            finite = finite[finite > 0]
            finite = np.sort(finite)[::-1]
            features[f"h{dimension}_count"] = float(finite.size)
            features[f"h{dimension}_total_persistence"] = float(finite.sum()) if finite.size else 0.0
            features[f"h{dimension}_max_lifetime"] = float(finite[0]) if finite.size else 0.0
            features[f"h{dimension}_mean_lifetime"] = float(finite.mean()) if finite.size else 0.0
            for rank in range(top_k):
                value = float(finite[rank]) if rank < finite.size else 0.0
                features[f"h{dimension}_top{rank + 1}_lifetime"] = value
        rows.append(features)
    return pd.DataFrame(rows)


def _flatten_features(
    values: np.ndarray,
    *,
    prefix: str,
    homology_dimensions: tuple[int, ...],
) -> tuple[np.ndarray, list[str]]:
    values = np.asarray(values)
    num_samples = values.shape[0]
    tail_shape = values.shape[1:]
    flat = values.reshape(num_samples, -1)
    columns: list[str] = []

    if tail_shape and tail_shape[0] == len(homology_dimensions):
        if len(tail_shape) == 1:
            columns = [f"{prefix}_h{dimension}" for dimension in homology_dimensions]
        else:
            for dim_index, dimension in enumerate(homology_dimensions):
                for idx in np.ndindex(*tail_shape[1:]):
                    suffix = "_".join(f"{part:02d}" for part in idx)
                    columns.append(f"{prefix}_h{dimension}_{suffix}")
    else:
        columns = [f"{prefix}_{index:04d}" for index in range(flat.shape[1])]
    return flat, columns


def _vectorize_diagrams(
    diagrams: np.ndarray,
    *,
    prefix: str,
    homology_dimensions: tuple[int, ...],
    betti_bins: int,
    persistence_image_bins: int,
    persistence_image_sigma: float,
    top_k_lifetimes: int,
) -> pd.DataFrame:
    feature_frames: list[pd.DataFrame] = []

    summary_df = _diagram_summary_features(
        diagrams,
        homology_dimensions=homology_dimensions,
        top_k=top_k_lifetimes,
    ).add_prefix(f"{prefix}_summary_")
    feature_frames.append(summary_df)

    vectorizers: list[tuple[str, Any]] = [
        ("entropy", PersistenceEntropy(normalize=True)),
        ("num_points", NumberOfPoints()),
        ("amplitude_bottleneck", Amplitude(metric="bottleneck")),
        ("amplitude_wasserstein", Amplitude(metric="wasserstein", metric_params={"p": 2})),
        ("amplitude_landscape", Amplitude(metric="landscape")),
        ("betti", BettiCurve(n_bins=betti_bins)),
        (
            "pimg",
            PersistenceImage(
                sigma=persistence_image_sigma,
                n_bins=persistence_image_bins,
            ),
        ),
    ]

    for name, vectorizer in vectorizers:
        transformed = vectorizer.fit_transform(diagrams)
        flat, columns = _flatten_features(
            transformed,
            prefix=f"{prefix}_{name}",
            homology_dimensions=homology_dimensions,
        )
        feature_frames.append(pd.DataFrame(flat, columns=columns))

    return pd.concat(feature_frames, axis=1)


def _base_feature_frame(metadata: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "patient_eye_id",
        "patient_code",
        "eye",
        "label",
        "label_text",
        "gender",
        "age_years",
        "kmax_value_D",
        "pachy_thinnest_um",
        "had_duplicate_rows",
        "had_conflicting_clinical_values",
    ]
    keep = [column for column in columns if column in metadata.columns]
    return metadata[keep].reset_index(drop=True).copy()


def _prepare_metadata(config: CubicalTDAConfig) -> pd.DataFrame:
    metadata_path = Path(config.project_dir) / config.metadata_csv
    metadata = pd.read_csv(metadata_path)
    if config.sample_limit is not None and config.sample_limit > 0:
        metadata = metadata.head(config.sample_limit).copy()
    return metadata.reset_index(drop=True)


def run_cubical_tda_extraction(config: CubicalTDAConfig) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    output_dir = project_dir / config.output_dir
    _ensure_dir(output_dir)

    metadata = _prepare_metadata(config)
    base_features = _base_feature_frame(metadata)
    debug_limit = min(config.debug_samples, len(metadata))

    filtration_store: dict[str, list[np.ndarray]] = {view: [] for view in config.views}
    for row_index, row in metadata.iterrows():
        sample_id = str(row["patient_eye_id"])
        eye = str(row["eye"])
        for view in config.views:
            image_path = row[IMAGE_PATH_COLUMNS[view]]
            arrays = prepare_orbscan_filtration(
                image_path=image_path,
                view=view,
                eye=eye,
                config=config,
            )
            filtration_store[view].append(arrays["filtration"])
            if row_index < debug_limit:
                _save_debug_bundle(sample_id=sample_id, view=view, arrays=arrays, output_dir=output_dir)

    combined_features = [base_features]
    cubical = CubicalPersistence(
        homology_dimensions=config.homology_dimensions,
        coeff=config.coeff,
        reduced_homology=config.reduced_homology,
        n_jobs=config.n_jobs,
    )

    modality_report: dict[str, Any] = {}
    for view in config.views:
        filtrations = np.stack(filtration_store[view], axis=0).astype(np.float32)
        diagrams = cubical.fit_transform(filtrations)
        np.save(output_dir / f"filtrations_{view}.npy", filtrations)
        np.save(output_dir / f"diagrams_{view}.npy", diagrams)

        features_view = _vectorize_diagrams(
            diagrams=diagrams,
            prefix=view,
            homology_dimensions=config.homology_dimensions,
            betti_bins=config.betti_bins,
            persistence_image_bins=config.persistence_image_bins,
            persistence_image_sigma=config.persistence_image_sigma,
            top_k_lifetimes=config.top_k_lifetimes,
        )
        combined_features.append(features_view)
        modality_report[view] = {
            "num_samples": int(filtrations.shape[0]),
            "filtration_shape": list(filtrations.shape[1:]),
            "diagram_shape": list(diagrams.shape[1:]),
            "num_features": int(features_view.shape[1]),
        }

    feature_frame = pd.concat(combined_features, axis=1)
    feature_frame.to_csv(output_dir / "cubical_tda_features.csv", index=False, encoding="utf-8-sig")
    metadata[["patient_eye_id"]].to_csv(output_dir / "sample_index.csv", index=False, encoding="utf-8-sig")

    summary = {
        "config": asdict(config),
        "num_samples": int(len(metadata)),
        "views": list(config.views),
        "feature_table": str(output_dir / "cubical_tda_features.csv"),
        "sample_index": str(output_dir / "sample_index.csv"),
        "modalities": modality_report,
    }
    with (output_dir / "cubical_tda_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary
