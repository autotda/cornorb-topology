from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from typing import Callable

import numpy as np
import pandas as pd
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .tda import DEFAULT_TDA_VIEWS


@dataclass
class TDABaselineConfig:
    project_dir: str = "."
    features_csv: str = "runs/cubical_tda_v1/cubical_tda_features.csv"
    splits_dir: str = "experiment_setup/splits"
    output_dir: str = "runs/tda_only_logreg_v1"
    seed: int = 20260321
    c_grid: tuple[float, ...] = (0.03, 0.1, 0.3, 1.0)
    l1_ratio_grid: tuple[float, ...] = (0.0, 0.5, 1.0)
    max_iter: int = 4000
    use_class_weight: bool = True
    resume_existing: bool = False


BASE_COLUMNS = {
    "patient_eye_id",
    "patient_code",
    "eye",
    "label",
    "label_text",
    "gender",
    "age_years",
    "kmax_value_D",
    "pachy_thinnest_um",
    "had_duplicate_rows",
    "had_conflicting_clinical_values",
}


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_existing_history(history_path: Path) -> dict[str, Any] | None:
    if not history_path.exists():
        return None
    with history_path.open("r", encoding="utf-8") as fp:
        return json.load(fp)


def _safe_metric(metric_fn, *args, default: float = math.nan, **kwargs) -> float:
    try:
        return float(metric_fn(*args, **kwargs))
    except Exception:
        return default


def _specificity_score(labels: pd.Series, predictions: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=int)
    preds_np = predictions.to_numpy(dtype=int)
    negatives = labels_np == 0
    denom = int(negatives.sum())
    if denom == 0:
        return math.nan
    tn = int(((preds_np == 0) & negatives).sum())
    return float(tn / denom)


def _npv_score(labels: pd.Series, predictions: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=int)
    preds_np = predictions.to_numpy(dtype=int)
    predicted_negative = preds_np == 0
    denom = int(predicted_negative.sum())
    if denom == 0:
        return math.nan
    tn = int(((labels_np == 0) & predicted_negative).sum())
    return float(tn / denom)


def _brier_score(labels: pd.Series, probabilities: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=float)
    probs_np = probabilities.to_numpy(dtype=float)
    return float(np.mean((probs_np - labels_np) ** 2))


def _ece_score(labels: pd.Series, probabilities: pd.Series, num_bins: int = 10) -> float:
    labels_np = labels.to_numpy(dtype=float)
    probs_np = probabilities.to_numpy(dtype=float)
    edges = np.linspace(0.0, 1.0, num_bins + 1)
    ece = 0.0
    for lower, upper in zip(edges[:-1], edges[1:]):
        if upper == 1.0:
            mask = (probs_np >= lower) & (probs_np <= upper)
        else:
            mask = (probs_np >= lower) & (probs_np < upper)
        if not np.any(mask):
            continue
        confidence = float(probs_np[mask].mean())
        accuracy = float(labels_np[mask].mean())
        ece += float(mask.mean()) * abs(confidence - accuracy)
    return float(ece)


def _recall_at_specificity(labels: pd.Series, probabilities: pd.Series, target_specificity: float = 0.95) -> float:
    try:
        fpr, tpr, _ = roc_curve(labels, probabilities)
    except Exception:
        return math.nan
    specificity = 1.0 - fpr
    valid = tpr[specificity >= target_specificity]
    if len(valid) == 0:
        return math.nan
    return float(np.max(valid))


def compute_prediction_metrics(labels: pd.Series, probabilities: pd.Series) -> dict[str, float]:
    pred_binary = (probabilities >= 0.5).astype(int)
    return {
        "auroc": _safe_metric(roc_auc_score, labels, probabilities),
        "auprc": _safe_metric(average_precision_score, labels, probabilities),
        "accuracy": _safe_metric(accuracy_score, labels, pred_binary),
        "balanced_accuracy": _safe_metric(balanced_accuracy_score, labels, pred_binary),
        "f1": _safe_metric(f1_score, labels, pred_binary),
        "precision": _safe_metric(precision_score, labels, pred_binary, zero_division=0),
        "recall": _safe_metric(recall_score, labels, pred_binary, zero_division=0),
        "specificity": _specificity_score(labels, pred_binary),
        "npv": _npv_score(labels, pred_binary),
        "mcc": _safe_metric(matthews_corrcoef, labels, pred_binary),
        "brier_score": _brier_score(labels, probabilities),
        "ece_10": _ece_score(labels, probabilities, num_bins=10),
        "recall_at_95_specificity": _recall_at_specificity(labels, probabilities, target_specificity=0.95),
    }


def _feature_columns(dataframe: pd.DataFrame) -> list[str]:
    return [column for column in dataframe.columns if any(column.startswith(f"{view}_") for view in DEFAULT_TDA_VIEWS)]


def _load_feature_table(config: TDABaselineConfig) -> tuple[pd.DataFrame, list[str]]:
    path = Path(config.project_dir) / config.features_csv
    dataframe = pd.read_csv(path)
    feature_columns = _feature_columns(dataframe)
    if not feature_columns:
        raise ValueError(f"No TDA feature columns found in {path}.")
    return dataframe, feature_columns


def _subset_from_split(feature_df: pd.DataFrame, split_csv: Path) -> pd.DataFrame:
    split_df = pd.read_csv(split_csv)
    merged = split_df[["patient_eye_id"]].merge(feature_df, on="patient_eye_id", how="left", validate="one_to_one")
    if merged.isnull().any().any():
        missing = merged[merged.isnull().any(axis=1)]["patient_eye_id"].tolist()
        raise ValueError(f"Missing TDA features for samples: {missing[:5]}")
    return merged


def _subset_from_inner_assignments(feature_df: pd.DataFrame, assignments_csv: Path, inner_fold: int, split_name: str) -> pd.DataFrame:
    assignments = pd.read_csv(assignments_csv)
    subset = assignments[(assignments["inner_fold"] == inner_fold) & (assignments["split"] == split_name)][["patient_eye_id"]]
    merged = subset.merge(feature_df, on="patient_eye_id", how="left", validate="one_to_one")
    if merged.isnull().any().any():
        missing = merged[merged.isnull().any(axis=1)]["patient_eye_id"].tolist()
        raise ValueError(f"Missing TDA features for inner split samples: {missing[:5]}")
    return merged


def _build_estimator(config: TDABaselineConfig, *, C: float, l1_ratio: float) -> Pipeline:
    class_weight = "balanced" if config.use_class_weight else None
    if abs(l1_ratio) < 1e-12:
        penalty = "l2"
        solver = "lbfgs"
        logistic_kwargs = {}
    elif abs(l1_ratio - 1.0) < 1e-12:
        penalty = "l1"
        solver = "saga"
        logistic_kwargs = {}
    else:
        penalty = "elasticnet"
        solver = "saga"
        logistic_kwargs = {"l1_ratio": l1_ratio}

    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="constant", fill_value=0.0)),
            ("variance", VarianceThreshold()),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(
                    penalty=penalty,
                    solver=solver,
                    C=C,
                    class_weight=class_weight,
                    random_state=config.seed,
                    max_iter=config.max_iter,
                    **logistic_kwargs,
                ),
            ),
        ]
    )


def _fit_predict(
    estimator: Pipeline,
    train_df: pd.DataFrame,
    valid_df: pd.DataFrame,
    feature_columns: list[str],
    valid_frame_postprocess: Callable[[pd.DataFrame], pd.DataFrame] | None = None,
) -> tuple[np.ndarray, dict[str, float]]:
    x_train = train_df[feature_columns].replace([np.inf, -np.inf], np.nan).to_numpy(dtype=np.float32)
    y_train = train_df["label"].astype(int).to_numpy()
    valid_features = valid_df.copy()
    if valid_frame_postprocess is not None:
        valid_features = valid_frame_postprocess(valid_features)
    x_valid = valid_features[feature_columns].replace([np.inf, -np.inf], np.nan).to_numpy(dtype=np.float32)
    y_valid = valid_df["label"].astype(int).reset_index(drop=True)

    estimator.fit(x_train, y_train)
    probabilities = estimator.predict_proba(x_valid)[:, 1]
    metrics = compute_prediction_metrics(y_valid, pd.Series(probabilities))
    return probabilities, metrics


def _score_tuple(metrics: dict[str, float]) -> tuple[float, float, float]:
    auroc = metrics.get("auroc", math.nan)
    auprc = metrics.get("auprc", math.nan)
    bal_acc = metrics.get("balanced_accuracy", math.nan)
    return (
        -math.inf if math.isnan(auroc) else auroc,
        -math.inf if math.isnan(auprc) else auprc,
        -math.inf if math.isnan(bal_acc) else bal_acc,
    )


def tune_inner_cv(
    config: TDABaselineConfig,
    feature_df: pd.DataFrame,
    feature_columns: list[str],
    *,
    repeat: int,
    outer_fold: int,
) -> tuple[dict[str, float], pd.DataFrame]:
    outer_dir = Path(config.project_dir) / config.splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    inner_assignments_csv = outer_dir / "inner_folds_eyes.csv"
    rows: list[dict[str, float]] = []

    for C in config.c_grid:
        for l1_ratio in config.l1_ratio_grid:
            fold_metrics: list[dict[str, float]] = []
            for inner_fold in range(1, 5):
                train_df = _subset_from_inner_assignments(feature_df, inner_assignments_csv, inner_fold=inner_fold, split_name="inner_train")
                valid_df = _subset_from_inner_assignments(feature_df, inner_assignments_csv, inner_fold=inner_fold, split_name="inner_valid")
                estimator = _build_estimator(config, C=C, l1_ratio=l1_ratio)
                _, metrics = _fit_predict(estimator, train_df, valid_df, feature_columns)
                row = {
                    "repeat": repeat,
                    "outer_fold": outer_fold,
                    "inner_fold": inner_fold,
                    "C": C,
                    "l1_ratio": l1_ratio,
                    **metrics,
                }
                rows.append(row)
                fold_metrics.append(metrics)

    results_df = pd.DataFrame(rows)
    aggregate = (
        results_df.groupby(["C", "l1_ratio"], as_index=False)[["auroc", "auprc", "balanced_accuracy", "f1", "mcc"]]
        .mean()
        .sort_values(["auroc", "auprc", "balanced_accuracy", "f1", "mcc", "C", "l1_ratio"], ascending=[False, False, False, False, False, True, True])
        .reset_index(drop=True)
    )
    best_row = aggregate.iloc[0]
    best_params = {"C": float(best_row["C"]), "l1_ratio": float(best_row["l1_ratio"])}
    return best_params, results_df


def run_outer_fold(config: TDABaselineConfig, *, repeat: int, outer_fold: int) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    output_dir = project_dir / config.output_dir / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    if config.resume_existing:
        existing = _load_existing_history(output_dir / "history.json")
        if existing is not None:
            return existing
    _ensure_dir(output_dir)

    feature_df, feature_columns = _load_feature_table(config)
    outer_dir = project_dir / config.splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    train_csv = outer_dir / "outer_train_eyes.csv"
    valid_csv = outer_dir / "outer_valid_eyes.csv"

    best_params, inner_results_df = tune_inner_cv(config, feature_df, feature_columns, repeat=repeat, outer_fold=outer_fold)
    inner_results_df.to_csv(output_dir / "inner_cv_results.csv", index=False, encoding="utf-8-sig")

    train_df = _subset_from_split(feature_df, train_csv)
    valid_df = _subset_from_split(feature_df, valid_csv)
    estimator = _build_estimator(config, C=best_params["C"], l1_ratio=best_params["l1_ratio"])
    probabilities, metrics = _fit_predict(estimator, train_df, valid_df, feature_columns)

    valid_predictions = valid_df[["patient_eye_id", "patient_code", "eye", "label"]].copy()
    valid_predictions["probability"] = probabilities
    valid_predictions.to_csv(output_dir / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        "repeat": repeat,
        "outer_fold": outer_fold,
        "outer_dir": str(outer_dir),
        "features_csv": str(project_dir / config.features_csv),
        "num_tda_features": len(feature_columns),
        "best_params": best_params,
        "best_metrics": metrics,
    }
    with (output_dir / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_full_outer_cv(config: TDABaselineConfig) -> dict[str, Any]:
    all_results: list[dict[str, Any]] = []
    for repeat in range(1, 4):
        for outer_fold in range(1, 6):
            all_results.append(run_outer_fold(config, repeat=repeat, outer_fold=outer_fold))

    metrics_df = pd.DataFrame(
        [
            {
                "repeat": result["repeat"],
                "outer_fold": result["outer_fold"],
                "C": result["best_params"]["C"],
                "l1_ratio": result["best_params"]["l1_ratio"],
                **result["best_metrics"],
            }
            for result in all_results
        ]
    )
    numeric_cols = [column for column in metrics_df.columns if column not in {"repeat", "outer_fold"}]
    summary = {
        "config": asdict(config),
        "per_fold_metrics": metrics_df.to_dict(orient="records"),
        "aggregate": {
            column: {
                "mean": float(metrics_df[column].mean()),
                "std": float(metrics_df[column].std(ddof=0)),
            }
            for column in numeric_cols
        },
        "selected_params_frequency": (
            metrics_df.groupby(["C", "l1_ratio"]).size().reset_index(name="count").sort_values("count", ascending=False).to_dict(orient="records")
        ),
    }
    output_dir = Path(config.project_dir) / config.output_dir
    _ensure_dir(output_dir)
    metrics_df.to_csv(output_dir / "outer_cv_metrics.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "outer_cv_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def run_fixed_split(
    config: TDABaselineConfig,
    *,
    train_csv: str | Path,
    valid_csv: str | Path,
    C: float,
    l1_ratio: float,
    output_dir: str | Path,
    split_name: str,
    meta: dict[str, Any] | None = None,
    save_predictions: bool = True,
    valid_frame_postprocess: Callable[[pd.DataFrame], pd.DataFrame] | None = None,
) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    output_path = Path(output_dir)
    _ensure_dir(output_path)

    feature_df, feature_columns = _load_feature_table(config)
    train_df = _subset_from_split(feature_df, Path(train_csv))
    valid_df = _subset_from_split(feature_df, Path(valid_csv))

    estimator = _build_estimator(config, C=C, l1_ratio=l1_ratio)
    probabilities, metrics = _fit_predict(
        estimator,
        train_df,
        valid_df,
        feature_columns,
        valid_frame_postprocess=valid_frame_postprocess,
    )
    if save_predictions:
        valid_predictions = valid_df[["patient_eye_id", "patient_code", "eye", "label"]].copy()
        valid_predictions["probability"] = probabilities
        valid_predictions.to_csv(output_path / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        "split_name": split_name,
        "train_csv": str(train_csv),
        "valid_csv": str(valid_csv),
        "features_csv": str(project_dir / config.features_csv),
        "num_tda_features": len(feature_columns),
        "chosen_params": {"C": C, "l1_ratio": l1_ratio},
        "best_metrics": metrics,
        **(meta or {}),
    }
    with (output_path / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_locked_test(
    config: TDABaselineConfig,
    *,
    C: float,
    l1_ratio: float,
    save_predictions: bool = True,
) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = project_dir / config.output_dir / "locked_test"
    return run_fixed_split(
        config,
        train_csv=splits_dir / "development_eyes.csv",
        valid_csv=splits_dir / "locked_test_eyes.csv",
        C=C,
        l1_ratio=l1_ratio,
        output_dir=output_dir,
        split_name="locked_test",
        save_predictions=save_predictions,
    )
