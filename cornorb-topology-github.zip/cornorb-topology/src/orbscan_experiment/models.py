from __future__ import annotations

import torch
from torch import nn
from torchvision.models import ConvNeXt_Tiny_Weights, convnext_tiny


class SmallImageEncoder(nn.Module):
    def __init__(self, output_dim: int = 192) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.GELU(),
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.GELU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.GELU(),
            nn.Conv2d(128, output_dim, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(output_dim),
            nn.GELU(),
            nn.AdaptiveAvgPool2d((1, 1)),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        return x.flatten(1)


class SmokeFusionNet(nn.Module):
    """Lightweight baseline used for quick smoke tests."""

    def __init__(self, clinical_dim: int, image_embedding_dim: int = 192) -> None:
        super().__init__()
        self.use_clinical = clinical_dim > 0
        self.image_encoder = SmallImageEncoder(output_dim=image_embedding_dim)
        self.view_gate = nn.Sequential(
            nn.Linear(image_embedding_dim, image_embedding_dim // 2),
            nn.GELU(),
            nn.Linear(image_embedding_dim // 2, 1),
        )
        if self.use_clinical:
            self.clinical_mlp = nn.Sequential(
                nn.Linear(clinical_dim, 64),
                nn.LayerNorm(64),
                nn.GELU(),
                nn.Dropout(0.1),
            )
            fusion_dim = image_embedding_dim + 64
        else:
            self.clinical_mlp = None
            fusion_dim = image_embedding_dim
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim, 128),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(128, 1),
        )

    def forward(
        self,
        images: torch.Tensor,
        clinical: torch.Tensor,
        tda: torch.Tensor | None = None,
    ) -> torch.Tensor:
        batch_size, num_views, channels, height, width = images.shape
        encoded = self.image_encoder(images.reshape(batch_size * num_views, channels, height, width))
        encoded = encoded.view(batch_size, num_views, -1)
        scores = self.view_gate(encoded).squeeze(-1)
        weights = torch.softmax(scores, dim=1).unsqueeze(-1)
        fused_images = torch.sum(encoded * weights, dim=1)
        if self.use_clinical:
            fused_clinical = self.clinical_mlp(clinical)
            fused_features = torch.cat([fused_images, fused_clinical], dim=1)
        else:
            fused_features = fused_images
        logits = self.classifier(fused_features)
        return logits.squeeze(-1)


class ConvNeXtTinyEncoder(nn.Module):
    def __init__(self, pretrained: bool = True) -> None:
        super().__init__()
        weights = ConvNeXt_Tiny_Weights.IMAGENET1K_V1 if pretrained else None
        backbone = convnext_tiny(weights=weights)
        self.features = backbone.features
        self.avgpool = backbone.avgpool
        self.norm = nn.LayerNorm(768)
        self.output_dim = 768

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = x.flatten(1)
        return self.norm(x)


class TabularTokenEncoder(nn.Module):
    def __init__(self, input_dim: int, token_dim: int, dropout: float = 0.1) -> None:
        super().__init__()
        hidden_dim = min(max(token_dim, input_dim // 2), 1024)
        self.proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, token_dim),
            nn.LayerNorm(token_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.proj(x)


class DeepMultiviewFusionNet(nn.Module):
    """
    Full deep-learning model before introducing TDA:
    shared ConvNeXt image encoder + clinical token + fusion transformer.
    """

    def __init__(
        self,
        clinical_dim: int,
        tda_dim: int = 0,
        num_views: int = 4,
        pretrained_backbone: bool = True,
        token_dim: int = 384,
        num_heads: int = 8,
        num_layers: int = 3,
        dropout: float = 0.1,
        freeze_backbone_epochs: int = 1,
    ) -> None:
        super().__init__()
        self.num_views = num_views
        self.use_clinical = clinical_dim > 0
        self.use_tda = tda_dim > 0
        self.freeze_backbone_epochs = freeze_backbone_epochs
        self.image_encoder = ConvNeXtTinyEncoder(pretrained=pretrained_backbone)
        self.image_proj = nn.Sequential(
            nn.Linear(self.image_encoder.output_dim, token_dim),
            nn.LayerNorm(token_dim),
        )
        self.clinical_encoder = (
            TabularTokenEncoder(input_dim=clinical_dim, token_dim=token_dim, dropout=dropout)
            if self.use_clinical
            else None
        )
        self.tda_encoder = (
            TabularTokenEncoder(input_dim=tda_dim, token_dim=token_dim, dropout=dropout) if self.use_tda else None
        )
        self.cls_token = nn.Parameter(torch.zeros(1, 1, token_dim))
        total_tokens = 1 + num_views + int(self.use_clinical) + int(self.use_tda)
        self.view_embeddings = nn.Parameter(torch.zeros(1, total_tokens, token_dim))
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=token_dim,
            nhead=num_heads,
            dim_feedforward=token_dim * 4,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.fusion_transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.final_norm = nn.LayerNorm(token_dim)
        self.head = nn.Sequential(
            nn.Linear(token_dim, token_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(token_dim // 2, 1),
        )
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        nn.init.trunc_normal_(self.view_embeddings, std=0.02)

    def set_backbone_trainable(self, trainable: bool) -> None:
        for param in self.image_encoder.parameters():
            param.requires_grad = trainable

    def forward(
        self,
        images: torch.Tensor,
        clinical: torch.Tensor,
        tda: torch.Tensor | None = None,
    ) -> torch.Tensor:
        batch_size, num_views, channels, height, width = images.shape
        if num_views != self.num_views:
            raise ValueError(f"Expected {self.num_views} views, got {num_views}.")

        encoded = self.image_encoder(images.reshape(batch_size * num_views, channels, height, width))
        encoded = self.image_proj(encoded).view(batch_size, num_views, -1)
        cls_token = self.cls_token.expand(batch_size, -1, -1)
        tokens = [cls_token, encoded]
        if self.use_clinical:
            if clinical.numel() == 0:
                raise ValueError("Clinical features are required but the batch is empty.")
            tokens.append(self.clinical_encoder(clinical).unsqueeze(1))
        if self.use_tda:
            if tda is None or tda.numel() == 0:
                raise ValueError("TDA features are required but the batch is empty.")
            tokens.append(self.tda_encoder(tda).unsqueeze(1))
        tokens = torch.cat(tokens, dim=1)
        tokens = tokens + self.view_embeddings[:, : tokens.size(1), :]
        fused = self.fusion_transformer(tokens)
        cls_out = self.final_norm(fused[:, 0])
        logits = self.head(cls_out)
        return logits.squeeze(-1)


def build_model(
    model_name: str,
    clinical_dim: int,
    tda_dim: int,
    num_views: int,
    pretrained_backbone: bool,
    token_dim: int,
    num_heads: int,
    num_layers: int,
    dropout: float,
    freeze_backbone_epochs: int,
) -> nn.Module:
    model_name = model_name.lower()
    if model_name == "smoke_fusion":
        return SmokeFusionNet(clinical_dim=clinical_dim)
    if model_name == "deep_mv_fusion":
        return DeepMultiviewFusionNet(
            clinical_dim=clinical_dim,
            tda_dim=0,
            num_views=num_views,
            pretrained_backbone=pretrained_backbone,
            token_dim=token_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout,
            freeze_backbone_epochs=freeze_backbone_epochs,
        )
    if model_name == "deep_mv_tda_fusion":
        if tda_dim <= 0:
            raise ValueError("deep_mv_tda_fusion requires a positive tda_dim.")
        return DeepMultiviewFusionNet(
            clinical_dim=clinical_dim,
            tda_dim=tda_dim,
            num_views=num_views,
            pretrained_backbone=pretrained_backbone,
            token_dim=token_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout,
            freeze_backbone_epochs=freeze_backbone_epochs,
        )
    raise ValueError(f"Unsupported model_name: {model_name}")
