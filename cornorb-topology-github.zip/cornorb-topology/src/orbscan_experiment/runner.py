from __future__ import annotations

import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from torch import nn
from torch.utils.data import DataLoader
from torchvision import transforms

from .dataset import (
    DEFAULT_NUMERIC_CLINICAL_COLUMNS,
    DEFAULT_VIEWS,
    OrbscanMultiviewDataset,
    fit_clinical_stats,
    fit_tda_stats,
    load_eye_split,
    load_tda_feature_table,
    subset_tda_feature_frame,
)
from .models import DeepMultiviewFusionNet, build_model


@dataclass
class RunnerConfig:
    project_dir: str = "."
    splits_dir: str = "experiment_setup/splits"
    output_dir: str = "runs/deep_mv_fusion"
    model_name: str = "deep_mv_fusion"
    image_size: int = 224
    batch_size: int = 8
    epochs: int = 10
    num_workers: int = 4
    learning_rate: float = 3e-4
    weight_decay: float = 1e-4
    seed: int = 20260320
    amp: bool = True
    device: str = "cuda"
    max_train_batches: int = -1
    max_val_batches: int = -1
    include_clinical: bool = True
    views: tuple[str, ...] = DEFAULT_VIEWS
    pretrained_backbone: bool = True
    token_dim: int = 384
    num_heads: int = 8
    num_layers: int = 3
    dropout: float = 0.1
    freeze_backbone_epochs: int = 1
    tda_features_csv: str = "runs/cubical_tda_v1/cubical_tda_features.csv"
    include_tda: bool = False
    selection_policy: str = "legacy_outer_valid"
    locked_selected_epoch: int | None = None
    clean_reference_history: str = ""
    resume_existing: bool = False


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def resolve_device(device: str) -> torch.device:
    if device == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_existing_history(history_path: Path) -> dict[str, Any] | None:
    if not history_path.exists():
        return None
    with history_path.open("r", encoding="utf-8") as fp:
        return json.load(fp)


def load_outer_split_paths(splits_dir: Path, repeat: int, outer_fold: int) -> tuple[Path, Path, Path]:
    outer_dir = splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    train_csv = outer_dir / "outer_train_eyes.csv"
    valid_csv = outer_dir / "outer_valid_eyes.csv"
    return outer_dir, train_csv, valid_csv


def load_locked_test_paths(splits_dir: Path) -> tuple[Path, Path, Path]:
    locked_dir = splits_dir / "locked_test"
    train_csv = splits_dir / "development_eyes.csv"
    valid_csv = splits_dir / "locked_test_eyes.csv"
    return locked_dir, train_csv, valid_csv


def load_inner_assignments_path(splits_dir: Path, repeat: int, outer_fold: int) -> Path:
    return splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}" / "inner_folds_eyes.csv"


def build_transforms(image_size: int) -> tuple[transforms.Compose, transforms.Compose]:
    normalize = transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
    train_transform = transforms.Compose(
        [
            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.RandomAffine(degrees=4, translate=(0.03, 0.03), scale=(0.96, 1.04)),
            transforms.ToTensor(),
            normalize,
        ]
    )
    valid_transform = transforms.Compose(
        [
            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            normalize,
        ]
    )
    return train_transform, valid_transform


def build_dataloaders(
    project_dir: Path,
    train_csv: Path,
    valid_csv: Path,
    image_size: int,
    batch_size: int,
    num_workers: int,
    views: tuple[str, ...],
    include_clinical: bool,
    include_tda: bool,
    tda_features_csv: str,
) -> tuple[DataLoader, DataLoader, int, int, float]:
    train_df = load_eye_split(train_csv)
    stats = fit_clinical_stats(train_df, DEFAULT_NUMERIC_CLINICAL_COLUMNS)
    train_transform, valid_transform = build_transforms(image_size)
    tda_feature_frame = None
    tda_feature_columns: tuple[str, ...] = ()
    tda_stats: dict[str, dict[str, float]] | None = None
    if include_tda:
        tda_feature_frame, feature_columns = load_tda_feature_table(project_dir / tda_features_csv)
        train_tda_subset = subset_tda_feature_frame(
            tda_feature_frame=tda_feature_frame,
            patient_eye_ids=train_df["patient_eye_id"].tolist(),
            feature_columns=feature_columns,
        )
        tda_feature_columns = tuple(feature_columns)
        tda_stats = fit_tda_stats(train_tda_subset, tda_feature_columns)

    train_dataset = OrbscanMultiviewDataset(
        train_csv,
        image_size=image_size,
        views=views,
        clinical_stats=stats,
        include_clinical=include_clinical,
        tda_feature_frame=tda_feature_frame,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        include_tda=include_tda,
        transform=train_transform,
    )
    valid_dataset = OrbscanMultiviewDataset(
        valid_csv,
        image_size=image_size,
        views=views,
        clinical_stats=stats,
        include_clinical=include_clinical,
        tda_feature_frame=tda_feature_frame,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        include_tda=include_tda,
        transform=valid_transform,
    )

    persistent = num_workers > 0
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=persistent,
    )
    valid_loader = DataLoader(
        valid_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=persistent,
    )
    clinical_dim = len(DEFAULT_NUMERIC_CLINICAL_COLUMNS) + 1 if include_clinical else 0
    tda_dim = len(tda_feature_columns) if include_tda else 0
    positives = float((train_df["label"] == 1).sum())
    negatives = float((train_df["label"] == 0).sum())
    pos_weight = negatives / positives if positives > 0 else 1.0
    return train_loader, valid_loader, clinical_dim, tda_dim, pos_weight


def _limit_batches(max_batches: int, batch_index: int) -> bool:
    return max_batches > 0 and batch_index >= max_batches


def _safe_metric(metric_fn, *args, default: float = math.nan, **kwargs) -> float:
    try:
        return float(metric_fn(*args, **kwargs))
    except Exception:
        return default


def _score_tuple(metrics: dict[str, float]) -> tuple[float, float, float, float]:
    def _value(key: str) -> float:
        value = metrics.get(key, math.nan)
        return -math.inf if math.isnan(value) else value

    return (
        _value("auroc"),
        _value("auprc"),
        _value("balanced_accuracy"),
        _value("f1"),
    )


def _specificity_score(labels: pd.Series, predictions: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=int)
    preds_np = predictions.to_numpy(dtype=int)
    negatives = labels_np == 0
    denom = int(negatives.sum())
    if denom == 0:
        return math.nan
    tn = int(((preds_np == 0) & negatives).sum())
    return float(tn / denom)


def _npv_score(labels: pd.Series, predictions: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=int)
    preds_np = predictions.to_numpy(dtype=int)
    predicted_negative = preds_np == 0
    denom = int(predicted_negative.sum())
    if denom == 0:
        return math.nan
    tn = int(((labels_np == 0) & predicted_negative).sum())
    return float(tn / denom)


def _brier_score(labels: pd.Series, probabilities: pd.Series) -> float:
    labels_np = labels.to_numpy(dtype=float)
    probs_np = probabilities.to_numpy(dtype=float)
    return float(np.mean((probs_np - labels_np) ** 2))


def _ece_score(labels: pd.Series, probabilities: pd.Series, num_bins: int = 10) -> float:
    labels_np = labels.to_numpy(dtype=float)
    probs_np = probabilities.to_numpy(dtype=float)
    edges = np.linspace(0.0, 1.0, num_bins + 1)
    ece = 0.0
    for lower, upper in zip(edges[:-1], edges[1:]):
        if upper == 1.0:
            mask = (probs_np >= lower) & (probs_np <= upper)
        else:
            mask = (probs_np >= lower) & (probs_np < upper)
        if not np.any(mask):
            continue
        confidence = float(probs_np[mask].mean())
        accuracy = float(labels_np[mask].mean())
        ece += float(mask.mean()) * abs(confidence - accuracy)
    return float(ece)


def _recall_at_specificity(labels: pd.Series, probabilities: pd.Series, target_specificity: float = 0.95) -> float:
    try:
        fpr, tpr, _ = roc_curve(labels, probabilities)
    except Exception:
        return math.nan
    specificity = 1.0 - fpr
    valid = tpr[specificity >= target_specificity]
    if len(valid) == 0:
        return math.nan
    return float(np.max(valid))


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    criterion: nn.Module,
    device: torch.device,
    scaler: torch.amp.GradScaler,
    amp: bool,
    max_batches: int,
    grad_clip: float = 1.0,
) -> float:
    model.train()
    losses: list[float] = []
    for batch_index, batch in enumerate(loader):
        if _limit_batches(max_batches, batch_index):
            break
        images = batch["images"].to(device, non_blocking=True)
        clinical_batch = batch.get("clinical")
        if clinical_batch is None:
            clinical = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
        else:
            clinical = clinical_batch.to(device, non_blocking=True)
        tda_batch = batch.get("tda")
        if tda_batch is None:
            tda = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
        else:
            tda = tda_batch.to(device, non_blocking=True)
        labels = batch["label"].to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast(device_type=device.type, enabled=amp and device.type == "cuda"):
            logits = model(images=images, clinical=clinical, tda=tda)
            loss = criterion(logits, labels)

        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        scaler.step(optimizer)
        scaler.update()
        losses.append(float(loss.detach().cpu()))
    return float(np.mean(losses)) if losses else math.nan


def evaluate(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    amp: bool,
    max_batches: int,
) -> tuple[dict[str, float], pd.DataFrame]:
    model.eval()
    losses: list[float] = []
    probs_all: list[float] = []
    labels_all: list[int] = []
    ids_all: list[str] = []
    patients_all: list[str] = []
    eyes_all: list[str] = []

    with torch.no_grad():
        for batch_index, batch in enumerate(loader):
            if _limit_batches(max_batches, batch_index):
                break
            images = batch["images"].to(device, non_blocking=True)
            clinical_batch = batch.get("clinical")
            if clinical_batch is None:
                clinical = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
            else:
                clinical = clinical_batch.to(device, non_blocking=True)
            tda_batch = batch.get("tda")
            if tda_batch is None:
                tda = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
            else:
                tda = tda_batch.to(device, non_blocking=True)
            labels = batch["label"].to(device, non_blocking=True)

            with torch.amp.autocast(device_type=device.type, enabled=amp and device.type == "cuda"):
                logits = model(images=images, clinical=clinical, tda=tda)
                loss = criterion(logits, labels)
            probs = torch.sigmoid(logits).detach().cpu().numpy()
            labels_np = labels.detach().cpu().numpy()

            losses.append(float(loss.detach().cpu()))
            probs_all.extend(probs.tolist())
            labels_all.extend(labels_np.astype(int).tolist())
            ids_all.extend(batch["patient_eye_id"])
            patients_all.extend(batch["patient_code"])
            eyes_all.extend(batch["eye"])

    prediction_df = pd.DataFrame(
        {
            "patient_eye_id": ids_all,
            "patient_code": patients_all,
            "eye": eyes_all,
            "label": labels_all,
            "probability": probs_all,
        }
    )
    pred_binary = (prediction_df["probability"] >= 0.5).astype(int)
    labels_series = prediction_df["label"].astype(int)

    metrics = {
        "loss": float(np.mean(losses)) if losses else math.nan,
        "auroc": _safe_metric(roc_auc_score, labels_series, prediction_df["probability"]),
        "auprc": _safe_metric(average_precision_score, labels_series, prediction_df["probability"]),
        "accuracy": _safe_metric(accuracy_score, labels_series, pred_binary),
        "balanced_accuracy": _safe_metric(balanced_accuracy_score, labels_series, pred_binary),
        "f1": _safe_metric(f1_score, labels_series, pred_binary),
        "precision": _safe_metric(precision_score, labels_series, pred_binary, zero_division=0),
        "recall": _safe_metric(recall_score, labels_series, pred_binary, zero_division=0),
        "specificity": _specificity_score(labels_series, pred_binary),
        "npv": _npv_score(labels_series, pred_binary),
        "mcc": _safe_metric(matthews_corrcoef, labels_series, pred_binary),
        "brier_score": _brier_score(labels_series, prediction_df["probability"]),
        "ece_10": _ece_score(labels_series, prediction_df["probability"], num_bins=10),
        "recall_at_95_specificity": _recall_at_specificity(labels_series, prediction_df["probability"], target_specificity=0.95),
    }
    return metrics, prediction_df


def maybe_freeze_backbone(model: nn.Module, epoch: int) -> None:
    if isinstance(model, DeepMultiviewFusionNet):
        trainable = epoch > model.freeze_backbone_epochs
        model.set_backbone_trainable(trainable=trainable)


def build_training_components(
    config: RunnerConfig,
    clinical_dim: int,
    tda_dim: int,
    pos_weight: float,
    device: torch.device,
):
    model = build_model(
        model_name=config.model_name,
        clinical_dim=clinical_dim,
        tda_dim=tda_dim,
        num_views=len(config.views),
        pretrained_backbone=config.pretrained_backbone,
        token_dim=config.token_dim,
        num_heads=config.num_heads,
        num_layers=config.num_layers,
        dropout=config.dropout,
        freeze_backbone_epochs=config.freeze_backbone_epochs,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(config.epochs, 1))
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([pos_weight], device=device))
    scaler = torch.amp.GradScaler(enabled=config.amp and device.type == "cuda")
    return model, optimizer, scheduler, criterion, scaler


def _subset_full_split_from_assignments(
    full_df: pd.DataFrame,
    assignments_df: pd.DataFrame,
    *,
    inner_fold: int,
    split_name: str,
) -> pd.DataFrame:
    subset_ids = assignments_df[
        (assignments_df["inner_fold"] == inner_fold) & (assignments_df["split"] == split_name)
    ][["patient_eye_id"]]
    subset = subset_ids.merge(full_df, on="patient_eye_id", how="left", validate="one_to_one")
    if subset["patient_code"].isnull().any():
        missing = subset[subset["patient_code"].isnull()]["patient_eye_id"].tolist()
        raise ValueError(f"Missing rows for inner split {split_name} fold {inner_fold}: {missing[:5]}")
    return subset


def _materialize_inner_split_csvs(
    *,
    outer_train_csv: Path,
    inner_assignments_csv: Path,
    inner_fold: int,
    output_dir: Path,
) -> tuple[Path, Path]:
    ensure_dir(output_dir)
    outer_train_df = load_eye_split(outer_train_csv)
    assignments_df = pd.read_csv(inner_assignments_csv)
    inner_train_df = _subset_full_split_from_assignments(
        full_df=outer_train_df,
        assignments_df=assignments_df,
        inner_fold=inner_fold,
        split_name="inner_train",
    )
    inner_valid_df = _subset_full_split_from_assignments(
        full_df=outer_train_df,
        assignments_df=assignments_df,
        inner_fold=inner_fold,
        split_name="inner_valid",
    )
    inner_train_csv = output_dir / "inner_train_eyes.csv"
    inner_valid_csv = output_dir / "inner_valid_eyes.csv"
    inner_train_df.to_csv(inner_train_csv, index=False, encoding="utf-8-sig")
    inner_valid_df.to_csv(inner_valid_csv, index=False, encoding="utf-8-sig")
    return inner_train_csv, inner_valid_csv


def _select_epoch_from_inner_histories(inner_results: list[dict[str, Any]]) -> tuple[int, pd.DataFrame]:
    rows: list[dict[str, float]] = []
    for result in inner_results:
        inner_fold = int(result["inner_fold"])
        for record in result.get("history", []):
            rows.append(
                {
                    "inner_fold": inner_fold,
                    "epoch": int(record["epoch"]),
                    "auroc": record.get("auroc", math.nan),
                    "auprc": record.get("auprc", math.nan),
                    "balanced_accuracy": record.get("balanced_accuracy", math.nan),
                    "f1": record.get("f1", math.nan),
                    "loss": record.get("loss", math.nan),
                }
            )
    history_df = pd.DataFrame(rows)
    if history_df.empty:
        raise ValueError("Inner-fold histories are empty; cannot select epoch.")

    aggregate = (
        history_df.groupby("epoch", as_index=False)[["auroc", "auprc", "balanced_accuracy", "f1", "loss"]]
        .mean()
        .sort_values(
            ["auroc", "auprc", "balanced_accuracy", "f1", "epoch"],
            ascending=[False, False, False, False, True],
        )
        .reset_index(drop=True)
    )
    best_epoch = int(aggregate.iloc[0]["epoch"])
    return best_epoch, aggregate


def _run_train_valid_job(
    config: RunnerConfig,
    *,
    train_csv: Path,
    valid_csv: Path,
    output_dir: Path,
    meta: dict[str, Any],
    select_best_epoch: bool = True,
    save_checkpoint: bool = True,
    save_predictions: bool = True,
) -> dict[str, Any]:
    ensure_dir(output_dir)

    train_loader, valid_loader, clinical_dim, tda_dim, pos_weight = build_dataloaders(
        project_dir=Path(config.project_dir),
        train_csv=train_csv,
        valid_csv=valid_csv,
        image_size=config.image_size,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        views=config.views,
        include_clinical=config.include_clinical,
        include_tda=config.include_tda,
        tda_features_csv=config.tda_features_csv,
    )

    device = resolve_device(config.device)
    model, optimizer, scheduler, criterion, scaler = build_training_components(
        config=config,
        clinical_dim=clinical_dim,
        tda_dim=tda_dim,
        pos_weight=pos_weight,
        device=device,
    )

    history: list[dict[str, float]] = []
    best_metric = -float("inf")
    best_state_path = output_dir / "best_model.pt"
    best_metrics: dict[str, float] | None = None
    best_predictions: pd.DataFrame | None = None
    selected_epoch = config.epochs
    last_payload: dict[str, Any] | None = None
    last_predictions: pd.DataFrame | None = None
    last_metrics: dict[str, float] | None = None

    for epoch in range(1, config.epochs + 1):
        maybe_freeze_backbone(model, epoch)
        train_loss = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
            scaler=scaler,
            amp=config.amp,
            max_batches=config.max_train_batches,
        )
        val_metrics, val_predictions = evaluate(
            model=model,
            loader=valid_loader,
            criterion=criterion,
            device=device,
            amp=config.amp,
            max_batches=config.max_val_batches,
        )
        scheduler.step()

        record = {
            "epoch": epoch,
            "train_loss": train_loss,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            **val_metrics,
        }
        history.append(record)
        last_payload = {
            "model_state_dict": model.state_dict(),
            "config": asdict(config),
            "clinical_dim": clinical_dim,
            "tda_dim": tda_dim,
            **meta,
        }
        last_predictions = val_predictions
        last_metrics = val_metrics

        if select_best_epoch:
            current_metric = val_metrics["auroc"] if not math.isnan(val_metrics["auroc"]) else val_metrics["auprc"]
            if current_metric > best_metric:
                best_metric = current_metric
                best_metrics = val_metrics
                selected_epoch = epoch
                if save_checkpoint:
                    torch.save(last_payload, best_state_path)
                if save_predictions:
                    best_predictions = val_predictions.copy()

    if not select_best_epoch:
        if last_payload is None or last_predictions is None or last_metrics is None:
            raise ValueError("Training produced no epochs; cannot save final model.")
        best_metrics = last_metrics
        selected_epoch = config.epochs
        if save_checkpoint:
            torch.save(last_payload, best_state_path)
        if save_predictions:
            last_predictions.to_csv(output_dir / "val_predictions.csv", index=False, encoding="utf-8-sig")
    elif save_predictions and best_predictions is not None:
        best_predictions.to_csv(output_dir / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        **meta,
        "device": str(device),
        "model_name": config.model_name,
        "epochs": config.epochs,
        "selection_policy": meta.get(
            "selection_policy",
            "outer_valid_best" if select_best_epoch else "fixed_epoch",
        ),
        "selected_epoch": selected_epoch,
        "train_csv": str(train_csv),
        "valid_csv": str(valid_csv),
        "clinical_dim": clinical_dim,
        "tda_dim": tda_dim,
        "best_metrics": best_metrics or {},
        "history": history,
    }
    with (output_dir / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def _run_outer_fold_nested(config: RunnerConfig, repeat: int, outer_fold: int) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = project_dir / config.output_dir / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    outer_dir, outer_train_csv, outer_valid_csv = load_outer_split_paths(splits_dir, repeat, outer_fold)
    inner_assignments_csv = load_inner_assignments_path(splits_dir, repeat, outer_fold)

    inner_results: list[dict[str, Any]] = []
    for inner_fold in range(1, 5):
        inner_output_dir = output_dir / "inner_cv" / f"inner_fold_{inner_fold:02d}"
        inner_train_csv, inner_valid_csv = _materialize_inner_split_csvs(
            outer_train_csv=outer_train_csv,
            inner_assignments_csv=inner_assignments_csv,
            inner_fold=inner_fold,
            output_dir=inner_output_dir,
        )
        seed_everything(config.seed + repeat * 1000 + outer_fold * 100 + inner_fold)
        inner_results.append(
            _run_train_valid_job(
                config=config,
                train_csv=inner_train_csv,
                valid_csv=inner_valid_csv,
                output_dir=inner_output_dir,
                meta={
                    "repeat": repeat,
                    "outer_fold": outer_fold,
                    "inner_fold": inner_fold,
                    "outer_dir": str(outer_dir),
                },
                select_best_epoch=True,
            )
        )

    selected_epoch, epoch_summary_df = _select_epoch_from_inner_histories(inner_results)
    ensure_dir(output_dir)
    epoch_summary_df.to_csv(output_dir / "inner_epoch_selection.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "inner_epoch_selection.json").open("w", encoding="utf-8") as fp:
        json.dump(
            {
                "repeat": repeat,
                "outer_fold": outer_fold,
                "selection_policy": "nested_inner_cv",
                "selected_epoch": selected_epoch,
                "epoch_summary": epoch_summary_df.to_dict(orient="records"),
                "inner_folds": [
                    {
                        "inner_fold": result["inner_fold"],
                        "selected_epoch": result.get("selected_epoch"),
                    }
                    for result in inner_results
                ],
            },
            fp,
            ensure_ascii=False,
            indent=2,
        )

    final_config = RunnerConfig(**asdict(config))
    final_config.epochs = selected_epoch
    seed_everything(config.seed + repeat * 100 + outer_fold)
    result = _run_train_valid_job(
        config=final_config,
        train_csv=outer_train_csv,
        valid_csv=outer_valid_csv,
        output_dir=output_dir,
        meta={
            "repeat": repeat,
            "outer_fold": outer_fold,
            "outer_dir": str(outer_dir),
            "selection_policy": "nested_inner_cv",
            "selected_epoch": selected_epoch,
            "inner_assignments_csv": str(inner_assignments_csv),
        },
        select_best_epoch=False,
    )
    result["inner_cv"] = {
        "selected_epoch": selected_epoch,
        "num_inner_folds": len(inner_results),
        "epoch_selection_csv": str(output_dir / "inner_epoch_selection.csv"),
    }
    with (output_dir / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_outer_fold(config: RunnerConfig, repeat: int, outer_fold: int) -> dict[str, Any]:
    output_dir = Path(config.project_dir) / config.output_dir / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    if config.resume_existing:
        existing = _load_existing_history(output_dir / "history.json")
        if existing is not None:
            return existing

    if config.selection_policy == "nested_inner_cv":
        return _run_outer_fold_nested(config, repeat=repeat, outer_fold=outer_fold)

    seed_everything(config.seed + repeat * 100 + outer_fold)
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    outer_dir, train_csv, valid_csv = load_outer_split_paths(splits_dir, repeat, outer_fold)
    return _run_train_valid_job(
        config=config,
        train_csv=train_csv,
        valid_csv=valid_csv,
        output_dir=output_dir,
        meta={
            "repeat": repeat,
            "outer_fold": outer_fold,
            "outer_dir": str(outer_dir),
            "selection_policy": config.selection_policy,
        },
    )


def run_locked_test(
    config: RunnerConfig,
    *,
    save_checkpoint: bool = True,
    save_predictions: bool = True,
) -> dict[str, Any]:
    seed_everything(config.seed + 999)
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = project_dir / config.output_dir / "locked_test"
    locked_dir, train_csv, valid_csv = load_locked_test_paths(splits_dir)
    locked_config = RunnerConfig(**asdict(config))
    if locked_config.locked_selected_epoch is not None and locked_config.locked_selected_epoch > 0:
        locked_config.epochs = int(locked_config.locked_selected_epoch)
        select_best_epoch = False
        selection_policy = "fixed_locked_epoch"
    else:
        select_best_epoch = True
        selection_policy = locked_config.selection_policy
    result = _run_train_valid_job(
        config=locked_config,
        train_csv=train_csv,
        valid_csv=valid_csv,
        output_dir=output_dir,
        meta={
            "split_name": "locked_test",
            "locked_dir": str(locked_dir),
            "selection_policy": selection_policy,
        },
        select_best_epoch=select_best_epoch,
        save_checkpoint=save_checkpoint,
        save_predictions=save_predictions,
    )
    return result


def run_full_outer_cv(config: RunnerConfig) -> dict[str, Any]:
    all_results: list[dict[str, Any]] = []
    for repeat in range(1, 4):
        for outer_fold in range(1, 6):
            all_results.append(run_outer_fold(config, repeat=repeat, outer_fold=outer_fold))

    metrics_df = pd.DataFrame(
        [
            {
                "repeat": r["repeat"],
                "outer_fold": r["outer_fold"],
                "selected_epoch": r.get("selected_epoch", math.nan),
                **r["best_metrics"],
            }
            for r in all_results
        ]
    )
    numeric_cols = [c for c in metrics_df.columns if c not in {"repeat", "outer_fold"}]
    summary = {
        "config": asdict(config),
        "per_fold_metrics": metrics_df.to_dict(orient="records"),
        "aggregate": {
            col: {"mean": float(metrics_df[col].mean()), "std": float(metrics_df[col].std(ddof=0))}
            for col in numeric_cols
        },
        "selected_epoch_frequency": (
            metrics_df["selected_epoch"]
            .value_counts(dropna=False)
            .sort_index()
            .rename_axis("selected_epoch")
            .reset_index(name="count")
            .to_dict(orient="records")
        ),
    }
    output_dir = Path(config.project_dir) / config.output_dir
    ensure_dir(output_dir)
    metrics_df.to_csv(output_dir / "outer_cv_metrics.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "outer_cv_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary
