from __future__ import annotations

import json
import math
import random
from dataclasses import asdict, dataclass
from io import BytesIO
from itertools import combinations
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import torch
from PIL import Image, ImageFilter
from torch import nn
from torch.utils.data import DataLoader
from torchvision.transforms import InterpolationMode
from torchvision.transforms import functional as F

from .dataset import (
    DEFAULT_NUMERIC_CLINICAL_COLUMNS,
    DEFAULT_VIEWS,
    OrbscanMultiviewDataset,
    fit_clinical_stats,
    fit_tda_stats,
    load_eye_split,
    load_tda_feature_table,
    subset_tda_feature_frame,
)
from .models import build_model
from .runner import (
    RunnerConfig,
    _run_train_valid_job,
    ensure_dir,
    evaluate,
    resolve_device,
    seed_everything,
)


@dataclass(frozen=True)
class EvalStressSpec:
    name: str
    corruption: str | None = None
    severity: int = 0
    downsample_size: int = 0
    missing_views: tuple[str, ...] = ()
    keep_only_views: tuple[str, ...] = ()
    mask_clinical: bool = False
    clinical_missing_fraction: float = 0.0
    clinical_drop_groups: tuple[str, ...] = ()
    clinical_noise_std: float = 0.0
    mask_tda: bool = False
    tda_dropout_fraction: float = 0.0
    tda_drop_views: tuple[str, ...] = ()
    tda_keep_homology: str = ""
    tda_noise_std: float = 0.0


@dataclass(frozen=True)
class TrainStressSpec:
    name: str
    low_shot_fraction: float = 1.0
    positive_patient_fraction: float = 1.0
    label_noise_fraction: float = 0.0


REQUESTED_LOW_SHOT_FRACTIONS = (0.80, 0.60, 0.40, 0.20, 0.10, 0.05)
REQUESTED_POSITIVE_PATIENT_FRACTIONS = (0.50, 0.25, 0.10, 0.05)
REQUESTED_LABEL_NOISE_FRACTIONS = (0.05, 0.10, 0.20, 0.30)
REQUESTED_RESOLUTION_LEVELS = (160, 128, 96, 64)
REQUESTED_CLINICAL_MISSING_FRACTIONS = (0.10, 0.20, 0.40, 0.60)
REQUESTED_TDA_DROPOUT_FRACTIONS = (0.10, 0.30, 0.50)


def _default_eval_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = [EvalStressSpec(name="clean")]

    for view in DEFAULT_VIEWS:
        specs.append(EvalStressSpec(name=f"missing_{view}", missing_views=(view,)))
    for view in DEFAULT_VIEWS:
        specs.append(EvalStressSpec(name=f"only_{view}", keep_only_views=(view,)))
    for pair in combinations(DEFAULT_VIEWS, 2):
        specs.append(EvalStressSpec(name=f"missing_{pair[0]}_{pair[1]}", missing_views=pair))

    specs.append(EvalStressSpec(name="missing_clinical", mask_clinical=True))
    specs.append(EvalStressSpec(name="clinical_noise_s1", clinical_noise_std=0.25))
    specs.append(EvalStressSpec(name="clinical_noise_s2", clinical_noise_std=0.50))
    specs.append(EvalStressSpec(name="clinical_noise_s3", clinical_noise_std=1.00))
    specs.append(EvalStressSpec(name="missing_tda", mask_tda=True))
    specs.append(EvalStressSpec(name="tda_noise_s1", tda_noise_std=0.25))
    specs.append(EvalStressSpec(name="tda_noise_s2", tda_noise_std=0.50))
    specs.append(EvalStressSpec(name="tda_noise_s3", tda_noise_std=1.00))

    corruption_names = (
        "gaussian_noise",
        "gaussian_blur",
        "jpeg",
        "brightness",
        "contrast",
        "hue_shift",
        "cutout",
        "affine",
    )
    for corruption in corruption_names:
        for severity in (1, 2, 3):
            specs.append(EvalStressSpec(name=f"{corruption}_s{severity}", corruption=corruption, severity=severity))
    return specs


def _default_train_suite() -> list[TrainStressSpec]:
    specs: list[TrainStressSpec] = []
    for fraction in REQUESTED_LOW_SHOT_FRACTIONS:
        specs.append(TrainStressSpec(name=f"low_shot_{int(fraction * 100):02d}", low_shot_fraction=fraction))
    for fraction in REQUESTED_POSITIVE_PATIENT_FRACTIONS:
        specs.append(
            TrainStressSpec(
                name=f"positive_patient_retention_{int(fraction * 100):02d}",
                positive_patient_fraction=fraction,
            )
        )
    for fraction in REQUESTED_LABEL_NOISE_FRACTIONS:
        specs.append(TrainStressSpec(name=f"label_noise_{int(fraction * 100):02d}", label_noise_fraction=fraction))
    return specs


def build_requested_train_stress_suite() -> list[TrainStressSpec]:
    return _default_train_suite()


def build_requested_image_input_stress_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = [EvalStressSpec(name="clean")]
    for size in REQUESTED_RESOLUTION_LEVELS:
        specs.append(EvalStressSpec(name=f"resolution_{size}", downsample_size=size))
    for corruption in (
        "gaussian_blur",
        "gaussian_noise",
        "jpeg",
        "brightness",
        "contrast",
        "center_cutout",
        "eccentric_cutout",
        "rotation",
        "translation",
        "scale",
    ):
        for severity in (1, 2, 3):
            specs.append(EvalStressSpec(name=f"{corruption}_s{severity}", corruption=corruption, severity=severity))
    return specs


def build_requested_missing_view_stress_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = [EvalStressSpec(name="clean")]
    for view in DEFAULT_VIEWS:
        specs.append(EvalStressSpec(name=f"missing_{view}", missing_views=(view,)))
    for pair in combinations(DEFAULT_VIEWS, 2):
        specs.append(EvalStressSpec(name=f"missing_{pair[0]}_{pair[1]}", missing_views=pair))
    for view in DEFAULT_VIEWS:
        specs.append(EvalStressSpec(name=f"only_{view}", keep_only_views=(view,)))
    return specs


def build_requested_clinical_modality_stress_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = [EvalStressSpec(name="clean")]
    for fraction in REQUESTED_CLINICAL_MISSING_FRACTIONS:
        specs.append(
            EvalStressSpec(
                name=f"clinical_missing_{int(fraction * 100):02d}",
                clinical_missing_fraction=fraction,
            )
        )
    for severity, noise_std in ((1, 0.25), (2, 0.50), (3, 1.00)):
        specs.append(EvalStressSpec(name=f"clinical_noise_s{severity}", clinical_noise_std=noise_std))
    for group_name in ("kmax", "pachy", "astigmatism"):
        specs.append(EvalStressSpec(name=f"clinical_drop_{group_name}", clinical_drop_groups=(group_name,)))
    return specs


def build_requested_tda_feature_stress_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = [EvalStressSpec(name="clean")]
    for fraction in REQUESTED_TDA_DROPOUT_FRACTIONS:
        specs.append(
            EvalStressSpec(
                name=f"tda_dropout_{int(fraction * 100):02d}",
                tda_dropout_fraction=fraction,
            )
        )
    for severity, noise_std in ((1, 0.25), (2, 0.50), (3, 1.00)):
        specs.append(EvalStressSpec(name=f"tda_noise_s{severity}", tda_noise_std=noise_std))
    for view in DEFAULT_VIEWS:
        specs.append(EvalStressSpec(name=f"tda_drop_{view}", tda_drop_views=(view,)))
    specs.append(EvalStressSpec(name="tda_h0_only", tda_keep_homology="h0"))
    specs.append(EvalStressSpec(name="tda_h1_only", tda_keep_homology="h1"))
    return specs


def build_requested_combo_train_stress_suite() -> list[TrainStressSpec]:
    return [
        TrainStressSpec(
            name="combo_low_shot_10_label_noise_10",
            low_shot_fraction=0.10,
            label_noise_fraction=0.10,
        )
    ]


def build_requested_combo_eval_suite() -> list[EvalStressSpec]:
    specs: list[EvalStressSpec] = []
    for view in DEFAULT_VIEWS:
        specs.append(
            EvalStressSpec(
                name=f"combo_res96_missing_{view}",
                downsample_size=96,
                missing_views=(view,),
            )
        )
    specs.append(
        EvalStressSpec(
            name="combo_clinical_missing40_tda_dropout30",
            clinical_missing_fraction=0.40,
            tda_dropout_fraction=0.30,
        )
    )
    return specs


def _jpeg_compress(image: Image.Image, quality: int) -> Image.Image:
    buffer = BytesIO()
    image.save(buffer, format="JPEG", quality=quality)
    buffer.seek(0)
    with Image.open(buffer) as reopened:
        rgb = reopened.convert("RGB")
    return rgb


class EvalCorruptionTransform:
    def __init__(
        self,
        image_size: int,
        corruption: str | None,
        severity: int,
        seed: int,
        downsample_size: int = 0,
    ) -> None:
        self.image_size = image_size
        self.corruption = corruption
        self.severity = severity
        self.downsample_size = downsample_size
        self.generator = torch.Generator().manual_seed(seed)
        self.normalize = lambda tensor: F.normalize(
            tensor,
            mean=(0.485, 0.456, 0.406),
            std=(0.229, 0.224, 0.225),
        )

    def __call__(self, image: Image.Image) -> torch.Tensor:
        image = F.resize(image, [self.image_size, self.image_size], interpolation=InterpolationMode.BICUBIC)
        if 0 < self.downsample_size < self.image_size:
            image = F.resize(image, [self.downsample_size, self.downsample_size], interpolation=InterpolationMode.BILINEAR)
            image = F.resize(image, [self.image_size, self.image_size], interpolation=InterpolationMode.BILINEAR)
        if self.corruption == "gaussian_blur":
            radius = {1: 0.8, 2: 1.6, 3: 2.4}[self.severity]
            image = image.filter(ImageFilter.GaussianBlur(radius=radius))
        elif self.corruption == "jpeg":
            quality = {1: 70, 2: 40, 3: 20}[self.severity]
            image = _jpeg_compress(image, quality=quality)

        tensor = F.to_tensor(image)
        if self.corruption == "gaussian_noise":
            sigma = {1: 0.04, 2: 0.08, 3: 0.12}[self.severity]
            noise = torch.randn(tensor.shape, generator=self.generator, dtype=tensor.dtype)
            tensor = (tensor + sigma * noise).clamp(0.0, 1.0)
        elif self.corruption == "brightness":
            factor = {1: 0.85, 2: 0.70, 3: 0.55}[self.severity]
            tensor = F.adjust_brightness(tensor, factor)
        elif self.corruption == "contrast":
            factor = {1: 0.85, 2: 0.70, 3: 0.55}[self.severity]
            tensor = F.adjust_contrast(tensor, factor)
        elif self.corruption == "hue_shift":
            hue_factor = {1: 0.02, 2: 0.05, 3: 0.08}[self.severity]
            tensor = F.adjust_hue(tensor, hue_factor)
        elif self.corruption in {"cutout", "center_cutout"}:
            frac = {1: 0.10, 2: 0.18, 3: 0.28}[self.severity]
            side = max(1, int(self.image_size * frac))
            start = (self.image_size - side) // 2
            tensor[:, start : start + side, start : start + side] = 0.0
        elif self.corruption == "eccentric_cutout":
            frac = {1: 0.10, 2: 0.18, 3: 0.28}[self.severity]
            side = max(1, int(self.image_size * frac))
            top = max(0, int(self.image_size * 0.18))
            left = max(0, int(self.image_size * 0.62) - side)
            tensor[:, top : top + side, left : left + side] = 0.0
        elif self.corruption in {"affine", "rotation"}:
            angle = {1: 2.0, 2: 4.0, 3: 6.0}[self.severity]
            tensor = F.affine(
                tensor,
                angle=angle,
                translate=[0, 0],
                scale=1.0,
                shear=[0.0, 0.0],
                interpolation=InterpolationMode.BILINEAR,
                fill=0.0,
            )
        elif self.corruption == "translation":
            translate_px = {1: 4, 2: 8, 3: 12}[self.severity]
            tensor = F.affine(
                tensor,
                angle=0.0,
                translate=[translate_px, translate_px],
                scale=1.0,
                shear=[0.0, 0.0],
                interpolation=InterpolationMode.BILINEAR,
                fill=0.0,
            )
        elif self.corruption == "scale":
            scale = {1: 0.95, 2: 0.90, 3: 0.85}[self.severity]
            tensor = F.affine(
                tensor,
                angle=0.0,
                translate=[0, 0],
                scale=scale,
                shear=[0.0, 0.0],
                interpolation=InterpolationMode.BILINEAR,
                fill=0.0,
            )
        return self.normalize(tensor)


def _missing_view_postprocess(
    views: tuple[str, ...],
    missing_views: tuple[str, ...] = (),
    keep_only_views: tuple[str, ...] = (),
) -> Callable[[torch.Tensor, pd.Series], torch.Tensor] | None:
    if not missing_views and not keep_only_views:
        return None

    missing_set = set(missing_views)
    keep_only_set = set(keep_only_views)

    def _postprocess(images: torch.Tensor, row: pd.Series) -> torch.Tensor:
        masked = images.clone()
        for index, view in enumerate(views):
            should_mask = False
            if keep_only_set:
                should_mask = view not in keep_only_set
            if view in missing_set:
                should_mask = True
            if should_mask:
                masked[index] = 0.0
        return masked

    return _postprocess


def _clinical_postprocess(
    *,
    mask_clinical: bool = False,
    clinical_missing_fraction: float = 0.0,
    clinical_drop_groups: tuple[str, ...] = (),
    clinical_noise_std: float = 0.0,
    seed: int = 0,
) -> Callable[[torch.Tensor, pd.Series], torch.Tensor] | None:
    if not mask_clinical and clinical_missing_fraction <= 0.0 and not clinical_drop_groups and clinical_noise_std <= 0.0:
        return None

    generator = torch.Generator().manual_seed(seed)
    numeric_dim = len(DEFAULT_NUMERIC_CLINICAL_COLUMNS)
    group_to_indices = {
        "astigmatism": (1, 2),
        "kmax": (3, 4),
        "pachy": (5, 6, 7, 8),
    }
    group_indices = sorted(
        {
            index
            for group_name in clinical_drop_groups
            for index in group_to_indices.get(group_name.lower(), ())
            if index < numeric_dim
        }
    )

    def _postprocess(clinical: torch.Tensor, row: pd.Series) -> torch.Tensor:
        updated = clinical.clone()
        if mask_clinical:
            updated.zero_()
            return updated
        if group_indices:
            updated[group_indices] = 0.0
        if clinical_missing_fraction > 0.0 and numeric_dim > 0:
            missing_mask = torch.rand((numeric_dim,), generator=generator, dtype=updated.dtype)
            updated[:numeric_dim] = updated[:numeric_dim] * (missing_mask >= clinical_missing_fraction).to(updated.dtype)
        if clinical_noise_std > 0.0:
            noise = torch.randn((numeric_dim,), generator=generator, dtype=updated.dtype)
            updated[:numeric_dim] = updated[:numeric_dim] + clinical_noise_std * noise
        return updated

    return _postprocess


def _tda_postprocess(
    *,
    mask_tda: bool = False,
    tda_dropout_fraction: float = 0.0,
    tda_drop_views: tuple[str, ...] = (),
    tda_keep_homology: str = "",
    tda_noise_std: float = 0.0,
    seed: int = 0,
    feature_columns: tuple[str, ...] = (),
) -> Callable[[torch.Tensor, pd.Series], torch.Tensor] | None:
    if (
        not mask_tda
        and tda_dropout_fraction <= 0.0
        and not tda_drop_views
        and not tda_keep_homology
        and tda_noise_std <= 0.0
    ):
        return None

    generator = torch.Generator().manual_seed(seed)
    drop_view_prefixes = tuple(f"{view.lower()}_" for view in tda_drop_views)
    view_drop_indices = [
        index for index, column in enumerate(feature_columns) if any(column.startswith(prefix) for prefix in drop_view_prefixes)
    ]
    keep_homology = tda_keep_homology.lower().strip()
    homology_keep_indices: list[int] | None = None
    if keep_homology in {"h0", "h1"}:
        token = f"_{keep_homology}"
        homology_keep_indices = [index for index, column in enumerate(feature_columns) if token in column]

    def _postprocess(tda: torch.Tensor, row: pd.Series) -> torch.Tensor:
        updated = tda.clone()
        if mask_tda:
            updated.zero_()
            return updated
        if view_drop_indices:
            updated[view_drop_indices] = 0.0
        if homology_keep_indices is not None:
            keep_mask = torch.zeros_like(updated)
            keep_mask[homology_keep_indices] = 1.0
            updated = updated * keep_mask
        if tda_dropout_fraction > 0.0:
            dropout_mask = torch.rand(updated.shape, generator=generator, dtype=updated.dtype)
            updated = updated * (dropout_mask >= tda_dropout_fraction).to(updated.dtype)
        if tda_noise_std > 0.0:
            noise = torch.randn(updated.shape, generator=generator, dtype=updated.dtype)
            updated = updated + tda_noise_std * noise
        return updated

    return _postprocess


def _infer_tda_dim_from_config(config_dict: dict[str, Any]) -> int:
    if not bool(config_dict.get("include_tda", False)):
        return 0
    features_csv = config_dict.get("tda_features_csv")
    if not features_csv:
        return 0
    project_dir = Path(config_dict.get("project_dir", "."))
    _, feature_columns = load_tda_feature_table(project_dir / features_csv)
    return len(feature_columns)


def _load_checkpoint(checkpoint_path: Path, device: torch.device) -> tuple[nn.Module, dict[str, Any]]:
    payload = torch.load(checkpoint_path, map_location=device)
    config_dict = dict(payload.get("config", {}))
    views = tuple(config_dict.get("views", DEFAULT_VIEWS))
    include_clinical = bool(config_dict.get("include_clinical", True))
    clinical_dim = int(payload.get("clinical_dim", len(DEFAULT_NUMERIC_CLINICAL_COLUMNS) + 1 if include_clinical else 0))
    tda_dim = int(payload.get("tda_dim", 0))
    if tda_dim <= 0:
        tda_dim = _infer_tda_dim_from_config(config_dict)
    model = build_model(
        model_name=config_dict.get("model_name", "deep_mv_fusion"),
        clinical_dim=clinical_dim,
        tda_dim=tda_dim,
        num_views=len(views),
        pretrained_backbone=bool(config_dict.get("pretrained_backbone", True)),
        token_dim=int(config_dict.get("token_dim", 384)),
        num_heads=int(config_dict.get("num_heads", 8)),
        num_layers=int(config_dict.get("num_layers", 3)),
        dropout=float(config_dict.get("dropout", 0.1)),
        freeze_backbone_epochs=int(config_dict.get("freeze_backbone_epochs", 1)),
    ).to(device)
    model.load_state_dict(payload["model_state_dict"])
    model.eval()
    return model, config_dict


def _build_eval_loader(
    *,
    project_dir: Path,
    valid_csv: Path,
    train_csv_for_stats: Path,
    image_size: int,
    batch_size: int,
    views: tuple[str, ...],
    include_clinical: bool,
    include_tda: bool,
    tda_features_csv: str,
    transform: Callable,
    sample_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None,
    clinical_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None,
    tda_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None,
) -> DataLoader:
    train_df = load_eye_split(train_csv_for_stats)
    stats = fit_clinical_stats(train_df, DEFAULT_NUMERIC_CLINICAL_COLUMNS)
    tda_feature_frame = None
    tda_feature_columns: tuple[str, ...] = ()
    tda_stats: dict[str, dict[str, float]] | None = None
    if include_tda:
        tda_feature_frame, feature_columns = load_tda_feature_table(project_dir / tda_features_csv)
        train_tda_subset = subset_tda_feature_frame(
            tda_feature_frame=tda_feature_frame,
            patient_eye_ids=train_df["patient_eye_id"].tolist(),
            feature_columns=feature_columns,
        )
        tda_feature_columns = tuple(feature_columns)
        tda_stats = fit_tda_stats(train_tda_subset, tda_feature_columns)
    dataset = OrbscanMultiviewDataset(
        valid_csv,
        image_size=image_size,
        views=views,
        clinical_stats=stats,
        include_clinical=include_clinical,
        tda_feature_frame=tda_feature_frame,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        include_tda=include_tda,
        transform=transform,
        sample_postprocess=sample_postprocess,
        clinical_postprocess=clinical_postprocess,
        tda_postprocess=tda_postprocess,
    )
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=False,
    )


def _load_clean_reference_metrics(history_path: Path) -> dict[str, float]:
    if not history_path.exists():
        return {}
    data = json.loads(history_path.read_text(encoding="utf-8"))
    return dict(data.get("best_metrics", {}))


def _augment_with_retention(metrics: dict[str, float], clean_metrics: dict[str, float]) -> dict[str, float]:
    augmented = dict(metrics)
    for key in ("auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc", "recall"):
        clean_value = clean_metrics.get(key)
        current = metrics.get(key)
        if clean_value is None or current is None or clean_value == 0:
            continue
        augmented[f"{key}_retention"] = float(current / clean_value)
    return augmented


def run_eval_stress(
    *,
    config: RunnerConfig,
    checkpoint_path: str | Path,
    spec: EvalStressSpec,
    output_root: str | Path,
    resume_existing: bool = False,
    save_predictions: bool = True,
    train_csv: str | Path | None = None,
    valid_csv: str | Path | None = None,
    clean_history_path: str | Path | None = None,
) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = Path(output_root) / "eval_stress" / spec.name
    ensure_dir(output_dir)
    result_path = output_dir / "result.json"
    if resume_existing and result_path.exists():
        return json.loads(result_path.read_text(encoding="utf-8"))

    device = resolve_device(config.device)
    model, checkpoint_config = _load_checkpoint(Path(checkpoint_path), device=device)
    views = tuple(checkpoint_config.get("views", config.views))
    include_clinical = bool(checkpoint_config.get("include_clinical", config.include_clinical))
    include_tda = bool(checkpoint_config.get("include_tda", config.include_tda))
    tda_features_csv = str(checkpoint_config.get("tda_features_csv", config.tda_features_csv))
    tda_feature_columns: tuple[str, ...] = ()
    if include_tda:
        _, loaded_feature_columns = load_tda_feature_table(project_dir / tda_features_csv)
        tda_feature_columns = tuple(loaded_feature_columns)
    train_csv_path = Path(train_csv) if train_csv is not None else splits_dir / "development_eyes.csv"
    valid_csv_path = Path(valid_csv) if valid_csv is not None else splits_dir / "locked_test_eyes.csv"
    transform = EvalCorruptionTransform(
        image_size=int(checkpoint_config.get("image_size", config.image_size)),
        corruption=spec.corruption,
        severity=spec.severity,
        seed=config.seed + spec.severity,
        downsample_size=spec.downsample_size,
    )
    sample_postprocess = _missing_view_postprocess(
        views=views,
        missing_views=spec.missing_views,
        keep_only_views=spec.keep_only_views,
    )
    clinical_postprocess = _clinical_postprocess(
        mask_clinical=spec.mask_clinical,
        clinical_missing_fraction=spec.clinical_missing_fraction,
        clinical_drop_groups=spec.clinical_drop_groups,
        clinical_noise_std=spec.clinical_noise_std,
        seed=config.seed + 101 + spec.severity,
    )
    tda_postprocess = _tda_postprocess(
        mask_tda=spec.mask_tda,
        tda_dropout_fraction=spec.tda_dropout_fraction,
        tda_drop_views=spec.tda_drop_views,
        tda_keep_homology=spec.tda_keep_homology,
        tda_noise_std=spec.tda_noise_std,
        seed=config.seed + 151 + spec.severity,
        feature_columns=tda_feature_columns,
    )
    loader = _build_eval_loader(
        project_dir=project_dir,
        valid_csv=valid_csv_path,
        train_csv_for_stats=train_csv_path,
        image_size=int(checkpoint_config.get("image_size", config.image_size)),
        batch_size=config.batch_size,
        views=views,
        include_clinical=include_clinical,
        include_tda=include_tda,
        tda_features_csv=tda_features_csv,
        transform=transform,
        sample_postprocess=sample_postprocess,
        clinical_postprocess=clinical_postprocess,
        tda_postprocess=tda_postprocess,
    )

    train_df = load_eye_split(train_csv_path)
    positives = float((train_df["label"] == 1).sum())
    negatives = float((train_df["label"] == 0).sum())
    pos_weight = negatives / positives if positives > 0 else 1.0
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([pos_weight], device=device))
    metrics, predictions = evaluate(
        model=model,
        loader=loader,
        criterion=criterion,
        device=device,
        amp=config.amp,
        max_batches=config.max_val_batches,
    )
    clean_history = Path(clean_history_path) if clean_history_path is not None else Path(checkpoint_path).with_name("history.json")
    clean_metrics = _load_clean_reference_metrics(clean_history)
    metrics = _augment_with_retention(metrics, clean_metrics)
    result = {
        "stress_type": "eval_stress",
        "spec": asdict(spec),
        "checkpoint_path": str(checkpoint_path),
        "train_csv_for_stats": str(train_csv_path),
        "valid_csv": str(valid_csv_path),
        "clean_history_path": str(clean_history),
        "metrics": metrics,
    }
    if save_predictions:
        predictions.to_csv(output_dir / "predictions.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "result.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def _derive_patient_profiles(dataframe: pd.DataFrame) -> pd.DataFrame:
    grouped = dataframe.groupby("patient_code")["label"].agg(["count", "sum"]).reset_index()
    grouped = grouped.rename(columns={"count": "n_eyes", "sum": "n_positive_eyes"})
    grouped["n_negative_eyes"] = grouped["n_eyes"] - grouped["n_positive_eyes"]

    def _profile(row: pd.Series) -> str:
        if int(row["n_eyes"]) == 1:
            return "single_kc" if int(row["n_positive_eyes"]) == 1 else "single_normal"
        if int(row["n_positive_eyes"]) == 0:
            return "bilateral_normal"
        if int(row["n_positive_eyes"]) == int(row["n_eyes"]):
            return "bilateral_kc"
        return "bilateral_mixed"

    grouped["patient_profile"] = grouped.apply(_profile, axis=1)
    return grouped


def _sample_patients_by_profile(
    profiles: pd.DataFrame,
    fraction: float,
    seed: int,
    eligible_mask: pd.Series | None = None,
) -> set[str]:
    rng = random.Random(seed)
    selected: set[str] = set()
    working = profiles if eligible_mask is None else profiles.loc[eligible_mask].copy()
    for _, group in working.groupby("patient_profile"):
        patient_codes = group["patient_code"].tolist()
        rng.shuffle(patient_codes)
        keep = max(1, int(round(len(patient_codes) * fraction)))
        selected.update(patient_codes[:keep])
    return selected


def _apply_low_shot(dataframe: pd.DataFrame, fraction: float, seed: int) -> pd.DataFrame:
    if fraction >= 1.0:
        return dataframe.copy()
    profiles = _derive_patient_profiles(dataframe)
    selected_patients = _sample_patients_by_profile(profiles, fraction=fraction, seed=seed)
    return dataframe[dataframe["patient_code"].isin(selected_patients)].reset_index(drop=True)


def _apply_positive_patient_retention(dataframe: pd.DataFrame, fraction: float, seed: int) -> pd.DataFrame:
    if fraction >= 1.0:
        return dataframe.copy()
    profiles = _derive_patient_profiles(dataframe)
    positive_mask = profiles["n_positive_eyes"] > 0
    negative_patients = set(profiles.loc[~positive_mask, "patient_code"].tolist())
    retained_positive_patients = _sample_patients_by_profile(
        profiles=profiles,
        fraction=fraction,
        seed=seed,
        eligible_mask=positive_mask,
    )
    keep_patients = negative_patients | retained_positive_patients
    return dataframe[dataframe["patient_code"].isin(keep_patients)].reset_index(drop=True)


def _apply_label_noise(dataframe: pd.DataFrame, fraction: float, seed: int) -> pd.DataFrame:
    if fraction <= 0.0:
        return dataframe.copy()
    rng = random.Random(seed)
    noisy = dataframe.copy().reset_index(drop=True)
    indices = list(range(len(noisy)))
    rng.shuffle(indices)
    num_flip = max(1, int(round(len(indices) * fraction)))
    flip_indices = indices[:num_flip]
    noisy.loc[flip_indices, "label"] = 1 - noisy.loc[flip_indices, "label"].astype(int)
    noisy.loc[flip_indices, "label_text"] = noisy.loc[flip_indices, "label"].map({0: "normal", 1: "keratoconus"})
    return noisy


def _prepare_train_stress_split(
    base_train_csv: Path,
    spec: TrainStressSpec,
    seed: int,
) -> pd.DataFrame:
    train_df = load_eye_split(base_train_csv)
    stressed = _apply_low_shot(train_df, fraction=spec.low_shot_fraction, seed=seed + 11)
    stressed = _apply_positive_patient_retention(stressed, fraction=spec.positive_patient_fraction, seed=seed + 23)
    stressed = _apply_label_noise(stressed, fraction=spec.label_noise_fraction, seed=seed + 37)
    return stressed.reset_index(drop=True)


def run_train_stress(
    *,
    config: RunnerConfig,
    spec: TrainStressSpec,
    output_root: str | Path,
    resume_existing: bool = False,
    persist_stressed_split: bool = True,
    save_checkpoint: bool = True,
    save_predictions: bool = True,
    base_train_csv: str | Path | None = None,
    valid_csv: str | Path | None = None,
    clean_history_path: str | Path | None = None,
    fixed_selected_epoch: int | None = None,
    extra_meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = Path(output_root) / "train_stress" / spec.name
    ensure_dir(output_dir)
    history_path = output_dir / "history.json"
    if resume_existing and history_path.exists():
        return json.loads(history_path.read_text(encoding="utf-8"))

    base_train_csv_path = Path(base_train_csv) if base_train_csv is not None else splits_dir / "development_eyes.csv"
    valid_csv_path = Path(valid_csv) if valid_csv is not None else splits_dir / "locked_test_eyes.csv"
    stressed_train_df = _prepare_train_stress_split(base_train_csv_path, spec=spec, seed=config.seed)
    stressed_train_csv = output_dir / ("stressed_train_split.csv" if persist_stressed_split else "__tmp_stressed_train_split.csv")
    stressed_train_df.to_csv(stressed_train_csv, index=False, encoding="utf-8-sig")

    seed_everything(config.seed + 700)
    stress_config = RunnerConfig(**asdict(config))
    selected_epoch = fixed_selected_epoch
    if selected_epoch is None and stress_config.locked_selected_epoch is not None and stress_config.locked_selected_epoch > 0:
        selected_epoch = int(stress_config.locked_selected_epoch)
    if selected_epoch is not None and selected_epoch > 0:
        stress_config.epochs = int(selected_epoch)
        select_best_epoch = False
        selection_policy = "fixed_reference_epoch"
    else:
        select_best_epoch = True
        selection_policy = stress_config.selection_policy

    meta = {
        "stress_type": "train_stress",
        "spec": asdict(spec),
        "base_train_csv": str(base_train_csv_path),
        "selection_policy": selection_policy,
    }
    if extra_meta:
        meta.update(extra_meta)

    result = _run_train_valid_job(
        config=stress_config,
        train_csv=stressed_train_csv,
        valid_csv=valid_csv_path,
        output_dir=output_dir,
        meta=meta,
        select_best_epoch=select_best_epoch,
        save_checkpoint=save_checkpoint,
        save_predictions=save_predictions,
    )
    result["stressed_train_csv"] = str(stressed_train_csv)
    result["valid_csv"] = str(valid_csv_path)
    if not persist_stressed_split and stressed_train_csv.exists():
        stressed_train_csv.unlink()
    clean_metrics = {}
    clean_history_value = clean_history_path if clean_history_path is not None else config.clean_reference_history
    if clean_history_value:
        clean_history = Path(clean_history_value)
        clean_metrics = _load_clean_reference_metrics(clean_history)
    if result.get("best_metrics") and clean_metrics:
        result["best_metrics"] = _augment_with_retention(result["best_metrics"], clean_metrics)
        with (output_dir / "history.json").open("w", encoding="utf-8") as fp:
            json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_eval_stress_suite(
    *,
    config: RunnerConfig,
    checkpoint_path: str | Path,
    output_root: str | Path,
    max_conditions: int = -1,
    specs: list[EvalStressSpec] | None = None,
    resume_existing: bool = False,
    save_predictions: bool = True,
) -> dict[str, Any]:
    specs = list(specs or _default_eval_suite())
    if max_conditions > 0:
        specs = specs[:max_conditions]
    results = [
        run_eval_stress(
            config=config,
            checkpoint_path=checkpoint_path,
            spec=spec,
            output_root=output_root,
            resume_existing=resume_existing,
            save_predictions=save_predictions,
        )
        for spec in specs
    ]
    summary = {
        "suite_name": "default_eval_suite",
        "num_conditions": len(results),
        "results": results,
    }
    output_dir = Path(output_root)
    ensure_dir(output_dir)
    pd.DataFrame(
        [{"name": item["spec"]["name"], **item["metrics"]} for item in results]
    ).to_csv(output_dir / "eval_stress_summary.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "eval_stress_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def run_train_stress_suite(
    *,
    config: RunnerConfig,
    output_root: str | Path,
    max_conditions: int = -1,
    specs: list[TrainStressSpec] | None = None,
    resume_existing: bool = False,
    persist_stressed_split: bool = True,
    save_checkpoint: bool = True,
    save_predictions: bool = True,
) -> dict[str, Any]:
    specs = list(specs or _default_train_suite())
    if max_conditions > 0:
        specs = specs[:max_conditions]
    results = [
        run_train_stress(
            config=config,
            spec=spec,
            output_root=output_root,
            resume_existing=resume_existing,
            persist_stressed_split=persist_stressed_split,
            save_checkpoint=save_checkpoint,
            save_predictions=save_predictions,
        )
        for spec in specs
    ]
    summary = {
        "suite_name": "default_train_suite",
        "num_conditions": len(results),
        "results": results,
    }
    output_dir = Path(output_root)
    ensure_dir(output_dir)
    pd.DataFrame(
        [{"name": item["spec"]["name"], **item["best_metrics"]} for item in results]
    ).to_csv(output_dir / "train_stress_summary.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "train_stress_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary
