from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterable, Sequence

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms


DEFAULT_VIEWS = ("anterior", "posterior", "axial", "pachymetry")
DEFAULT_NUMERIC_CLINICAL_COLUMNS = (
    "age_years",
    "astig_value_D",
    "astig_axis_deg",
    "kmax_value_D",
    "kmax_axis_deg",
    "pachy_central_um",
    "pachy_thinnest_um",
    "pachy_thinnest_x",
    "pachy_thinnest_y",
    "asphericity_anterior",
    "asphericity_posterior",
)
DEFAULT_TDA_METADATA_COLUMNS = {
    "patient_eye_id",
    "patient_code",
    "eye",
    "label",
    "label_text",
    "gender",
    "age_years",
    "kmax_value_D",
    "pachy_thinnest_um",
    "had_duplicate_rows",
    "had_conflicting_clinical_values",
}


def load_eye_split(split_csv: str | Path) -> pd.DataFrame:
    return pd.read_csv(split_csv)


def infer_tda_feature_columns(
    dataframe: pd.DataFrame,
    views: Sequence[str] = DEFAULT_VIEWS,
) -> list[str]:
    return [
        column
        for column in dataframe.columns
        if column not in DEFAULT_TDA_METADATA_COLUMNS and any(column.startswith(f"{view}_") for view in views)
    ]


def load_tda_feature_table(features_csv: str | Path) -> tuple[pd.DataFrame, list[str]]:
    dataframe = pd.read_csv(features_csv)
    feature_columns = infer_tda_feature_columns(dataframe)
    if not feature_columns:
        raise ValueError(f"No TDA feature columns found in {features_csv}.")
    return dataframe, feature_columns


def fit_numeric_feature_stats(
    dataframe: pd.DataFrame,
    numeric_columns: Sequence[str],
) -> dict[str, dict[str, float]]:
    stats: dict[str, dict[str, float]] = {}
    for column in numeric_columns:
        values = pd.to_numeric(dataframe[column], errors="coerce")
        mean = float(values.mean())
        std = float(values.std(ddof=0))
        stats[column] = {"mean": mean, "std": std if std > 0 else 1.0}
    return stats


def fit_clinical_stats(
    dataframe: pd.DataFrame,
    numeric_columns: Sequence[str] = DEFAULT_NUMERIC_CLINICAL_COLUMNS,
) -> dict[str, dict[str, float]]:
    return fit_numeric_feature_stats(dataframe, numeric_columns)


def fit_tda_stats(
    dataframe: pd.DataFrame,
    feature_columns: Sequence[str],
) -> dict[str, dict[str, float]]:
    return fit_numeric_feature_stats(dataframe, feature_columns)


def subset_tda_feature_frame(
    tda_feature_frame: pd.DataFrame,
    patient_eye_ids: Sequence[str],
    feature_columns: Sequence[str],
) -> pd.DataFrame:
    subset = pd.DataFrame({"patient_eye_id": list(patient_eye_ids)})
    merged = subset.merge(
        tda_feature_frame[["patient_eye_id", *feature_columns]],
        on="patient_eye_id",
        how="left",
        validate="one_to_one",
    )
    if merged.loc[:, feature_columns].isnull().any().any():
        missing = merged[merged.loc[:, feature_columns].isnull().any(axis=1)]["patient_eye_id"].tolist()
        raise ValueError(f"Missing TDA features for samples: {missing[:5]}")
    return merged


def standardize_feature_frame(
    dataframe: pd.DataFrame,
    feature_columns: Sequence[str],
    feature_stats: dict[str, dict[str, float]] | None = None,
) -> np.ndarray:
    values = dataframe.loc[:, feature_columns].replace([np.inf, -np.inf], np.nan)
    values = values.apply(pd.to_numeric, errors="coerce")
    array = values.to_numpy(dtype=np.float32)
    if feature_stats:
        means = np.asarray([feature_stats[column]["mean"] for column in feature_columns], dtype=np.float32)
        stds = np.asarray([feature_stats[column]["std"] for column in feature_columns], dtype=np.float32)
        array = (array - means) / stds
    return np.nan_to_num(array, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


class OrbscanMultiviewDataset(Dataset):
    """Eye-level dataset backed by the precomputed strict-CV split CSVs."""

    def __init__(
        self,
        split_csv: str | Path,
        image_size: int = 224,
        views: Iterable[str] = DEFAULT_VIEWS,
        clinical_stats: dict[str, dict[str, float]] | None = None,
        numeric_clinical_columns: Sequence[str] = DEFAULT_NUMERIC_CLINICAL_COLUMNS,
        include_clinical: bool = True,
        transform: Callable | None = None,
        sample_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None = None,
        clinical_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None = None,
        tda_feature_frame: pd.DataFrame | None = None,
        tda_feature_columns: Sequence[str] = (),
        tda_stats: dict[str, dict[str, float]] | None = None,
        include_tda: bool = False,
        tda_postprocess: Callable[[torch.Tensor, pd.Series], torch.Tensor] | None = None,
    ) -> None:
        self.split_csv = Path(split_csv)
        self.dataframe = load_eye_split(self.split_csv).reset_index(drop=True)
        self.views = tuple(views)
        self.clinical_stats = clinical_stats or {}
        self.numeric_clinical_columns = tuple(numeric_clinical_columns)
        self.include_clinical = include_clinical
        self.include_tda = include_tda
        self.sample_postprocess = sample_postprocess
        self.clinical_postprocess = clinical_postprocess
        self.tda_postprocess = tda_postprocess
        self.transform = transform or transforms.Compose(
            [
                transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.BICUBIC),
                transforms.ToTensor(),
                transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
            ]
        )
        self.tda_feature_columns = tuple(tda_feature_columns)
        self.tda_array: np.ndarray | None = None
        if self.include_tda:
            if tda_feature_frame is None or not self.tda_feature_columns:
                raise ValueError("TDA feature frame and columns are required when include_tda=True.")
            tda_subset = subset_tda_feature_frame(
                tda_feature_frame=tda_feature_frame,
                patient_eye_ids=self.dataframe["patient_eye_id"].tolist(),
                feature_columns=self.tda_feature_columns,
            )
            self.tda_array = standardize_feature_frame(
                dataframe=tda_subset,
                feature_columns=self.tda_feature_columns,
                feature_stats=tda_stats,
            )

    def __len__(self) -> int:
        return len(self.dataframe)

    def _load_view(self, row: pd.Series, view: str) -> torch.Tensor:
        path = Path(row[f"image_{view}_path"])
        with Image.open(path) as image:
            rgb = image.convert("RGB")
        return self.transform(rgb)

    def _encode_gender(self, value: object) -> float:
        if value is None:
            return 0.0
        text = str(value).strip().lower()
        return 1.0 if text == "m" else 0.0

    def _clinical_tensor(self, row: pd.Series) -> torch.Tensor:
        values: list[float] = []
        for column in self.numeric_clinical_columns:
            value = float(pd.to_numeric(row[column], errors="coerce"))
            if column in self.clinical_stats:
                mean = self.clinical_stats[column]["mean"]
                std = self.clinical_stats[column]["std"]
                value = (value - mean) / std
            values.append(value)
        values.append(self._encode_gender(row.get("gender")))
        return torch.nan_to_num(torch.tensor(values, dtype=torch.float32), nan=0.0, posinf=0.0, neginf=0.0)

    def __getitem__(self, index: int) -> dict[str, object]:
        row = self.dataframe.iloc[index]
        images = torch.stack([self._load_view(row, view) for view in self.views], dim=0)
        if self.sample_postprocess is not None:
            images = self.sample_postprocess(images, row)
        item: dict[str, object] = {
            "images": images,
            "label": torch.tensor(float(row["label"]), dtype=torch.float32),
            "patient_eye_id": row["patient_eye_id"],
            "patient_code": row["patient_code"],
            "eye": row["eye"],
        }
        if self.include_clinical:
            clinical = self._clinical_tensor(row)
            if self.clinical_postprocess is not None:
                clinical = self.clinical_postprocess(clinical, row)
            item["clinical"] = clinical
        if self.include_tda:
            if self.tda_array is None:
                raise RuntimeError("TDA array is not initialized.")
            tda = torch.from_numpy(self.tda_array[index].copy())
            if self.tda_postprocess is not None:
                tda = self.tda_postprocess(tda, row)
            item["tda"] = tda
        return item
