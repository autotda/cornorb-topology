from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from typing import Callable

import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .dataset import DEFAULT_NUMERIC_CLINICAL_COLUMNS
from .tda_baseline import compute_prediction_metrics


@dataclass
class ClinicalBaselineConfig:
    project_dir: str = "."
    splits_dir: str = "experiment_setup/splits"
    output_dir: str = "runs/clinical_only_logreg_v1"
    seed: int = 20260325
    c_grid: tuple[float, ...] = (0.01, 0.03, 0.1, 0.3, 1.0)
    l1_ratio_grid: tuple[float, ...] = (0.0,)
    max_iter: int = 4000
    use_class_weight: bool = True
    resume_existing: bool = False


CLINICAL_FEATURE_COLUMNS = (*DEFAULT_NUMERIC_CLINICAL_COLUMNS, "gender_encoded")


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_existing_history(history_path: Path) -> dict[str, Any] | None:
    if not history_path.exists():
        return None
    with history_path.open("r", encoding="utf-8") as fp:
        return json.load(fp)


def _prepare_clinical_frame(dataframe: pd.DataFrame) -> pd.DataFrame:
    prepared = dataframe.copy()
    prepared["gender_encoded"] = (
        prepared["gender"].astype(str).str.strip().str.lower().map({"m": 1.0, "f": 0.0}).fillna(0.0)
    )
    return prepared


def _load_split(split_csv: Path) -> pd.DataFrame:
    return _prepare_clinical_frame(pd.read_csv(split_csv))


def _subset_from_inner_assignments(
    *,
    outer_train_df: pd.DataFrame,
    assignments_csv: Path,
    inner_fold: int,
    split_name: str,
) -> pd.DataFrame:
    assignments = pd.read_csv(assignments_csv)
    subset_ids = assignments[
        (assignments["inner_fold"] == inner_fold) & (assignments["split"] == split_name)
    ][["patient_eye_id"]]
    subset = subset_ids.merge(outer_train_df, on="patient_eye_id", how="left", validate="one_to_one")
    if subset["patient_code"].isnull().any():
        missing = subset[subset["patient_code"].isnull()]["patient_eye_id"].tolist()
        raise ValueError(f"Missing rows for inner split {split_name} fold {inner_fold}: {missing[:5]}")
    return subset


def _build_estimator(config: ClinicalBaselineConfig, *, C: float, l1_ratio: float) -> Pipeline:
    class_weight = "balanced" if config.use_class_weight else None
    if abs(l1_ratio) < 1e-12:
        penalty = "l2"
        solver = "lbfgs"
        logistic_kwargs = {}
    elif abs(l1_ratio - 1.0) < 1e-12:
        penalty = "l1"
        solver = "saga"
        logistic_kwargs = {}
    else:
        penalty = "elasticnet"
        solver = "saga"
        logistic_kwargs = {"l1_ratio": l1_ratio}

    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(
                    penalty=penalty,
                    solver=solver,
                    C=C,
                    class_weight=class_weight,
                    random_state=config.seed,
                    max_iter=config.max_iter,
                    **logistic_kwargs,
                ),
            ),
        ]
    )


def _fit_predict(
    estimator: Pipeline,
    train_df: pd.DataFrame,
    valid_df: pd.DataFrame,
    valid_frame_postprocess: Callable[[pd.DataFrame], pd.DataFrame] | None = None,
) -> tuple[pd.Series, dict[str, float]]:
    x_train = train_df.loc[:, CLINICAL_FEATURE_COLUMNS]
    y_train = train_df["label"].astype(int)
    x_valid = valid_df.loc[:, CLINICAL_FEATURE_COLUMNS].copy()
    if valid_frame_postprocess is not None:
        x_valid = valid_frame_postprocess(x_valid)
    y_valid = valid_df["label"].astype(int).reset_index(drop=True)

    estimator.fit(x_train, y_train)
    probabilities = pd.Series(estimator.predict_proba(x_valid)[:, 1], index=y_valid.index)
    metrics = compute_prediction_metrics(y_valid, probabilities)
    return probabilities, metrics


def tune_inner_cv(
    config: ClinicalBaselineConfig,
    *,
    repeat: int,
    outer_fold: int,
) -> tuple[dict[str, float], pd.DataFrame]:
    project_dir = Path(config.project_dir)
    outer_dir = project_dir / config.splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    outer_train_df = _load_split(outer_dir / "outer_train_eyes.csv")
    inner_assignments_csv = outer_dir / "inner_folds_eyes.csv"
    rows: list[dict[str, float]] = []

    for C in config.c_grid:
        for l1_ratio in config.l1_ratio_grid:
            for inner_fold in range(1, 5):
                train_df = _subset_from_inner_assignments(
                    outer_train_df=outer_train_df,
                    assignments_csv=inner_assignments_csv,
                    inner_fold=inner_fold,
                    split_name="inner_train",
                )
                valid_df = _subset_from_inner_assignments(
                    outer_train_df=outer_train_df,
                    assignments_csv=inner_assignments_csv,
                    inner_fold=inner_fold,
                    split_name="inner_valid",
                )
                estimator = _build_estimator(config, C=C, l1_ratio=l1_ratio)
                _, metrics = _fit_predict(estimator, train_df, valid_df)
                rows.append(
                    {
                        "repeat": repeat,
                        "outer_fold": outer_fold,
                        "inner_fold": inner_fold,
                        "C": C,
                        "l1_ratio": l1_ratio,
                        **metrics,
                    }
                )

    results_df = pd.DataFrame(rows)
    aggregate = (
        results_df.groupby(["C", "l1_ratio"], as_index=False)[["auroc", "auprc", "balanced_accuracy", "f1", "mcc"]]
        .mean()
        .sort_values(
            ["auroc", "auprc", "balanced_accuracy", "f1", "mcc", "C", "l1_ratio"],
            ascending=[False, False, False, False, False, True, True],
        )
        .reset_index(drop=True)
    )
    best_row = aggregate.iloc[0]
    best_params = {"C": float(best_row["C"]), "l1_ratio": float(best_row["l1_ratio"])}
    return best_params, results_df


def run_outer_fold(config: ClinicalBaselineConfig, *, repeat: int, outer_fold: int) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    output_dir = project_dir / config.output_dir / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    if config.resume_existing:
        existing = _load_existing_history(output_dir / "history.json")
        if existing is not None:
            return existing
    _ensure_dir(output_dir)

    outer_dir = project_dir / config.splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    train_df = _load_split(outer_dir / "outer_train_eyes.csv")
    valid_df = _load_split(outer_dir / "outer_valid_eyes.csv")

    best_params, inner_results_df = tune_inner_cv(config, repeat=repeat, outer_fold=outer_fold)
    inner_results_df.to_csv(output_dir / "inner_cv_results.csv", index=False, encoding="utf-8-sig")

    estimator = _build_estimator(config, C=best_params["C"], l1_ratio=best_params["l1_ratio"])
    probabilities, metrics = _fit_predict(estimator, train_df, valid_df)

    valid_predictions = valid_df[["patient_eye_id", "patient_code", "eye", "label"]].copy()
    valid_predictions["probability"] = probabilities
    valid_predictions.to_csv(output_dir / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        "repeat": repeat,
        "outer_fold": outer_fold,
        "outer_dir": str(outer_dir),
        "num_clinical_features": len(CLINICAL_FEATURE_COLUMNS),
        "feature_columns": list(CLINICAL_FEATURE_COLUMNS),
        "best_params": best_params,
        "best_metrics": metrics,
    }
    with (output_dir / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_fixed_split(
    config: ClinicalBaselineConfig,
    *,
    train_csv: str | Path,
    valid_csv: str | Path,
    C: float,
    l1_ratio: float,
    output_dir: str | Path,
    split_name: str,
    meta: dict[str, Any] | None = None,
    save_predictions: bool = True,
    valid_frame_postprocess: Callable[[pd.DataFrame], pd.DataFrame] | None = None,
) -> dict[str, Any]:
    train_path = Path(train_csv)
    valid_path = Path(valid_csv)
    output_path = Path(output_dir)
    _ensure_dir(output_path)

    train_df = _load_split(train_path)
    valid_df = _load_split(valid_path)
    estimator = _build_estimator(config, C=C, l1_ratio=l1_ratio)
    probabilities, metrics = _fit_predict(
        estimator,
        train_df,
        valid_df,
        valid_frame_postprocess=valid_frame_postprocess,
    )

    if save_predictions:
        valid_predictions = valid_df[["patient_eye_id", "patient_code", "eye", "label"]].copy()
        valid_predictions["probability"] = probabilities
        valid_predictions.to_csv(output_path / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        "split_name": split_name,
        "train_csv": str(train_path),
        "valid_csv": str(valid_path),
        "num_clinical_features": len(CLINICAL_FEATURE_COLUMNS),
        "feature_columns": list(CLINICAL_FEATURE_COLUMNS),
        "chosen_params": {"C": C, "l1_ratio": l1_ratio},
        "best_metrics": metrics,
        **(meta or {}),
    }
    with (output_path / "history.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def run_full_outer_cv(config: ClinicalBaselineConfig) -> dict[str, Any]:
    all_results: list[dict[str, Any]] = []
    for repeat in range(1, 4):
        for outer_fold in range(1, 6):
            all_results.append(run_outer_fold(config, repeat=repeat, outer_fold=outer_fold))

    metrics_df = pd.DataFrame(
        [
            {
                "repeat": result["repeat"],
                "outer_fold": result["outer_fold"],
                "C": result["best_params"]["C"],
                "l1_ratio": result["best_params"]["l1_ratio"],
                **result["best_metrics"],
            }
            for result in all_results
        ]
    )
    numeric_cols = [column for column in metrics_df.columns if column not in {"repeat", "outer_fold"}]
    summary = {
        "config": asdict(config),
        "feature_columns": list(CLINICAL_FEATURE_COLUMNS),
        "per_fold_metrics": metrics_df.to_dict(orient="records"),
        "aggregate": {
            column: {
                "mean": float(metrics_df[column].mean()),
                "std": float(metrics_df[column].std(ddof=0)),
            }
            for column in numeric_cols
        },
        "selected_params_frequency": (
            metrics_df.groupby(["C", "l1_ratio"])
            .size()
            .reset_index(name="count")
            .sort_values("count", ascending=False)
            .to_dict(orient="records")
        ),
    }
    output_dir = Path(config.project_dir) / config.output_dir
    _ensure_dir(output_dir)
    metrics_df.to_csv(output_dir / "outer_cv_metrics.csv", index=False, encoding="utf-8-sig")
    with (output_dir / "outer_cv_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def run_locked_test(
    config: ClinicalBaselineConfig,
    *,
    C: float,
    l1_ratio: float,
    save_predictions: bool = True,
) -> dict[str, Any]:
    project_dir = Path(config.project_dir)
    splits_dir = project_dir / config.splits_dir
    output_dir = project_dir / config.output_dir / "locked_test"
    return run_fixed_split(
        config,
        train_csv=splits_dir / "development_eyes.csv",
        valid_csv=splits_dir / "locked_test_eyes.csv",
        C=C,
        l1_ratio=l1_ratio,
        output_dir=output_dir,
        split_name="locked_test",
        save_predictions=save_predictions,
    )
