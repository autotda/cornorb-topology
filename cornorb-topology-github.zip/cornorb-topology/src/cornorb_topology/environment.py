from __future__ import annotations

import argparse
from importlib import metadata
import json
import platform


def main() -> int:
    argparse.ArgumentParser(description="Read dependency versions without modifying the environment.").parse_args()
    versions = {}
    for name in ("numpy", "pandas", "scipy", "scikit-learn", "torch", "torchvision", "Pillow", "matplotlib", "openpyxl", "giotto-tda", "gudhi", "homcloud"):
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = None
    warnings = []
    if versions["giotto-tda"] == "0.6.2" and versions["scikit-learn"] != "1.3.2":
        warnings.append("giotto-tda 0.6.2 declares scikit-learn==1.3.2; the installed combination differs.")
    if versions["numpy"] and int(versions["numpy"].split(".")[0]) >= 2:
        warnings.append("NumPy 2 is outside this release's conservative installation constraints; historical compatibility is not a clean-install guarantee.")
    print(json.dumps({"python": platform.python_version(), "versions": versions, "warnings": warnings}, indent=2))
    return 0
