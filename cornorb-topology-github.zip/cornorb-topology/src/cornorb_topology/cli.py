from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
import re
import sys
from typing import Any


WORKFLOWS = {
    "prepare-cornorb": ("data.prepare_cornorb", "Clean local CornOrb metadata and generate patient-level splits"),
    "prepare-kaggle": ("data.prepare_kaggle", "Prepare the independent Kaggle replication source"),
    "extract-tda": ("features.extract_cubical", "Extract CornOrb rendered-map cubical TDA features"),
    "extract-kaggle-tda": ("features.extract_kaggle", "Extract Kaggle TDA features using training-source vectorizers"),
    "train": ("training.strict_cv", "Image and multimodal patient-level CV or locked audit"),
    "clinical-cv": ("training.clinical_cv", "Clinical-only regularized logistic baseline"),
    "tda-cv": ("training.tda_cv", "TDA-only regularized logistic baseline"),
    "ablations": ("training.ablations", "Run the six primary modality configurations"),
    "clinical-lite": ("training.clinical_lite", "Remove strong diagnostic-proxy clinical features"),
    "kaggle-replication": ("training.kaggle_replication", "Kaggle-only training and independent-source evaluation"),
    "stress-cv": ("stress.strict_cv", "15-outer-fold stress testing with metrics-only storage and ETA"),
    "legacy-stress-progress": ("stress.progress", "Inspect the historical extreme-stress progress report"),
    "statistics": ("analysis.ablation_statistics", "Fold summaries, descriptive CIs, Wilcoxon and Holm adjustment"),
    "stress-tables": ("analysis.stress_tables", "Build the full strict-CV metric workbook"),
    "representatives": ("interpretability.homcloud", "HomCloud H1 optimal cycles/volumes and H0 localization"),
    "gudhi-localization": ("interpretability.gudhi", "Historical GUDHI birth/death-based localization"),
    "mask-crop": ("sensitivity.mask_crop", "TDA mask/crop sensitivity under the same CV splits"),
    "legacy-extreme-stress": ("legacy.extreme_stress", "Historical fixed-split extreme stress, not primary strict CV"),
    "legacy-stress": ("legacy.stress_benchmark", "Historical stress benchmark, not primary strict CV"),
    "legacy-stress-tables": ("legacy.stress_tables", "Historical fixed-split stress workbook"),
    "validate-splits": ("cornorb_topology.validation", "Audit patient/eye isolation and nested-CV coverage"),
    "doctor": ("cornorb_topology.environment", "Read dependency versions and report compatibility warnings"),
}


def module_name(command: str) -> str:
    target = WORKFLOWS[command][0]
    return target if target.startswith("cornorb_topology.") else f"cornorb_topology.workflows.{target}"


def load_config(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict) or set(payload) - {"command", "arguments"}:
        raise ValueError("Config must be an object containing only command and arguments.")
    if not isinstance(payload.get("command"), str) or payload["command"] not in WORKFLOWS:
        raise ValueError("Config command must name a supported workflow.")
    if not isinstance(payload.get("arguments", {}), dict):
        raise ValueError("Config arguments must be an object.")
    return payload


def config_arguments(arguments: dict[str, Any]) -> list[str]:
    result = []
    for key, value in arguments.items():
        if not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]*", key):
            raise ValueError("Config argument keys must be unprefixed long-option names.")
        option = "--" + key.replace("_", "-")
        if value is None or value is False:
            continue
        if value is True:
            result.append(option)
        elif isinstance(value, (str, int, float)):
            result.extend([option, str(value)])
        elif isinstance(value, list) and all(isinstance(item, (str, int, float)) and not isinstance(item, bool) for item in value):
            result.extend([option, *[str(item) for item in value]])
        else:
            raise ValueError(f"Unsupported config value for {key!r}.")
    return result


def main(argv: list[str] | None = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(
        prog="cornorb",
        usage="cornorb [COMMAND] [--config CONFIG] [--dry-run] [workflow options]",
        add_help=False,
        allow_abbrev=False,
        description="Rendered-map topology and multi-view keratoconus research workflows.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Workflows:\n" + "\n".join(f"  {name:24} {description}" for name, (_, description) in WORKFLOWS.items())
        + "\n\nUse cornorb COMMAND --help for workflow options. Config paths are relative to the current working directory.",
    )
    parser.add_argument("--config", type=Path, help="JSON workflow preset; explicit workflow options are applied last")
    parser.add_argument("--dry-run", action="store_true", help="Print the module and arguments without importing it or running experiments")
    if not raw or raw in (["--help"], ["-h"]):
        parser.print_help()
        return 0
    # Do not let an unknown workflow option's value become a positional command.
    explicit_command = raw.pop(0) if raw and not raw[0].startswith("-") else None
    if explicit_command and explicit_command not in WORKFLOWS:
        parser.error(f"Unknown workflow: {explicit_command}")
    args, forwarded = parser.parse_known_args(raw)
    try:
        preset = load_config(args.config) if args.config else None
        command = explicit_command or (preset["command"] if preset else None)
        if not command:
            parser.error("Provide a command or a --config preset.")
        if preset and preset["command"] != command:
            parser.error("The explicit command and preset command do not match.")
        workflow_args = config_arguments(preset.get("arguments", {})) if preset else []
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    workflow_args.extend(forwarded)
    target = module_name(command)
    if args.dry_run:
        print(json.dumps({"command": command, "module": target, "arguments": workflow_args}, indent=2))
        return 0

    try:
        workflow = importlib.import_module(target)
    except ModuleNotFoundError as exc:
        if exc.name and exc.name.startswith(("cornorb_topology", "orbscan_experiment")):
            raise
        parser.error(f"Missing dependency {exc.name!r}. Install the workflow dependencies documented in README.md.")
    old_argv = sys.argv
    try:
        sys.argv = [f"cornorb {command}", *workflow_args]
        return workflow.main() or 0
    finally:
        sys.argv = old_argv
