"""Experiment entry points, organized by workflow stage."""
