from __future__ import annotations

import argparse
import copy
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.feature_selection import VarianceThreshold
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.utils.data import DataLoader

from orbscan_experiment.dataset import (
    OrbscanMultiviewDataset,
    fit_tda_stats,
    infer_tda_feature_columns,
    subset_tda_feature_frame,
)
from orbscan_experiment.models import build_model
from orbscan_experiment.runner import (
    build_transforms,
    evaluate,
    resolve_device,
    seed_everything,
    train_one_epoch,
)
from orbscan_experiment.tda_baseline import compute_prediction_metrics
from cornorb_topology.workflows.data.prepare_kaggle import KAGGLE_VIEWS


@dataclass
class KaggleExternalConfig:
    split_dir: str = "experiment_setup/kaggle_replication"
    tda_features_csv: str = "runs/kaggle_replication_tda_v1/kaggle_cubical_tda_features.csv"
    output_dir: str = "runs/kaggle_replication_v1"
    image_size: int = 224
    batch_size: int = 8
    epochs: int = 12
    num_workers: int = 2
    learning_rate: float = 2e-4
    weight_decay: float = 1e-4
    seed: int = 20260507
    amp: bool = True
    device: str = "cuda"
    pretrained_backbone: bool = True
    token_dim: int = 384
    num_heads: int = 8
    num_layers: int = 3
    dropout: float = 0.1
    freeze_backbone_epochs: int = 1
    bootstrap_repeats: int = 1000
    tda_clip_value: float = 8.0


@dataclass
class ClipTensorPostprocess:
    clip_value: float

    def __call__(self, tensor: torch.Tensor, row: pd.Series) -> torch.Tensor:
        return torch.clamp(tensor, -self.clip_value, self.clip_value)


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _split_paths(split_dir: Path) -> dict[str, Path]:
    return {
        "train": split_dir / "train_binary.csv",
        "valid": split_dir / "valid_binary.csv",
        "development": split_dir / "development_binary.csv",
        "test": split_dir / "test_binary.csv",
        "suspect": split_dir / "test_suspect.csv",
    }


def _safe_metric_value(value: float) -> float:
    return float(value) if value is not None and not math.isnan(float(value)) else math.nan


def _bootstrap_ci(
    labels: pd.Series,
    probabilities: pd.Series,
    *,
    repeats: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    labels_np = labels.astype(int).to_numpy()
    probs_np = probabilities.astype(float).to_numpy()
    rows = []
    metric_names = [
        "auroc",
        "auprc",
        "accuracy",
        "balanced_accuracy",
        "f1",
        "precision",
        "recall",
        "specificity",
        "mcc",
    ]
    samples: dict[str, list[float]] = {name: [] for name in metric_names}
    n = len(labels_np)
    for _ in range(repeats):
        indices = rng.integers(0, n, size=n)
        if len(np.unique(labels_np[indices])) < 2:
            continue
        metrics = compute_prediction_metrics(pd.Series(labels_np[indices]), pd.Series(probs_np[indices]))
        for name in metric_names:
            value = metrics.get(name, math.nan)
            if not math.isnan(value):
                samples[name].append(float(value))
    point = compute_prediction_metrics(pd.Series(labels_np), pd.Series(probs_np))
    for name in metric_names:
        values = np.asarray(samples[name], dtype=np.float64)
        if len(values) == 0:
            lower = math.nan
            upper = math.nan
        else:
            lower = float(np.percentile(values, 2.5))
            upper = float(np.percentile(values, 97.5))
        rows.append(
            {
                "metric": name,
                "point": _safe_metric_value(point.get(name, math.nan)),
                "ci95_lower": lower,
                "ci95_upper": upper,
                "bootstrap_repeats_used": int(len(values)),
            }
        )
    return pd.DataFrame(rows)


def _summarize_suspect(probabilities: pd.Series) -> dict[str, float]:
    values = probabilities.astype(float)
    return {
        "n": int(len(values)),
        "prob_mean": float(values.mean()),
        "prob_std": float(values.std(ddof=0)),
        "prob_median": float(values.median()),
        "prob_q25": float(values.quantile(0.25)),
        "prob_q75": float(values.quantile(0.75)),
        "risk_ge_0_5": float((values >= 0.5).mean()),
        "risk_ge_0_8": float((values >= 0.8).mean()),
        "risk_le_0_2": float((values <= 0.2).mean()),
    }


def _load_tda_table(config: KaggleExternalConfig) -> tuple[pd.DataFrame, list[str]]:
    tda_df = pd.read_csv(config.tda_features_csv)
    feature_columns = infer_tda_feature_columns(tda_df, views=KAGGLE_VIEWS)
    if not feature_columns:
        raise ValueError(f"No Kaggle TDA features found in {config.tda_features_csv}")
    return tda_df, feature_columns


def _make_loader(
    split_csv: Path,
    *,
    config: KaggleExternalConfig,
    transform,
    include_tda: bool,
    tda_feature_frame: pd.DataFrame | None,
    tda_feature_columns: list[str],
    tda_stats: dict[str, dict[str, float]] | None,
    shuffle: bool,
) -> DataLoader:
    dataset = OrbscanMultiviewDataset(
        split_csv,
        image_size=config.image_size,
        views=KAGGLE_VIEWS,
        include_clinical=False,
        include_tda=include_tda,
        tda_feature_frame=tda_feature_frame,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        tda_postprocess=ClipTensorPostprocess(config.tda_clip_value) if include_tda else None,
        transform=transform,
    )
    return DataLoader(
        dataset,
        batch_size=config.batch_size,
        shuffle=shuffle,
        num_workers=config.num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=config.num_workers > 0,
    )


def _predict_loader(
    model: nn.Module,
    loader: DataLoader,
    *,
    device: torch.device,
    amp: bool,
) -> pd.DataFrame:
    model.eval()
    rows = []
    with torch.no_grad():
        for batch in loader:
            images = batch["images"].to(device, non_blocking=True)
            clinical = batch.get("clinical")
            if clinical is None:
                clinical_tensor = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
            else:
                clinical_tensor = clinical.to(device, non_blocking=True)
            tda = batch.get("tda")
            if tda is None:
                tda_tensor = torch.empty((images.size(0), 0), dtype=torch.float32, device=device)
            else:
                tda_tensor = tda.to(device, non_blocking=True)
            with torch.amp.autocast(device_type=device.type, enabled=amp and device.type == "cuda"):
                logits = model(images=images, clinical=clinical_tensor, tda=tda_tensor)
            probs = torch.sigmoid(logits).detach().cpu().numpy()
            labels = batch["label"].detach().cpu().numpy()
            for idx, probability in enumerate(probs):
                rows.append(
                    {
                        "patient_eye_id": batch["patient_eye_id"][idx],
                        "patient_code": batch["patient_code"][idx],
                        "eye": batch["eye"][idx],
                        "label": int(labels[idx]),
                        "probability": float(probability),
                        "prediction": int(probability >= 0.5),
                    }
                )
    return pd.DataFrame(rows)


def run_dl_arm(config: KaggleExternalConfig, *, arm_name: str, include_tda: bool) -> dict[str, Any]:
    seed_everything(config.seed + (11 if include_tda else 7))
    start = time.time()
    output_dir = Path(config.output_dir) / arm_name
    _ensure_dir(output_dir)
    split_paths = _split_paths(Path(config.split_dir))

    train_df = pd.read_csv(split_paths["train"])
    train_transform, valid_transform = build_transforms(config.image_size)

    tda_df = None
    tda_feature_columns: list[str] = []
    tda_stats = None
    if include_tda:
        tda_df, tda_feature_columns = _load_tda_table(config)
        train_tda_subset = subset_tda_feature_frame(
            tda_feature_frame=tda_df,
            patient_eye_ids=train_df["patient_eye_id"].tolist(),
            feature_columns=tda_feature_columns,
        )
        tda_stats = fit_tda_stats(train_tda_subset, tda_feature_columns)

    train_loader = _make_loader(
        split_paths["train"],
        config=config,
        transform=train_transform,
        include_tda=include_tda,
        tda_feature_frame=tda_df,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        shuffle=True,
    )
    valid_loader = _make_loader(
        split_paths["valid"],
        config=config,
        transform=valid_transform,
        include_tda=include_tda,
        tda_feature_frame=tda_df,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        shuffle=False,
    )
    test_loader = _make_loader(
        split_paths["test"],
        config=config,
        transform=valid_transform,
        include_tda=include_tda,
        tda_feature_frame=tda_df,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        shuffle=False,
    )
    suspect_loader = _make_loader(
        split_paths["suspect"],
        config=config,
        transform=valid_transform,
        include_tda=include_tda,
        tda_feature_frame=tda_df,
        tda_feature_columns=tda_feature_columns,
        tda_stats=tda_stats,
        shuffle=False,
    )

    positives = float((train_df["label"] == 1).sum())
    negatives = float((train_df["label"] == 0).sum())
    pos_weight = negatives / positives if positives > 0 else 1.0
    device = resolve_device(config.device)
    arm_amp = config.amp and not include_tda
    model = build_model(
        "deep_mv_tda_fusion" if include_tda else "deep_mv_fusion",
        clinical_dim=0,
        tda_dim=len(tda_feature_columns) if include_tda else 0,
        num_views=len(KAGGLE_VIEWS),
        pretrained_backbone=config.pretrained_backbone,
        token_dim=config.token_dim,
        num_heads=config.num_heads,
        num_layers=config.num_layers,
        dropout=config.dropout,
        freeze_backbone_epochs=config.freeze_backbone_epochs,
    ).to(device)
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(pos_weight, dtype=torch.float32, device=device))
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(config.epochs, 1))
    scaler = torch.amp.GradScaler("cuda", enabled=arm_amp and device.type == "cuda")

    best_score = -math.inf
    best_epoch = 0
    best_state = None
    history = []

    for epoch in range(1, config.epochs + 1):
        backbone_trainable = epoch > config.freeze_backbone_epochs
        if hasattr(model, "set_backbone_trainable"):
            model.set_backbone_trainable(backbone_trainable)
        train_loss = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
            scaler=scaler,
            amp=arm_amp,
            max_batches=-1,
        )
        valid_metrics, _ = evaluate(
            model=model,
            loader=valid_loader,
            criterion=criterion,
            device=device,
            amp=arm_amp,
            max_batches=-1,
        )
        scheduler.step()
        score = valid_metrics["auroc"] if not math.isnan(valid_metrics["auroc"]) else valid_metrics["auprc"]
        if score > best_score:
            best_score = score
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
        record = {
            "epoch": epoch,
            "train_loss": float(train_loss),
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
            "backbone_trainable": bool(backbone_trainable),
            **valid_metrics,
        }
        history.append(record)
        print(
            f"[{arm_name}] epoch {epoch}/{config.epochs} "
            f"val_auroc={valid_metrics['auroc']:.4f} val_f1={valid_metrics['f1']:.4f}",
            flush=True,
        )

    if best_state is not None:
        model.load_state_dict(best_state)

    test_metrics, test_predictions = evaluate(
        model=model,
        loader=test_loader,
        criterion=criterion,
        device=device,
        amp=arm_amp,
        max_batches=-1,
    )
    suspect_predictions = _predict_loader(model=model, loader=suspect_loader, device=device, amp=arm_amp)
    ci_df = _bootstrap_ci(
        test_predictions["label"],
        test_predictions["probability"],
        repeats=config.bootstrap_repeats,
        seed=config.seed + 101,
    )
    suspect_summary = _summarize_suspect(suspect_predictions["probability"])

    pd.DataFrame(history).to_csv(output_dir / "valid_history.csv", index=False, encoding="utf-8-sig")
    test_predictions.to_csv(output_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")
    suspect_predictions.to_csv(output_dir / "suspect_predictions.csv", index=False, encoding="utf-8-sig")
    ci_df.to_csv(output_dir / "test_metric_ci.csv", index=False, encoding="utf-8-sig")
    result = {
        "arm": arm_name,
        "type": "deep_multiview",
        "include_tda": include_tda,
        "device": str(device),
        "config": asdict(config),
        "best_epoch": int(best_epoch),
        "test_metrics": test_metrics,
        "test_metric_ci": ci_df.to_dict(orient="records"),
        "suspect_summary": suspect_summary,
        "elapsed_seconds": float(time.time() - start),
    }
    with (output_dir / "result.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def _build_tda_estimator(*, C: float, l1_ratio: float, seed: int) -> Pipeline:
    if abs(l1_ratio) < 1e-12:
        penalty = "l2"
        solver = "lbfgs"
        logistic_kwargs = {}
    elif abs(l1_ratio - 1.0) < 1e-12:
        penalty = "l1"
        solver = "saga"
        logistic_kwargs = {}
    else:
        penalty = "elasticnet"
        solver = "saga"
        logistic_kwargs = {"l1_ratio": l1_ratio}
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="constant", fill_value=0.0)),
            ("variance", VarianceThreshold()),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(
                    penalty=penalty,
                    solver=solver,
                    C=C,
                    l1_ratio=logistic_kwargs.get("l1_ratio"),
                    class_weight="balanced",
                    random_state=seed,
                    max_iter=4000,
                ),
            ),
        ]
    )


def _subset_features(
    split_csv: Path,
    tda_df: pd.DataFrame,
    feature_columns: list[str],
) -> pd.DataFrame:
    split_df = pd.read_csv(split_csv)
    merged = split_df[["patient_eye_id", "patient_code", "eye", "label"]].merge(
        tda_df[["patient_eye_id", *feature_columns]],
        on="patient_eye_id",
        how="left",
        validate="one_to_one",
    )
    if merged[feature_columns].isnull().any().any():
        missing = merged[merged[feature_columns].isnull().any(axis=1)]["patient_eye_id"].tolist()
        raise ValueError(f"Missing TDA features for samples: {missing[:5]}")
    return merged


def _predict_tda(
    estimator: Pipeline,
    dataframe: pd.DataFrame,
    feature_columns: list[str],
) -> pd.DataFrame:
    x = dataframe[feature_columns].replace([np.inf, -np.inf], np.nan).to_numpy(dtype=np.float32)
    probabilities = estimator.predict_proba(x)[:, 1]
    output = dataframe[["patient_eye_id", "patient_code", "eye", "label"]].copy()
    output["probability"] = probabilities
    output["prediction"] = (output["probability"] >= 0.5).astype(int)
    return output


def run_tda_only(config: KaggleExternalConfig) -> dict[str, Any]:
    seed_everything(config.seed + 3)
    start = time.time()
    output_dir = Path(config.output_dir) / "tda_only"
    _ensure_dir(output_dir)
    split_paths = _split_paths(Path(config.split_dir))
    tda_df, feature_columns = _load_tda_table(config)

    train_df = _subset_features(split_paths["train"], tda_df, feature_columns)
    valid_df = _subset_features(split_paths["valid"], tda_df, feature_columns)
    test_df = _subset_features(split_paths["test"], tda_df, feature_columns)
    suspect_df = _subset_features(split_paths["suspect"], tda_df, feature_columns)

    x_train = train_df[feature_columns].replace([np.inf, -np.inf], np.nan).to_numpy(dtype=np.float32)
    y_train = train_df["label"].astype(int).to_numpy()
    x_valid = valid_df[feature_columns].replace([np.inf, -np.inf], np.nan).to_numpy(dtype=np.float32)
    y_valid = valid_df["label"].astype(int).reset_index(drop=True)

    rows = []
    best_score = -math.inf
    best_params = {"C": 1.0, "l1_ratio": 0.0}
    for C in (0.03, 0.1, 0.3, 1.0):
        for l1_ratio in (0.0, 0.5, 1.0):
            estimator = _build_tda_estimator(C=C, l1_ratio=l1_ratio, seed=config.seed)
            estimator.fit(x_train, y_train)
            valid_prob = estimator.predict_proba(x_valid)[:, 1]
            valid_metrics = compute_prediction_metrics(y_valid, pd.Series(valid_prob))
            score = valid_metrics["auroc"] if not math.isnan(valid_metrics["auroc"]) else valid_metrics["auprc"]
            rows.append({"C": C, "l1_ratio": l1_ratio, **valid_metrics})
            if score > best_score:
                best_score = score
                best_params = {"C": float(C), "l1_ratio": float(l1_ratio)}
    pd.DataFrame(rows).to_csv(output_dir / "valid_grid_search.csv", index=False, encoding="utf-8-sig")

    estimator = _build_tda_estimator(C=best_params["C"], l1_ratio=best_params["l1_ratio"], seed=config.seed)
    estimator.fit(x_train, y_train)
    test_predictions = _predict_tda(estimator, test_df, feature_columns)
    suspect_predictions = _predict_tda(estimator, suspect_df, feature_columns)
    test_metrics = compute_prediction_metrics(test_predictions["label"], test_predictions["probability"])
    ci_df = _bootstrap_ci(
        test_predictions["label"],
        test_predictions["probability"],
        repeats=config.bootstrap_repeats,
        seed=config.seed + 103,
    )
    suspect_summary = _summarize_suspect(suspect_predictions["probability"])

    test_predictions.to_csv(output_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")
    suspect_predictions.to_csv(output_dir / "suspect_predictions.csv", index=False, encoding="utf-8-sig")
    ci_df.to_csv(output_dir / "test_metric_ci.csv", index=False, encoding="utf-8-sig")
    result = {
        "arm": "tda_only",
        "type": "logistic_regression",
        "config": asdict(config),
        "num_tda_features": int(len(feature_columns)),
        "best_params": best_params,
        "test_metrics": test_metrics,
        "test_metric_ci": ci_df.to_dict(orient="records"),
        "suspect_summary": suspect_summary,
        "elapsed_seconds": float(time.time() - start),
    }
    with (output_dir / "result.json").open("w", encoding="utf-8") as fp:
        json.dump(result, fp, ensure_ascii=False, indent=2)
    return result


def build_summary(output_dir: Path, results: list[dict[str, Any]]) -> None:
    rows = []
    ci_rows = []
    suspect_rows = []
    for result in results:
        arm = result["arm"]
        metric_row = {"arm": arm}
        metric_row.update(result["test_metrics"])
        rows.append(metric_row)
        for row in result["test_metric_ci"]:
            ci_rows.append({"arm": arm, **row})
        suspect_rows.append({"arm": arm, **result["suspect_summary"]})
    metrics_df = pd.DataFrame(rows)
    ci_df = pd.DataFrame(ci_rows)
    suspect_df = pd.DataFrame(suspect_rows)
    metrics_df.to_csv(output_dir / "independent_test_metrics.csv", index=False, encoding="utf-8-sig")
    ci_df.to_csv(output_dir / "independent_test_metric_ci.csv", index=False, encoding="utf-8-sig")
    suspect_df.to_csv(output_dir / "suspect_score_summary.csv", index=False, encoding="utf-8-sig")
    try:
        with pd.ExcelWriter(output_dir / "kaggle_replication_summary.xlsx") as writer:
            metrics_df.to_excel(writer, sheet_name="test_metrics", index=False)
            ci_df.to_excel(writer, sheet_name="test_metric_ci", index=False)
            suspect_df.to_excel(writer, sheet_name="suspect_scores", index=False)
    except Exception as exc:
        print(f"Excel summary was skipped: {exc}", flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Kaggle exploratory replication for image-only, TDA-only, and image+TDA.")
    parser.add_argument("--split-dir", default="experiment_setup/kaggle_replication")
    parser.add_argument("--tda-features-csv", default="runs/kaggle_replication_tda_v1/kaggle_cubical_tda_features.csv")
    parser.add_argument("--output-dir", default="runs/kaggle_replication_v1")
    parser.add_argument("--epochs", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--bootstrap-repeats", type=int, default=1000)
    parser.add_argument("--arms", nargs="+", default=["tda_only", "image_only", "image_tda"])
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = KaggleExternalConfig(
        split_dir=args.split_dir,
        tda_features_csv=args.tda_features_csv,
        output_dir=args.output_dir,
        epochs=args.epochs,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=args.device,
        bootstrap_repeats=args.bootstrap_repeats,
    )
    output_dir = Path(config.output_dir)
    _ensure_dir(output_dir)
    with (output_dir / "config.json").open("w", encoding="utf-8") as fp:
        json.dump(asdict(config), fp, ensure_ascii=False, indent=2)

    results = []
    if "tda_only" in args.arms:
        results.append(run_tda_only(config))
    if "image_only" in args.arms:
        results.append(run_dl_arm(config, arm_name="image_only", include_tda=False))
    if "image_tda" in args.arms:
        results.append(run_dl_arm(config, arm_name="image_tda", include_tda=True))
    build_summary(output_dir, results)
    print(json.dumps({"output_dir": str(output_dir.resolve()), "arms": [r["arm"] for r in results]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
