from __future__ import annotations

import argparse
import json

from orbscan_experiment.tda_baseline import TDABaselineConfig, run_full_outer_cv, run_locked_test, run_outer_fold


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Strict patient-level CV runner for the TDA-only baseline.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--features-csv", default="runs/cubical_tda_v1/cubical_tda_features.csv", help="TDA feature CSV.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Directory containing split CSVs.")
    parser.add_argument("--output-dir", default="runs/tda_only_logreg_v1", help="Directory for outputs.")
    parser.add_argument("--repeat", type=int, default=1, help="Outer repeat index (1-based).")
    parser.add_argument("--outer-fold", type=int, default=1, help="Outer fold index (1-based).")
    parser.add_argument("--run-scope", choices=["single-fold", "full-outer", "locked-test"], default="single-fold")
    parser.add_argument("--seed", type=int, default=20260321)
    parser.add_argument("--max-iter", type=int, default=4000)
    parser.add_argument("--c-grid", default="0.03,0.1,0.3,1.0", help="Comma-separated C grid.")
    parser.add_argument("--l1-grid", default="0.0,0.5,1.0", help="Comma-separated l1_ratio grid.")
    parser.add_argument("--no-class-weight", action="store_true")
    parser.add_argument("--locked-C", type=float, default=None, help="Fixed C for locked-test mode.")
    parser.add_argument("--locked-l1-ratio", type=float, default=None, help="Fixed l1_ratio for locked-test mode.")
    return parser.parse_args()


def _parse_float_grid(raw: str) -> tuple[float, ...]:
    return tuple(float(part.strip()) for part in raw.split(",") if part.strip())


def main() -> None:
    args = parse_args()
    config = TDABaselineConfig(
        project_dir=args.project_dir,
        features_csv=args.features_csv,
        splits_dir=args.splits_dir,
        output_dir=args.output_dir,
        seed=args.seed,
        c_grid=_parse_float_grid(args.c_grid),
        l1_ratio_grid=_parse_float_grid(args.l1_grid),
        max_iter=args.max_iter,
        use_class_weight=not args.no_class_weight,
    )

    if args.run_scope == "single-fold":
        result = run_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
    elif args.run_scope == "locked-test":
        if args.locked_C is None or args.locked_l1_ratio is None:
            raise ValueError("--locked-C and --locked-l1-ratio are required for locked-test mode.")
        result = run_locked_test(config, C=args.locked_C, l1_ratio=args.locked_l1_ratio)
    else:
        result = run_full_outer_cv(config)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
