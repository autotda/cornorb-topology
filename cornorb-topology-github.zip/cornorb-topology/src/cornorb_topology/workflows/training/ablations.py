from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from orbscan_experiment.clinical_baseline import ClinicalBaselineConfig, run_full_outer_cv as run_clinical_full_outer
from orbscan_experiment.clinical_baseline import run_outer_fold as run_clinical_outer_fold
from orbscan_experiment.runner import RunnerConfig, run_full_outer_cv as run_deep_full_outer
from orbscan_experiment.runner import run_outer_fold as run_deep_outer_fold
from orbscan_experiment.tda_baseline import TDABaselineConfig, run_full_outer_cv as run_tda_full_outer
from orbscan_experiment.tda_baseline import run_outer_fold as run_tda_outer_fold


ABLATION_GROUPS = (
    "image_only",
    "clinical_only",
    "tda_only",
    "image_clinical",
    "image_tda",
    "image_clinical_tda",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Unified six-way strict-CV ablation runner.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Directory containing split CSVs.")
    parser.add_argument("--output-root", default="runs/ablation_suite_v1", help="Root directory for all ablation outputs.")
    parser.add_argument(
        "--groups",
        default=",".join(ABLATION_GROUPS),
        help="Comma-separated ablation groups to run.",
    )
    parser.add_argument("--run-scope", choices=["single-fold", "full-outer"], default="full-outer")
    parser.add_argument("--repeat", type=int, default=1, help="Outer repeat index (1-based) for single-fold mode.")
    parser.add_argument("--outer-fold", type=int, default=1, help="Outer fold index (1-based) for single-fold mode.")
    parser.add_argument("--tda-features-csv", default="runs/cubical_tda_v1/cubical_tda_features.csv")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--token-dim", type=int, default=384)
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--num-layers", type=int, default=3)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--freeze-backbone-epochs", type=int, default=1)
    parser.add_argument("--selection-policy", choices=["nested_inner_cv", "legacy_outer_valid"], default="nested_inner_cv")
    parser.add_argument("--seed", type=int, default=20260325)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--max-train-batches", type=int, default=-1)
    parser.add_argument("--max-val-batches", type=int, default=-1)
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--max-iter", type=int, default=4000, help="Max iter for clinical/TDA logistic baselines.")
    parser.add_argument("--c-grid", default="0.01,0.03,0.1,0.3,1.0", help="Comma-separated C grid for clinical/TDA baselines.")
    parser.add_argument("--l1-grid", default="0.0", help="Comma-separated l1_ratio grid for clinical/TDA baselines.")
    parser.add_argument("--no-class-weight", action="store_true")
    parser.add_argument("--resume-existing", action="store_true", help="Skip already-completed folds/groups when history files exist.")
    return parser.parse_args()


def _parse_groups(raw: str) -> tuple[str, ...]:
    groups = tuple(part.strip().lower() for part in raw.split(",") if part.strip())
    invalid = [group for group in groups if group not in ABLATION_GROUPS]
    if invalid:
        raise ValueError(f"Unsupported ablation groups: {invalid}")
    return groups


def _parse_float_grid(raw: str) -> tuple[float, ...]:
    return tuple(float(part.strip()) for part in raw.split(",") if part.strip())


def _build_deep_config(args: argparse.Namespace, *, output_dir: str, include_clinical: bool, include_tda: bool) -> RunnerConfig:
    return RunnerConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=output_dir,
        model_name="deep_mv_tda_fusion" if include_tda else "deep_mv_fusion",
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        num_workers=args.num_workers,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        token_dim=args.token_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        dropout=args.dropout,
        freeze_backbone_epochs=args.freeze_backbone_epochs,
        include_clinical=include_clinical,
        include_tda=include_tda,
        tda_features_csv=args.tda_features_csv,
        selection_policy=args.selection_policy,
        pretrained_backbone=not args.no_pretrained,
        seed=args.seed,
        amp=not args.no_amp,
        device=args.device,
        max_train_batches=args.max_train_batches,
        max_val_batches=args.max_val_batches,
        resume_existing=args.resume_existing,
    )


def _build_clinical_config(args: argparse.Namespace, *, output_dir: str) -> ClinicalBaselineConfig:
    return ClinicalBaselineConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=output_dir,
        seed=args.seed,
        c_grid=_parse_float_grid(args.c_grid),
        l1_ratio_grid=_parse_float_grid(args.l1_grid),
        max_iter=args.max_iter,
        use_class_weight=not args.no_class_weight,
        resume_existing=args.resume_existing,
    )


def _build_tda_config(args: argparse.Namespace, *, output_dir: str) -> TDABaselineConfig:
    return TDABaselineConfig(
        project_dir=args.project_dir,
        features_csv=args.tda_features_csv,
        splits_dir=args.splits_dir,
        output_dir=output_dir,
        seed=args.seed,
        c_grid=_parse_float_grid(args.c_grid),
        l1_ratio_grid=_parse_float_grid(args.l1_grid),
        max_iter=args.max_iter,
        use_class_weight=not args.no_class_weight,
        resume_existing=args.resume_existing,
    )


def _run_single_group(args: argparse.Namespace, group: str) -> dict:
    output_dir = f"{args.output_root}/{group}"
    if group == "image_only":
        config = _build_deep_config(args, output_dir=output_dir, include_clinical=False, include_tda=False)
        result = (
            run_deep_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_deep_full_outer(config)
        )
        return {"group": group, "runner": "deep", "config": asdict(config), "result": result}
    if group == "image_clinical":
        config = _build_deep_config(args, output_dir=output_dir, include_clinical=True, include_tda=False)
        result = (
            run_deep_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_deep_full_outer(config)
        )
        return {"group": group, "runner": "deep", "config": asdict(config), "result": result}
    if group == "image_tda":
        config = _build_deep_config(args, output_dir=output_dir, include_clinical=False, include_tda=True)
        result = (
            run_deep_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_deep_full_outer(config)
        )
        return {"group": group, "runner": "deep", "config": asdict(config), "result": result}
    if group == "image_clinical_tda":
        config = _build_deep_config(args, output_dir=output_dir, include_clinical=True, include_tda=True)
        result = (
            run_deep_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_deep_full_outer(config)
        )
        return {"group": group, "runner": "deep", "config": asdict(config), "result": result}
    if group == "clinical_only":
        config = _build_clinical_config(args, output_dir=output_dir)
        result = (
            run_clinical_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_clinical_full_outer(config)
        )
        return {"group": group, "runner": "clinical_logreg", "config": asdict(config), "result": result}
    if group == "tda_only":
        config = _build_tda_config(args, output_dir=output_dir)
        result = (
            run_tda_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
            if args.run_scope == "single-fold"
            else run_tda_full_outer(config)
        )
        return {"group": group, "runner": "tda_logreg", "config": asdict(config), "result": result}
    raise ValueError(f"Unsupported group: {group}")


def _extract_primary_metrics(payload: dict) -> dict[str, float]:
    result = payload["result"]
    if "aggregate" in result:
        aggregate = result["aggregate"]
        return {
            key: aggregate[key]["mean"]
            for key in ("auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc")
            if key in aggregate
        }
    best_metrics = result.get("best_metrics", {})
    return {
        key: best_metrics[key]
        for key in ("auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc")
        if key in best_metrics
    }


def main() -> None:
    args = parse_args()
    groups = _parse_groups(args.groups)
    outputs = [_run_single_group(args, group) for group in groups]
    summary = {
        "run_scope": args.run_scope,
        "resume_existing": args.resume_existing,
        "groups": list(groups),
        "primary_metrics": {payload["group"]: _extract_primary_metrics(payload) for payload in outputs},
        "runs": outputs,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
