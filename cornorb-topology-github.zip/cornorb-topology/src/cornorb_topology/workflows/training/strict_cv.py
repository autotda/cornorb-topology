from __future__ import annotations

import argparse
import json

from orbscan_experiment.runner import RunnerConfig, run_full_outer_cv, run_locked_test, run_outer_fold


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Strict patient-level CV runner for Orbscan experiments.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Directory containing split CSVs.")
    parser.add_argument("--output-dir", default="runs/deep_mv_fusion", help="Directory for checkpoints and metrics.")
    parser.add_argument("--model-name", choices=["smoke_fusion", "deep_mv_fusion", "deep_mv_tda_fusion"], default="deep_mv_fusion")
    parser.add_argument("--tda-features-csv", default="runs/cubical_tda_v1/cubical_tda_features.csv", help="TDA feature CSV for fusion models.")
    parser.add_argument("--repeat", type=int, default=1, help="Outer repeat index (1-based).")
    parser.add_argument("--outer-fold", type=int, default=1, help="Outer fold index (1-based).")
    parser.add_argument("--run-scope", choices=["single-fold", "full-outer", "locked-test"], default="single-fold")
    parser.add_argument(
        "--selection-policy",
        choices=["nested_inner_cv", "legacy_outer_valid"],
        default="nested_inner_cv",
        help="How to choose the training epoch for outer-fold runs.",
    )
    parser.add_argument(
        "--locked-selected-epoch",
        type=int,
        default=None,
        help="Fixed epoch for strict locked-test evaluation after outer-CV selection.",
    )
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--token-dim", type=int, default=384)
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--num-layers", type=int, default=3)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--freeze-backbone-epochs", type=int, default=1)
    parser.add_argument("--no-clinical", action="store_true")
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--seed", type=int, default=20260320)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--max-train-batches", type=int, default=-1)
    parser.add_argument("--max-val-batches", type=int, default=-1)
    parser.add_argument("--no-amp", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = RunnerConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=args.output_dir,
        model_name=args.model_name,
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        num_workers=args.num_workers,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        token_dim=args.token_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        dropout=args.dropout,
        freeze_backbone_epochs=args.freeze_backbone_epochs,
        include_clinical=not args.no_clinical,
        include_tda=args.model_name == "deep_mv_tda_fusion",
        tda_features_csv=args.tda_features_csv,
        selection_policy=args.selection_policy,
        locked_selected_epoch=args.locked_selected_epoch,
        pretrained_backbone=not args.no_pretrained,
        seed=args.seed,
        amp=not args.no_amp,
        device=args.device,
        max_train_batches=args.max_train_batches,
        max_val_batches=args.max_val_batches,
    )

    if args.run_scope == "single-fold":
        result = run_outer_fold(config, repeat=args.repeat, outer_fold=args.outer_fold)
    elif args.run_scope == "locked-test":
        if args.selection_policy == "nested_inner_cv" and args.locked_selected_epoch is None:
            raise ValueError("--locked-selected-epoch is required for locked-test when --selection-policy nested_inner_cv.")
        result = run_locked_test(config)
    else:
        result = run_full_outer_cv(config)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
