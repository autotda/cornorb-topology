from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from orbscan_experiment.clinical_baseline import _prepare_clinical_frame, _subset_from_inner_assignments
from orbscan_experiment.tda_baseline import compute_prediction_metrics


CLINICAL_LITE_FEATURE_COLUMNS = (
    "age_years",
    "astig_value_D",
    "astig_axis_deg",
    "gender_encoded",
)

SUMMARY_METRICS = (
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "precision",
    "recall",
    "specificity",
    "mcc",
    "brier_score",
    "ece_10",
    "recall_at_95_specificity",
)

PAIRWISE_METRICS = ("auroc", "auprc", "balanced_accuracy", "f1", "mcc")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run a strict-CV clinical-lite baseline excluding strong diagnostic proxy variables "
            "(Kmax, pachymetry, and asphericity)."
        )
    )
    parser.add_argument("--project-dir", default=".")
    parser.add_argument("--splits-dir", default="experiment_setup/splits")
    parser.add_argument("--output-dir", default="runs/clinical_lite_strict_cv_v1")
    parser.add_argument("--reference-runs-root", default="runs/ablation_suite_v1")
    parser.add_argument("--seed", type=int, default=20260325)
    parser.add_argument("--c-grid", default="0.01,0.03,0.1,0.3,1.0")
    parser.add_argument("--max-iter", type=int, default=4000)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--resume-existing", action="store_true")
    return parser.parse_args()


def _parse_grid(raw: str) -> tuple[float, ...]:
    return tuple(float(part.strip()) for part in raw.split(",") if part.strip())


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_split(path: Path) -> pd.DataFrame:
    return _prepare_clinical_frame(pd.read_csv(path))


def _build_estimator(*, C: float, seed: int, max_iter: int) -> Pipeline:
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(
                    penalty="l2",
                    solver="lbfgs",
                    C=C,
                    class_weight="balanced",
                    random_state=seed,
                    max_iter=max_iter,
                ),
            ),
        ]
    )


def _fit_predict(
    estimator: Pipeline,
    train_df: pd.DataFrame,
    valid_df: pd.DataFrame,
) -> tuple[pd.Series, dict[str, float]]:
    x_train = train_df.loc[:, CLINICAL_LITE_FEATURE_COLUMNS]
    y_train = train_df["label"].astype(int)
    x_valid = valid_df.loc[:, CLINICAL_LITE_FEATURE_COLUMNS]
    y_valid = valid_df["label"].astype(int).reset_index(drop=True)
    estimator.fit(x_train, y_train)
    probabilities = pd.Series(estimator.predict_proba(x_valid)[:, 1], index=y_valid.index)
    return probabilities, compute_prediction_metrics(y_valid, probabilities)


def _select_inner_params(
    *,
    outer_train_df: pd.DataFrame,
    assignments_csv: Path,
    c_grid: Iterable[float],
    seed: int,
    max_iter: int,
) -> tuple[dict[str, float], pd.DataFrame]:
    rows: list[dict[str, float]] = []
    for C in c_grid:
        for inner_fold in range(1, 5):
            train_df = _subset_from_inner_assignments(
                outer_train_df=outer_train_df,
                assignments_csv=assignments_csv,
                inner_fold=inner_fold,
                split_name="inner_train",
            )
            valid_df = _subset_from_inner_assignments(
                outer_train_df=outer_train_df,
                assignments_csv=assignments_csv,
                inner_fold=inner_fold,
                split_name="inner_valid",
            )
            estimator = _build_estimator(C=C, seed=seed, max_iter=max_iter)
            _, metrics = _fit_predict(estimator, train_df, valid_df)
            rows.append({"inner_fold": inner_fold, "C": float(C), **metrics})
    results = pd.DataFrame(rows)
    aggregate = (
        results.groupby("C", as_index=False)[["auroc", "auprc", "balanced_accuracy", "f1", "mcc"]]
        .mean()
        .sort_values(["auroc", "auprc", "balanced_accuracy", "f1", "mcc", "C"], ascending=[False, False, False, False, False, True])
        .reset_index(drop=True)
    )
    best = aggregate.iloc[0]
    return {"C": float(best["C"]), "l1_ratio": 0.0}, results


def _run_fold(
    *,
    project_dir: Path,
    splits_dir: Path,
    output_dir: Path,
    repeat: int,
    outer_fold: int,
    c_grid: tuple[float, ...],
    seed: int,
    max_iter: int,
    resume_existing: bool,
) -> dict[str, object]:
    fold_output = output_dir / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    history_path = fold_output / "history.json"
    if resume_existing and history_path.exists():
        return json.loads(history_path.read_text(encoding="utf-8"))
    _ensure_dir(fold_output)

    outer_dir = project_dir / splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
    train_df = _load_split(outer_dir / "outer_train_eyes.csv")
    valid_df = _load_split(outer_dir / "outer_valid_eyes.csv")
    params, inner_results = _select_inner_params(
        outer_train_df=train_df,
        assignments_csv=outer_dir / "inner_folds_eyes.csv",
        c_grid=c_grid,
        seed=seed,
        max_iter=max_iter,
    )
    inner_results.to_csv(fold_output / "inner_cv_results.csv", index=False, encoding="utf-8-sig")

    estimator = _build_estimator(C=float(params["C"]), seed=seed, max_iter=max_iter)
    probabilities, metrics = _fit_predict(estimator, train_df, valid_df)
    predictions = valid_df[["patient_eye_id", "patient_code", "eye", "label"]].copy()
    predictions["probability"] = probabilities
    predictions.to_csv(fold_output / "val_predictions.csv", index=False, encoding="utf-8-sig")

    result = {
        "repeat": repeat,
        "outer_fold": outer_fold,
        "outer_dir": str(outer_dir),
        "num_clinical_features": len(CLINICAL_LITE_FEATURE_COLUMNS),
        "feature_columns": list(CLINICAL_LITE_FEATURE_COLUMNS),
        "excluded_proxy_groups": ["Kmax", "pachymetry", "asphericity"],
        "best_params": params,
        "best_metrics": metrics,
    }
    history_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def _bootstrap_mean_ci(values: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    if values.size == 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(n_boot, values.size))
    means = values[indices].mean(axis=1)
    lower, upper = np.quantile(means, [0.025, 0.975])
    return float(lower), float(upper)


def _format_metric(row: pd.Series) -> str:
    return f"{row['mean']:.4f} +/- {row['std']:.4f} [{row['ci95_low']:.4f}, {row['ci95_high']:.4f}]"


def _summarize_metrics(metrics_df: pd.DataFrame, *, n_boot: int, seed: int) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for metric in SUMMARY_METRICS:
        values = metrics_df[metric].to_numpy(dtype=float)
        ci_low, ci_high = _bootstrap_mean_ci(values, n_boot=n_boot, seed=seed)
        rows.append(
            {
                "group": "clinical_lite",
                "metric": metric,
                "n_folds": int(values.size),
                "mean": float(values.mean()),
                "std": float(values.std(ddof=0)),
                "ci95_low": ci_low,
                "ci95_high": ci_high,
            }
        )
    return pd.DataFrame(rows)


def _build_pairwise(
    clinical_lite_df: pd.DataFrame,
    reference_root: Path,
    *,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    refs = {
        "clinical_only": pd.read_csv(reference_root / "clinical_only" / "outer_cv_metrics.csv"),
        "tda_only": pd.read_csv(reference_root / "tda_only" / "outer_cv_metrics.csv"),
    }
    lite = clinical_lite_df.sort_values(["repeat", "outer_fold"]).reset_index(drop=True)
    rows: list[dict[str, object]] = []
    for ref_name, ref_df in refs.items():
        ref = ref_df.sort_values(["repeat", "outer_fold"]).reset_index(drop=True)
        if not lite[["repeat", "outer_fold"]].equals(ref[["repeat", "outer_fold"]]):
            raise ValueError(f"Fold assignments do not align for clinical_lite vs {ref_name}.")
        for metric in PAIRWISE_METRICS:
            values_a = lite[metric].to_numpy(dtype=float)
            values_b = ref[metric].to_numpy(dtype=float)
            diff = values_a - values_b
            ci_low, ci_high = _bootstrap_mean_ci(diff, n_boot=n_boot, seed=seed + len(rows))
            if np.allclose(diff, 0.0):
                stat, pvalue = 0.0, 1.0
            else:
                stat, pvalue = wilcoxon(values_a, values_b, zero_method="wilcox", alternative="two-sided", method="auto")
            rows.append(
                {
                    "group_a": "clinical_lite",
                    "group_b": ref_name,
                    "metric": metric,
                    "n_pairs": int(diff.size),
                    "mean_a": float(values_a.mean()),
                    "mean_b": float(values_b.mean()),
                    "mean_diff": float(diff.mean()),
                    "diff_ci95_low": ci_low,
                    "diff_ci95_high": ci_high,
                    "wilcoxon_stat": float(stat),
                    "p_value": float(pvalue),
                }
            )
    pairwise = pd.DataFrame(rows)
    adjusted_parts: list[pd.DataFrame] = []
    for metric, metric_df in pairwise.groupby("metric", sort=False):
        metric_df = metric_df.copy()
        pvalues = metric_df["p_value"].astype(float).tolist()
        order = sorted(range(len(pvalues)), key=lambda idx: pvalues[idx])
        adjusted = [0.0] * len(pvalues)
        running_max = 0.0
        for rank, original_idx in enumerate(order, start=1):
            adj = min(1.0, (len(pvalues) - rank + 1) * pvalues[original_idx])
            running_max = max(running_max, adj)
            adjusted[original_idx] = running_max
        metric_df["p_value_holm"] = adjusted
        adjusted_parts.append(metric_df)
    return pd.concat(adjusted_parts, ignore_index=True)


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir).resolve()
    splits_dir = Path(args.splits_dir)
    output_dir = (project_dir / args.output_dir).resolve()
    reference_root = (project_dir / args.reference_runs_root).resolve()
    _ensure_dir(output_dir)

    c_grid = _parse_grid(args.c_grid)
    results = []
    for repeat in range(1, 4):
        for outer_fold in range(1, 6):
            results.append(
                _run_fold(
                    project_dir=project_dir,
                    splits_dir=splits_dir,
                    output_dir=output_dir,
                    repeat=repeat,
                    outer_fold=outer_fold,
                    c_grid=c_grid,
                    seed=args.seed,
                    max_iter=args.max_iter,
                    resume_existing=args.resume_existing,
                )
            )

    metrics_df = pd.DataFrame(
        [
            {
                "repeat": result["repeat"],
                "outer_fold": result["outer_fold"],
                "C": result["best_params"]["C"],
                "l1_ratio": result["best_params"]["l1_ratio"],
                **result["best_metrics"],
            }
            for result in results
        ]
    )
    metrics_df.to_csv(output_dir / "outer_cv_metrics.csv", index=False, encoding="utf-8-sig")

    summary_df = _summarize_metrics(metrics_df, n_boot=args.bootstrap_samples, seed=args.seed)
    summary_df.to_csv(output_dir / "clinical_lite_metric_summary_with_ci.csv", index=False, encoding="utf-8-sig")
    paper_df = (
        summary_df[summary_df["metric"].isin(["auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc"])]
        .assign(display=lambda frame: frame.apply(_format_metric, axis=1))
        .pivot(index="group", columns="metric", values="display")
        .reset_index()
    )
    paper_df = paper_df[["group", "auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc"]]
    paper_df.to_csv(output_dir / "clinical_lite_paper_table.csv", index=False, encoding="utf-8-sig")

    pairwise_df = _build_pairwise(metrics_df, reference_root, n_boot=args.bootstrap_samples, seed=args.seed + 101)
    pairwise_df.to_csv(output_dir / "clinical_lite_pairwise_vs_main.csv", index=False, encoding="utf-8-sig")

    selected_params_frequency = (
        metrics_df.groupby(["C", "l1_ratio"])
        .size()
        .reset_index(name="count")
        .sort_values("count", ascending=False)
        .to_dict(orient="records")
    )
    payload = {
        "config": {
            "splits_dir": str(splits_dir),
            "output_dir": str(output_dir),
            "seed": args.seed,
            "c_grid": list(c_grid),
            "max_iter": args.max_iter,
            "bootstrap_samples": args.bootstrap_samples,
        },
        "feature_columns": list(CLINICAL_LITE_FEATURE_COLUMNS),
        "excluded_proxy_groups": ["Kmax", "pachymetry", "asphericity"],
        "per_fold_metrics": metrics_df.to_dict(orient="records"),
        "summary": summary_df.to_dict(orient="records"),
        "paper_table": paper_df.to_dict(orient="records"),
        "pairwise": pairwise_df.to_dict(orient="records"),
        "selected_params_frequency": selected_params_frequency,
    }
    (output_dir / "outer_cv_summary.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "output_dir": str(output_dir),
                "feature_columns": list(CLINICAL_LITE_FEATURE_COLUMNS),
                "paper_table": paper_df.to_dict(orient="records"),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
