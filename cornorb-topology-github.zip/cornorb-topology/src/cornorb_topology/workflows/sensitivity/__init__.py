"""Rendered-map mask and crop sensitivity experiments."""
