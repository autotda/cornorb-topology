from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from gtda.homology import CubicalPersistence

from orbscan_experiment.tda import (
    CubicalTDAConfig,
    IMAGE_PATH_COLUMNS,
    _base_feature_frame,
    _vectorize_diagrams,
    prepare_orbscan_filtration,
)
from orbscan_experiment.tda_baseline import TDABaselineConfig, run_full_outer_cv


@dataclass(frozen=True)
class SensitivityVariant:
    name: str
    crop_ratio: float
    mask_radius_ratio: float
    description: str


VARIANTS = (
    SensitivityVariant(
        name="mask042_crop084",
        crop_ratio=0.84,
        mask_radius_ratio=0.42,
        description="Baseline crop with tighter central circular mask.",
    ),
    SensitivityVariant(
        name="mask036_crop084",
        crop_ratio=0.84,
        mask_radius_ratio=0.36,
        description="Baseline crop with very tight central circular mask.",
    ),
    SensitivityVariant(
        name="mask042_crop070",
        crop_ratio=0.70,
        mask_radius_ratio=0.42,
        description="Smaller central crop plus tighter circular mask.",
    ),
)

METRICS = (
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "precision",
    "recall",
    "specificity",
    "mcc",
)


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_metadata(config: CubicalTDAConfig) -> pd.DataFrame:
    metadata = pd.read_csv(Path(config.project_dir) / config.metadata_csv)
    if config.sample_limit is not None and config.sample_limit > 0:
        metadata = metadata.head(config.sample_limit).copy()
    return metadata.reset_index(drop=True)


def extract_features_no_large_arrays(config: CubicalTDAConfig) -> dict[str, Any]:
    """Extract TDA features without saving filtrations/diagrams to disk."""

    start = time.time()
    project_dir = Path(config.project_dir)
    output_dir = project_dir / config.output_dir
    _ensure_dir(output_dir)

    metadata = _load_metadata(config)
    combined_features: list[pd.DataFrame] = [_base_feature_frame(metadata)]
    cubical = CubicalPersistence(
        homology_dimensions=config.homology_dimensions,
        coeff=config.coeff,
        reduced_homology=config.reduced_homology,
        n_jobs=config.n_jobs,
    )

    modality_report: dict[str, Any] = {}
    for view in config.views:
        view_start = time.time()
        filtrations = []
        for row_index, row in metadata.iterrows():
            arrays = prepare_orbscan_filtration(
                image_path=row[IMAGE_PATH_COLUMNS[view]],
                view=view,
                eye=str(row["eye"]),
                config=config,
            )
            filtrations.append(arrays["filtration"])
            if (row_index + 1) % 200 == 0 or (row_index + 1) == len(metadata):
                print(f"[{Path(config.output_dir).name}:{view}] {row_index + 1}/{len(metadata)} filtrations", flush=True)

        filtration_array = np.stack(filtrations, axis=0).astype(np.float32)
        diagrams = cubical.fit_transform(filtration_array)
        features_view = _vectorize_diagrams(
            diagrams=diagrams,
            prefix=view,
            homology_dimensions=config.homology_dimensions,
            betti_bins=config.betti_bins,
            persistence_image_bins=config.persistence_image_bins,
            persistence_image_sigma=config.persistence_image_sigma,
            top_k_lifetimes=config.top_k_lifetimes,
        )
        combined_features.append(features_view)
        modality_report[view] = {
            "num_samples": int(filtration_array.shape[0]),
            "filtration_shape": list(filtration_array.shape[1:]),
            "diagram_shape": list(diagrams.shape[1:]),
            "num_features": int(features_view.shape[1]),
            "elapsed_seconds": float(time.time() - view_start),
        }
        del filtrations, filtration_array, diagrams, features_view
        print(f"[{Path(config.output_dir).name}:{view}] done", flush=True)

    feature_frame = pd.concat(combined_features, axis=1)
    feature_path = output_dir / "cubical_tda_features.csv"
    feature_frame.to_csv(feature_path, index=False, encoding="utf-8-sig")

    summary = {
        "config": asdict(config),
        "num_samples": int(len(metadata)),
        "views": list(config.views),
        "feature_table": str(feature_path.resolve()),
        "num_features_total": int(feature_frame.shape[1]),
        "modalities": modality_report,
        "elapsed_seconds": float(time.time() - start),
        "storage_policy": "features_only_no_filtration_or_diagram_npy",
    }
    with (output_dir / "cubical_tda_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def _bootstrap_mean_ci(values: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    if values.size == 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(n_boot, values.size))
    means = values[indices].mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _summarize_metrics(metrics_df: pd.DataFrame, *, variant: SensitivityVariant | None, n_boot: int, seed: int) -> pd.DataFrame:
    rows = []
    for metric in METRICS:
        values = metrics_df[metric].to_numpy(dtype=float)
        ci_low, ci_high = _bootstrap_mean_ci(values, n_boot=n_boot, seed=seed)
        rows.append(
            {
                "variant": variant.name if variant else "baseline_mask048_crop084",
                "description": variant.description if variant else "Original published TDA extraction setting.",
                "crop_ratio": variant.crop_ratio if variant else 0.84,
                "mask_radius_ratio": variant.mask_radius_ratio if variant else 0.48,
                "metric": metric,
                "n_folds": int(len(values)),
                "mean": float(values.mean()),
                "std": float(values.std(ddof=0)),
                "ci95_low": ci_low,
                "ci95_high": ci_high,
            }
        )
    return pd.DataFrame(rows)


def _format_paper_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    primary = ["auroc", "auprc", "balanced_accuracy", "f1", "mcc"]
    subset = summary_df[summary_df["metric"].isin(primary)].copy()
    subset["display"] = subset.apply(
        lambda row: f"{row['mean']:.4f} +/- {row['std']:.4f} [{row['ci95_low']:.4f}, {row['ci95_high']:.4f}]",
        axis=1,
    )
    paper = subset.pivot(index=["variant", "crop_ratio", "mask_radius_ratio"], columns="metric", values="display").reset_index()
    return paper[["variant", "crop_ratio", "mask_radius_ratio", *primary]]


def _write_plot(summary_df: pd.DataFrame, output_dir: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"Skipping sensitivity plot because matplotlib import failed: {exc}", flush=True)
        return

    primary = summary_df[summary_df["metric"].isin(["auroc", "balanced_accuracy", "f1"])].copy()
    variants = primary["variant"].drop_duplicates().tolist()
    metric_labels = {"auroc": "AUROC", "balanced_accuracy": "Balanced accuracy", "f1": "F1"}
    x = np.arange(len(variants))
    width = 0.25
    fig, ax = plt.subplots(figsize=(10, 5), dpi=300)
    for offset, metric in zip([-width, 0.0, width], ["auroc", "balanced_accuracy", "f1"]):
        metric_df = primary[primary["metric"] == metric].set_index("variant").loc[variants]
        means = metric_df["mean"].to_numpy()
        lows = means - metric_df["ci95_low"].to_numpy()
        highs = metric_df["ci95_high"].to_numpy() - means
        ax.bar(x + offset, means, width=width, label=metric_labels[metric], yerr=[lows, highs], capsize=3)
    ax.set_xticks(x)
    ax.set_xticklabels(variants, rotation=20, ha="right")
    ax.set_ylim(0.75, 1.01)
    ax.set_ylabel("Metric value")
    ax.set_title("TDA-only mask/crop sensitivity analysis")
    ax.grid(axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "tda_mask_crop_sensitivity.png", bbox_inches="tight")
    fig.savefig(output_dir / "tda_mask_crop_sensitivity.pdf", bbox_inches="tight")
    plt.close(fig)


def run_suite(args: argparse.Namespace) -> dict[str, Any]:
    project_dir = Path(args.project_dir)
    output_root = project_dir / args.output_root
    _ensure_dir(output_root)

    summary_parts: list[pd.DataFrame] = []
    if args.baseline_metrics_csv:
        baseline_df = pd.read_csv(project_dir / args.baseline_metrics_csv)
        summary_parts.append(
            _summarize_metrics(
                baseline_df,
                variant=None,
                n_boot=args.bootstrap_samples,
                seed=args.seed,
            )
        )

    variant_reports = []
    for variant in VARIANTS:
        variant_root = output_root / variant.name
        feature_dir = variant_root / "tda_features"
        feature_csv = feature_dir / "cubical_tda_features.csv"
        if not feature_csv.exists() or not args.resume_existing:
            config = CubicalTDAConfig(
                project_dir=args.project_dir,
                metadata_csv=args.metadata_csv,
                output_dir=str(feature_dir.relative_to(project_dir) if feature_dir.is_absolute() else feature_dir),
                image_size=args.image_size,
                crop_ratio=variant.crop_ratio,
                mask_radius_ratio=variant.mask_radius_ratio,
                radial_bins=args.radial_bins,
                anomaly_clip_quantile=args.anomaly_clip_quantile,
                scalarization=args.scalarization,
                align_left_right=not args.no_align_left_right,
                n_jobs=args.n_jobs,
                betti_bins=args.betti_bins,
                persistence_image_bins=args.persistence_image_bins,
                persistence_image_sigma=args.persistence_image_sigma,
                top_k_lifetimes=args.top_k_lifetimes,
                debug_samples=0,
                sample_limit=args.sample_limit if args.sample_limit > 0 else None,
            )
            extraction_summary = extract_features_no_large_arrays(config)
        else:
            extraction_summary = json.loads((feature_dir / "cubical_tda_summary.json").read_text(encoding="utf-8"))

        cv_output = variant_root / "tda_only"
        metrics_csv = cv_output / "outer_cv_metrics.csv"
        if not metrics_csv.exists() or not args.resume_existing:
            cv_config = TDABaselineConfig(
                project_dir=args.project_dir,
                features_csv=str(feature_csv.relative_to(project_dir) if feature_csv.is_absolute() else feature_csv),
                splits_dir=args.splits_dir,
                output_dir=str(cv_output.relative_to(project_dir) if cv_output.is_absolute() else cv_output),
                seed=args.seed,
                c_grid=tuple(float(part) for part in args.c_grid.split(",") if part.strip()),
                l1_ratio_grid=tuple(float(part) for part in args.l1_grid.split(",") if part.strip()),
                max_iter=args.max_iter,
                use_class_weight=not args.no_class_weight,
                resume_existing=args.resume_existing,
            )
            cv_summary = run_full_outer_cv(cv_config)
        else:
            cv_summary = json.loads((cv_output / "outer_cv_summary.json").read_text(encoding="utf-8"))

        metrics_df = pd.read_csv(metrics_csv)
        summary_parts.append(
            _summarize_metrics(
                metrics_df,
                variant=variant,
                n_boot=args.bootstrap_samples,
                seed=args.seed,
            )
        )
        variant_reports.append(
            {
                "variant": asdict(variant),
                "features_csv": str(feature_csv),
                "metrics_csv": str(metrics_csv),
                "extraction": extraction_summary,
                "cv_aggregate": cv_summary.get("aggregate", {}),
            }
        )

    summary_df = pd.concat(summary_parts, ignore_index=True)
    summary_csv = output_root / "tda_mask_crop_sensitivity_summary.csv"
    paper_csv = output_root / "tda_mask_crop_sensitivity_paper_table.csv"
    summary_df.to_csv(summary_csv, index=False, encoding="utf-8-sig")
    paper_df = _format_paper_table(summary_df)
    paper_df.to_csv(paper_csv, index=False, encoding="utf-8-sig")
    try:
        with pd.ExcelWriter(output_root / "tda_mask_crop_sensitivity_summary.xlsx") as writer:
            summary_df.to_excel(writer, sheet_name="metric_summary", index=False)
            paper_df.to_excel(writer, sheet_name="paper_table", index=False)
    except Exception as exc:
        print(f"Excel summary skipped: {exc}", flush=True)
    _write_plot(summary_df, output_root)

    manifest = {
        "output_root": str(output_root.resolve()),
        "baseline_metrics_csv": args.baseline_metrics_csv,
        "summary_csv": str(summary_csv.resolve()),
        "paper_csv": str(paper_csv.resolve()),
        "variants": variant_reports,
        "interpretation": (
            "This suite tests whether TDA-only performance remains stable when the central mask/crop is tightened "
            "to reduce software-rendering overlays, grid lines, rings, and peripheral numeric annotations."
        ),
    }
    with (output_root / "tda_mask_crop_sensitivity_manifest.json").open("w", encoding="utf-8") as fp:
        json.dump(manifest, fp, ensure_ascii=False, indent=2)
    return manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run overlay-aware TDA mask/crop sensitivity experiments.")
    parser.add_argument("--project-dir", default=".")
    parser.add_argument("--metadata-csv", default="experiment_setup/metadata_clean.csv")
    parser.add_argument("--splits-dir", default="experiment_setup/splits")
    parser.add_argument("--output-root", default="runs/tda_overlay_sensitivity_v1")
    parser.add_argument("--baseline-metrics-csv", default="runs/ablation_suite_v1/tda_only/outer_cv_metrics.csv")
    parser.add_argument("--image-size", type=int, default=192)
    parser.add_argument("--radial-bins", type=int, default=64)
    parser.add_argument("--anomaly-clip-quantile", type=float, default=0.995)
    parser.add_argument("--scalarization", choices=["luminance_rank", "luminance", "value_rank"], default="luminance_rank")
    parser.add_argument("--betti-bins", type=int, default=32)
    parser.add_argument("--persistence-image-bins", type=int, default=16)
    parser.add_argument("--persistence-image-sigma", type=float, default=0.05)
    parser.add_argument("--top-k-lifetimes", type=int, default=3)
    parser.add_argument("--n-jobs", type=int, default=-1)
    parser.add_argument("--sample-limit", type=int, default=0)
    parser.add_argument("--no-align-left-right", action="store_true")
    parser.add_argument("--seed", type=int, default=20260507)
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    parser.add_argument("--max-iter", type=int, default=4000)
    parser.add_argument("--c-grid", default="0.01,0.03,0.1,0.3,1.0")
    parser.add_argument("--l1-grid", default="0.0")
    parser.add_argument("--no-class-weight", action="store_true")
    parser.add_argument("--resume-existing", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = run_suite(args)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
