"""Cubical persistence feature extraction."""
