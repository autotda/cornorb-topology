from __future__ import annotations

import argparse
import json

from orbscan_experiment.tda import CubicalTDAConfig, run_cubical_tda_extraction


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract cubical-complex TDA features from Orbscan maps using giotto-tda.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--metadata-csv", default="experiment_setup/metadata_clean.csv", help="Eye-level metadata CSV.")
    parser.add_argument("--output-dir", default="runs/cubical_tda_v1", help="Output directory.")
    parser.add_argument("--image-size", type=int, default=192)
    parser.add_argument("--crop-ratio", type=float, default=0.84)
    parser.add_argument("--mask-radius-ratio", type=float, default=0.48)
    parser.add_argument("--radial-bins", type=int, default=64)
    parser.add_argument("--anomaly-clip-quantile", type=float, default=0.995)
    parser.add_argument("--scalarization", choices=["luminance_rank", "luminance", "value_rank"], default="luminance_rank")
    parser.add_argument("--betti-bins", type=int, default=32)
    parser.add_argument("--persistence-image-bins", type=int, default=16)
    parser.add_argument("--persistence-image-sigma", type=float, default=0.05)
    parser.add_argument("--top-k-lifetimes", type=int, default=3)
    parser.add_argument("--sample-limit", type=int, default=None)
    parser.add_argument("--debug-samples", type=int, default=8)
    parser.add_argument("--n-jobs", type=int, default=None)
    parser.add_argument("--no-align-left-right", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = CubicalTDAConfig(
        project_dir=args.project_dir,
        metadata_csv=args.metadata_csv,
        output_dir=args.output_dir,
        image_size=args.image_size,
        crop_ratio=args.crop_ratio,
        mask_radius_ratio=args.mask_radius_ratio,
        radial_bins=args.radial_bins,
        anomaly_clip_quantile=args.anomaly_clip_quantile,
        scalarization=args.scalarization,
        align_left_right=not args.no_align_left_right,
        betti_bins=args.betti_bins,
        persistence_image_bins=args.persistence_image_bins,
        persistence_image_sigma=args.persistence_image_sigma,
        top_k_lifetimes=args.top_k_lifetimes,
        sample_limit=args.sample_limit,
        debug_samples=args.debug_samples,
        n_jobs=args.n_jobs,
    )
    summary = run_cubical_tda_extraction(config)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
