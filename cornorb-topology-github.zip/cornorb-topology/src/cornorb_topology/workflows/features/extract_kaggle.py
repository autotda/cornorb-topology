from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from gtda.diagrams import Amplitude, BettiCurve, NumberOfPoints, PersistenceEntropy, PersistenceImage
from gtda.homology import CubicalPersistence
from PIL import Image

from orbscan_experiment.tda import (
    _center_crop,
    _corneal_mask,
    _diagram_summary_features,
    _flatten_features,
    _radial_baseline,
    _resize_rgb,
    _rgb_to_scalar,
    _robust_unit_interval,
)
from cornorb_topology.workflows.data.prepare_kaggle import KAGGLE_VIEWS


if not hasattr(np, "product"):
    np.product = np.prod


NEGATIVE_ANOMALY_VIEWS = {"ct_a"}
POSITIVE_ANOMALY_VIEWS = {"ec_a", "ec_p", "elv_a", "elv_p", "sag_a", "sag_p"}


@dataclass
class KaggleTDAConfig:
    manifest_csv: str = "experiment_setup/kaggle_replication/kaggle_all_manifest.csv"
    fit_split_csv: str = "experiment_setup/kaggle_replication/train_binary.csv"
    output_dir: str = "runs/kaggle_replication_tda_v1"
    views: tuple[str, ...] = KAGGLE_VIEWS
    image_size: int = 192
    crop_ratio: float = 1.0
    mask_radius_ratio: float = 0.48
    radial_bins: int = 64
    anomaly_clip_quantile: float = 0.995
    scalarization: str = "luminance_rank"
    homology_dimensions: tuple[int, ...] = (0, 1)
    coeff: int = 2
    reduced_homology: bool = True
    n_jobs: int | None = None
    betti_bins: int = 32
    persistence_image_bins: int = 16
    persistence_image_sigma: float = 0.05
    top_k_lifetimes: int = 3
    sample_limit: int | None = None


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def prepare_kaggle_filtration(image_path: str | Path, *, view: str, config: KaggleTDAConfig) -> np.ndarray:
    with Image.open(image_path) as image:
        rgb = np.asarray(image.convert("RGB"), dtype=np.uint8)
    rgb = _center_crop(rgb, crop_ratio=config.crop_ratio)
    rgb = _resize_rgb(rgb, image_size=config.image_size)
    mask = _corneal_mask(image_size=config.image_size, radius_ratio=config.mask_radius_ratio)
    scalar = _rgb_to_scalar(rgb, mask=mask, scalarization=config.scalarization)
    baseline, _ = _radial_baseline(scalar=scalar, mask=mask, radial_bins=config.radial_bins)
    residual = scalar - baseline

    if view in NEGATIVE_ANOMALY_VIEWS:
        anomaly = np.clip(-residual, a_min=0.0, a_max=None)
    elif view in POSITIVE_ANOMALY_VIEWS:
        anomaly = np.clip(residual, a_min=0.0, a_max=None)
    else:
        raise ValueError(f"Unknown Kaggle view: {view}")

    anomaly_norm = _robust_unit_interval(anomaly, mask=mask, high_quantile=config.anomaly_clip_quantile)
    filtration = np.full_like(anomaly_norm, fill_value=1.05, dtype=np.float32)
    filtration[mask] = 1.0 - anomaly_norm[mask]
    return filtration.astype(np.float32)


def _vectorizers(config: KaggleTDAConfig) -> list[tuple[str, Any]]:
    return [
        ("entropy", PersistenceEntropy(normalize=True)),
        ("num_points", NumberOfPoints()),
        ("amplitude_bottleneck", Amplitude(metric="bottleneck")),
        ("amplitude_wasserstein", Amplitude(metric="wasserstein", metric_params={"p": 2})),
        ("amplitude_landscape", Amplitude(metric="landscape")),
        ("betti", BettiCurve(n_bins=config.betti_bins)),
        (
            "pimg",
            PersistenceImage(
                sigma=config.persistence_image_sigma,
                n_bins=config.persistence_image_bins,
            ),
        ),
    ]


def _vectorize_split_safe(
    diagrams: np.ndarray,
    fit_mask: np.ndarray,
    *,
    prefix: str,
    config: KaggleTDAConfig,
) -> pd.DataFrame:
    feature_frames: list[pd.DataFrame] = []
    summary_df = _diagram_summary_features(
        diagrams,
        homology_dimensions=config.homology_dimensions,
        top_k=config.top_k_lifetimes,
    ).add_prefix(f"{prefix}_summary_")
    feature_frames.append(summary_df)

    fit_diagrams = diagrams[fit_mask]
    if len(fit_diagrams) == 0:
        raise ValueError("No fit diagrams found for split-safe TDA vectorization.")
    for name, vectorizer in _vectorizers(config):
        vectorizer.fit(fit_diagrams)
        transformed = vectorizer.transform(diagrams)
        flat, columns = _flatten_features(
            transformed,
            prefix=f"{prefix}_{name}",
            homology_dimensions=config.homology_dimensions,
        )
        feature_frames.append(pd.DataFrame(flat, columns=columns))
    return pd.concat(feature_frames, axis=1)


def run_kaggle_tda(config: KaggleTDAConfig) -> dict[str, Any]:
    start = time.time()
    output_dir = Path(config.output_dir)
    _ensure_dir(output_dir)

    metadata = pd.read_csv(config.manifest_csv)
    if config.sample_limit is not None and config.sample_limit > 0:
        metadata = metadata.head(config.sample_limit).copy()
    metadata = metadata.reset_index(drop=True)
    fit_ids = set(pd.read_csv(config.fit_split_csv)["patient_eye_id"].astype(str))
    fit_mask = metadata["patient_eye_id"].astype(str).isin(fit_ids).to_numpy()

    base_columns = [
        "patient_eye_id",
        "patient_code",
        "eye",
        "case_id",
        "split_source",
        "label",
        "label_text",
    ]
    combined_features: list[pd.DataFrame] = [metadata[base_columns].copy()]

    cubical = CubicalPersistence(
        homology_dimensions=config.homology_dimensions,
        coeff=config.coeff,
        reduced_homology=config.reduced_homology,
        n_jobs=config.n_jobs,
    )

    modality_report: dict[str, Any] = {}
    for view in config.views:
        view_start = time.time()
        filtrations = []
        for row_index, row in metadata.iterrows():
            filtrations.append(
                prepare_kaggle_filtration(
                    row[f"image_{view}_path"],
                    view=view,
                    config=config,
                )
            )
            if (row_index + 1) % 100 == 0 or row_index + 1 == len(metadata):
                print(f"[{view}] filtrations {row_index + 1}/{len(metadata)}", flush=True)
        filtration_array = np.stack(filtrations, axis=0).astype(np.float32)
        diagrams = cubical.fit_transform(filtration_array)
        features_view = _vectorize_split_safe(
            diagrams=diagrams,
            fit_mask=fit_mask,
            prefix=view,
            config=config,
        )
        combined_features.append(features_view)
        modality_report[view] = {
            "num_samples": int(filtration_array.shape[0]),
            "fit_samples": int(fit_mask.sum()),
            "filtration_shape": list(filtration_array.shape[1:]),
            "diagram_shape": list(diagrams.shape[1:]),
            "num_features": int(features_view.shape[1]),
            "elapsed_seconds": float(time.time() - view_start),
        }
        print(f"[{view}] done in {time.time() - view_start:.1f}s", flush=True)

    feature_frame = pd.concat(combined_features, axis=1)
    features_csv = output_dir / "kaggle_cubical_tda_features.csv"
    feature_frame.to_csv(features_csv, index=False, encoding="utf-8-sig")

    summary = {
        "config": asdict(config),
        "num_samples": int(len(metadata)),
        "fit_samples": int(fit_mask.sum()),
        "views": list(config.views),
        "feature_table": str(features_csv.resolve()),
        "num_features_total": int(feature_frame.shape[1]),
        "modalities": modality_report,
        "elapsed_seconds": float(time.time() - start),
    }
    with (output_dir / "kaggle_cubical_tda_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract split-safe cubical TDA features for the Kaggle dataset.")
    parser.add_argument("--manifest-csv", default="experiment_setup/kaggle_replication/kaggle_all_manifest.csv")
    parser.add_argument("--fit-split-csv", default="experiment_setup/kaggle_replication/train_binary.csv")
    parser.add_argument("--output-dir", default="runs/kaggle_replication_tda_v1")
    parser.add_argument("--image-size", type=int, default=192)
    parser.add_argument("--n-jobs", type=int, default=-1)
    parser.add_argument("--sample-limit", type=int, default=0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = KaggleTDAConfig(
        manifest_csv=args.manifest_csv,
        fit_split_csv=args.fit_split_csv,
        output_dir=args.output_dir,
        image_size=args.image_size,
        n_jobs=args.n_jobs,
        sample_limit=args.sample_limit if args.sample_limit > 0 else None,
    )
    summary = run_kaggle_tda(config)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
