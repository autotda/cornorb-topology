"""Descriptive localization of representative topological structures."""
