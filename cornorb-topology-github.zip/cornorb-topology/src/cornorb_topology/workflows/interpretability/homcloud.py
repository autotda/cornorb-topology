from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import homcloud.interface as hc
import matplotlib
import numpy as np
import pandas as pd
from scipy import ndimage

from orbscan_experiment.tda import (
    DEFAULT_TDA_VIEWS,
    IMAGE_PATH_COLUMNS,
    CubicalTDAConfig,
    prepare_orbscan_filtration,
)

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


STRUCTURE_4 = np.array(
    [
        [0, 1, 0],
        [1, 1, 1],
        [0, 1, 0],
    ],
    dtype=bool,
)

DEFAULT_SAMPLE_IDS = ("125GC_OD", "15UG2_OD")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compute HomCloud representative structures for selected Orbscan "
            "cubical filtrations. H1 uses HomCloud optimal cycles/volumes; "
            "H0 uses HomCloud birth-death pairs plus thresholded connected "
            "component localization."
        )
    )
    parser.add_argument("--project-dir", default=".")
    parser.add_argument("--metadata-csv", default="experiment_setup/metadata_clean.csv")
    parser.add_argument("--output-dir", default="runs/homcloud_representatives_v1")
    parser.add_argument(
        "--all-samples",
        action="store_true",
        help="Run all usable samples in metadata_csv instead of the explicitly listed sample ids.",
    )
    parser.add_argument("--sample-ids", nargs="*", default=list(DEFAULT_SAMPLE_IDS))
    parser.add_argument("--views", nargs="*", default=["axial"])
    parser.add_argument("--top-k", type=int, default=1)
    parser.add_argument("--min-lifetime", type=float, default=0.02)
    parser.add_argument("--cutoff-radius", type=float, default=32.0)
    parser.add_argument(
        "--skip-volume",
        action="store_true",
        help="Skip HomCloud optimal_volume computation and keep only optimal_1_cycle localization.",
    )
    parser.add_argument(
        "--no-figures",
        action="store_true",
        help="Do not save representative PNG figures. Recommended for full-cohort runs.",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from the partial CSV in the output directory if it exists.",
    )
    parser.add_argument("--progress-every", type=int, default=25)
    parser.add_argument("--keep-pdgm", action="store_true")
    parser.add_argument("--image-size", type=int, default=192)
    parser.add_argument("--crop-ratio", type=float, default=0.84)
    parser.add_argument("--mask-radius-ratio", type=float, default=0.48)
    parser.add_argument("--radial-bins", type=int, default=64)
    parser.add_argument("--anomaly-clip-quantile", type=float, default=0.995)
    parser.add_argument("--scalarization", default="luminance_rank")
    parser.add_argument("--no-align-left-right", action="store_true")
    return parser.parse_args()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def position_to_row_col(position: Any) -> tuple[int, int]:
    """Convert HomCloud bitmap/cubical positions to image row/col indices."""
    if (
        isinstance(position, tuple)
        and position
        and isinstance(position[0], (list, tuple, np.ndarray))
    ):
        position = position[0]
    if isinstance(position, np.ndarray):
        position = position.tolist()
    if isinstance(position, (list, tuple)) and len(position) >= 2:
        row = int(round(float(position[0])))
        col = int(round(float(position[1])))
        return row, col
    raise ValueError(f"Cannot parse HomCloud position: {position!r}")


def safe_bool(value: Any) -> bool:
    if callable(value):
        value = value()
    return bool(value)


def safe_call_list(method: Any) -> list[Any]:
    if not callable(method):
        return []
    try:
        value = method()
    except Exception:
        return []
    if value is None:
        return []
    if isinstance(value, set):
        return list(value)
    return list(value)


def mask_from_positions(positions: list[Any], shape: tuple[int, int], *, dilation: int = 1) -> np.ndarray:
    mask = np.zeros(shape, dtype=bool)
    for position in positions:
        try:
            row, col = position_to_row_col(position)
        except Exception:
            continue
        if 0 <= row < shape[0] and 0 <= col < shape[1]:
            mask[row, col] = True
    if dilation > 0 and np.any(mask):
        mask = ndimage.binary_dilation(mask, structure=STRUCTURE_4, iterations=dilation)
    return mask


def component_containing(binary: np.ndarray, row: int, col: int) -> np.ndarray:
    labels, _ = ndimage.label(binary.astype(bool), structure=STRUCTURE_4)
    if row < 0 or col < 0 or row >= binary.shape[0] or col >= binary.shape[1]:
        return np.zeros_like(binary, dtype=bool)
    label = int(labels[row, col])
    if label == 0:
        return np.zeros_like(binary, dtype=bool)
    return labels == label


def boundary_of(region: np.ndarray) -> np.ndarray:
    if not np.any(region):
        return np.zeros_like(region, dtype=bool)
    return region & ~ndimage.binary_erosion(region, structure=STRUCTURE_4, border_value=0)


def select_pairs(pd: Any, *, top_k: int, min_lifetime: float) -> list[dict[str, Any]]:
    births = np.asarray(pd.births, dtype=float)
    deaths = np.asarray(pd.deaths, dtype=float)
    selected: list[dict[str, Any]] = []
    for index, (birth, death) in enumerate(zip(births, deaths, strict=False)):
        lifetime = float(death - birth)
        if not np.isfinite(lifetime) or lifetime < min_lifetime:
            continue
        selected.append(
            {
                "pair_index": int(index),
                "pair": pd.pair(int(index)),
                "birth": float(birth),
                "death": float(death),
                "lifetime": lifetime,
            }
        )
    selected.sort(key=lambda item: float(item["lifetime"]), reverse=True)
    return selected[:top_k]


def localize_h0_pair(filtration: np.ndarray, mask: np.ndarray, pair_info: dict[str, Any]) -> dict[str, Any]:
    pair = pair_info["pair"]
    birth_row, birth_col = position_to_row_col(pair.birth_position)
    death_row, death_col = position_to_row_col(pair.death_position)
    epsilon = max(1e-6, 0.01 * float(pair_info["lifetime"]))
    threshold = float(pair_info["death"]) - epsilon
    active = (filtration <= threshold) & mask.astype(bool)
    component = component_containing(active, birth_row, birth_col)
    return {
        "birth_row": birth_row,
        "birth_col": birth_col,
        "death_row": death_row,
        "death_col": death_col,
        "threshold": threshold,
        "component": component,
        "boundary": boundary_of(component),
        "component_area_px": int(component.sum()),
    }


def localize_h1_pair(
    pair_info: dict[str, Any],
    shape: tuple[int, int],
    cutoff_radius: float | None,
    *,
    compute_volume: bool,
) -> dict[str, Any]:
    pair = pair_info["pair"]
    birth_row, birth_col = position_to_row_col(pair.birth_position)
    death_row, death_col = position_to_row_col(pair.death_position)

    cycle_status = "not_computed"
    cycle_path: list[Any] = []
    cycle_boundary_points: list[Any] = []
    try:
        cycle = pair.optimal_1_cycle()
        cycle_path = safe_call_list(cycle.path)
        cycle_boundary_points = safe_call_list(cycle.boundary_points)
        cycle_status = "ok"
    except Exception as exc:
        cycle_status = f"failed:{type(exc).__name__}"

    volume_status = "skipped"
    volume_points: list[Any] = []
    volume_boundary_points: list[Any] = []
    if compute_volume:
        volume_status = "not_computed"
        try:
            volume = pair.optimal_volume(
                cutoff_radius=cutoff_radius,
                return_failure_if_not_found=True,
            )
            if safe_bool(getattr(volume, "success", True)):
                volume_points = safe_call_list(volume.points)
                volume_boundary_points = safe_call_list(volume.boundary_points)
                volume_status = "ok"
            else:
                volume_status = "failed:infeasible"
        except Exception as exc:
            volume_status = f"failed:{type(exc).__name__}"

    cycle_mask = mask_from_positions(cycle_path, shape, dilation=1)
    cycle_boundary_mask = mask_from_positions(cycle_boundary_points, shape, dilation=1)
    volume_mask = mask_from_positions(volume_points, shape, dilation=1)
    volume_boundary_mask = mask_from_positions(volume_boundary_points, shape, dilation=1)

    return {
        "birth_row": birth_row,
        "birth_col": birth_col,
        "death_row": death_row,
        "death_col": death_col,
        "cycle_status": cycle_status,
        "volume_status": volume_status,
        "cycle_mask": cycle_mask,
        "cycle_boundary_mask": cycle_boundary_mask,
        "volume_mask": volume_mask,
        "volume_boundary_mask": volume_boundary_mask,
        "cycle_area_px": int(cycle_mask.sum()),
        "volume_area_px": int(volume_mask.sum()),
    }


def normalize_gray(array: np.ndarray) -> np.ndarray:
    values = np.asarray(array, dtype=np.float32)
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return np.zeros_like(values)
    low, high = np.quantile(finite, [0.01, 0.99])
    if high <= low:
        return np.zeros_like(values)
    return np.clip((values - low) / (high - low), 0.0, 1.0)


def overlay_mask(
    image: np.ndarray,
    mask: np.ndarray,
    color: tuple[float, float, float],
    alpha: float,
) -> np.ndarray:
    rgb = image.astype(np.float32).copy()
    if rgb.max() > 1.0:
        rgb /= 255.0
    mask_bool = mask.astype(bool)
    color_array = np.asarray(color, dtype=np.float32)
    rgb[mask_bool] = (1.0 - alpha) * rgb[mask_bool] + alpha * color_array
    return np.clip(rgb, 0.0, 1.0)


def plot_representatives(
    *,
    sample_id: str,
    label_text: str,
    view: str,
    arrays: dict[str, np.ndarray],
    h0_items: list[tuple[dict[str, Any], dict[str, Any]]],
    h1_items: list[tuple[dict[str, Any], dict[str, Any]]],
    all_pairs: dict[int, list[dict[str, Any]]],
    output_path: Path,
) -> None:
    rgb = arrays["rgb"]
    anomaly = normalize_gray(arrays["anomaly"])

    h0_overlay = rgb.copy()
    h1_overlay = rgb.copy()
    for _, rep in h0_items:
        h0_overlay = overlay_mask(h0_overlay, rep["component"], (0.0, 0.85, 1.0), 0.45)
        h0_overlay = overlay_mask(h0_overlay, rep["boundary"], (0.0, 0.05, 0.05), 0.55)
    for _, rep in h1_items:
        h1_overlay = overlay_mask(h1_overlay, rep["volume_mask"], (0.1, 0.35, 1.0), 0.35)
        h1_overlay = overlay_mask(h1_overlay, rep["volume_boundary_mask"], (1.0, 0.75, 0.0), 0.70)
        h1_overlay = overlay_mask(h1_overlay, rep["cycle_mask"], (1.0, 0.05, 0.05), 0.80)
        h1_overlay = overlay_mask(h1_overlay, rep["cycle_boundary_mask"], (0.0, 1.0, 0.4), 0.80)

    fig, axes = plt.subplots(1, 5, figsize=(18, 4.2))
    fig.suptitle(f"{sample_id} ({label_text}) - {view} - HomCloud representatives", fontsize=12, weight="bold")

    axes[0].imshow(rgb)
    axes[0].set_title("Rendered map")
    axes[0].axis("off")

    axes[1].imshow(anomaly, cmap="inferno")
    axes[1].set_title("Anomaly field")
    axes[1].axis("off")

    axes[2].imshow(h0_overlay)
    axes[2].set_title("H0 component")
    axes[2].axis("off")

    axes[3].imshow(h1_overlay)
    axes[3].set_title("H1 optimal cycle/volume")
    axes[3].axis("off")

    for dim, color, label in [(0, "#8ecae6", "H0"), (1, "#f4a0a3", "H1")]:
        points = all_pairs.get(dim, [])
        if points:
            axes[4].scatter(
                [item["birth"] for item in points],
                [item["death"] for item in points],
                s=10,
                alpha=0.22,
                color=color,
                label=label,
            )

    for items, marker, color, label in [
        (h0_items, "o", "#008fb3", "H0 selected"),
        (h1_items, "^", "#d62828", "H1 selected"),
    ]:
        if items:
            axes[4].scatter(
                [info["birth"] for info, _ in items],
                [info["death"] for info, _ in items],
                s=68,
                marker=marker,
                color=color,
                edgecolor="black",
                linewidth=0.4,
                label=label,
            )

    axes[4].plot([0, 1.08], [0, 1.08], "--", color="#6b7280", linewidth=0.8)
    axes[4].set_xlim(0, 1.08)
    axes[4].set_ylim(0, 1.08)
    axes[4].set_xlabel("Birth")
    axes[4].set_ylabel("Death")
    axes[4].set_title("Persistence pairs")
    axes[4].legend(loc="lower right", fontsize=7)
    axes[4].grid(alpha=0.2)

    for info, rep in h0_items + h1_items:
        axes[1].scatter([rep["birth_col"]], [rep["birth_row"]], s=24, color="#00ff66", edgecolor="black", linewidth=0.3)
        axes[1].scatter([rep["death_col"]], [rep["death_row"]], s=24, color="#ff00ff", edgecolor="black", linewidth=0.3)

    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def compute_homcloud_pd(
    filtration: np.ndarray,
    output_path: Path,
    *,
    compute_volume: bool,
) -> Any:
    filtration_type = "cubical" if compute_volume else "bitmap"
    return hc.PDList.from_bitmap_levelset(
        filtration.astype(np.float64),
        mode="sublevel",
        type=filtration_type,
        save_to=str(output_path),
        save_suppl_info=True,
        save_boundary_map=compute_volume,
    )


def append_rows_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    frame = pd.DataFrame(rows)
    frame.to_csv(
        path,
        mode="a",
        header=not path.exists(),
        index=False,
        encoding="utf-8-sig",
    )


def run(args: argparse.Namespace) -> dict[str, Any]:
    project_dir = Path(args.project_dir)
    output_dir = project_dir / args.output_dir
    figure_dir = output_dir / "figures"
    pdgm_dir = output_dir / "pdgm"
    if not args.no_figures:
        ensure_dir(figure_dir)
    ensure_dir(pdgm_dir)

    metadata = pd.read_csv(project_dir / args.metadata_csv)
    if args.all_samples:
        sample_ids = metadata["patient_eye_id"].astype(str).tolist()
    else:
        sample_ids = list(args.sample_ids or DEFAULT_SAMPLE_IDS)
        metadata = metadata[metadata["patient_eye_id"].astype(str).isin(sample_ids)].copy()
    if metadata.empty:
        raise ValueError(f"No requested sample ids were found: {sample_ids}")
    metadata["sample_order"] = metadata["patient_eye_id"].astype(str).map({sid: idx for idx, sid in enumerate(sample_ids)})
    metadata = metadata.sort_values("sample_order")

    config = CubicalTDAConfig(
        project_dir=args.project_dir,
        metadata_csv=args.metadata_csv,
        output_dir=args.output_dir,
        views=tuple(args.views),
        image_size=args.image_size,
        crop_ratio=args.crop_ratio,
        mask_radius_ratio=args.mask_radius_ratio,
        radial_bins=args.radial_bins,
        anomaly_clip_quantile=args.anomaly_clip_quantile,
        scalarization=args.scalarization,
        align_left_right=not args.no_align_left_right,
    )

    rows: list[dict[str, Any]] = []
    partial_csv = output_dir / "homcloud_representative_summary.partial.csv"
    final_csv = output_dir / "homcloud_representative_summary.csv"
    completed_view_keys: set[tuple[str, str]] = set()
    if args.resume and partial_csv.exists():
        partial = pd.read_csv(partial_csv)
        if not partial.empty:
            rows = partial.to_dict("records")
            completed_view_keys = set(
                zip(partial["patient_eye_id"].astype(str), partial["view"].astype(str), strict=False)
            )
    elif partial_csv.exists():
        partial_csv.unlink()
    if final_csv.exists() and not args.resume:
        final_csv.unlink()

    total_tasks = int(len(metadata) * len(args.views))
    completed_tasks = 0
    started_at = time.time()

    for _, row in metadata.iterrows():
        sample_id = str(row["patient_eye_id"])
        label_text = str(row.get("label_text", row.get("label", "")))
        eye = str(row["eye"])
        for view in args.views:
            completed_tasks += 1
            if (sample_id, view) in completed_view_keys:
                if args.progress_every > 0 and completed_tasks % args.progress_every == 0:
                    elapsed = max(1e-6, time.time() - started_at)
                    print(
                        f"[resume-skip] {completed_tasks}/{total_tasks} "
                        f"({completed_tasks / total_tasks:.1%}), elapsed {elapsed / 60:.1f} min",
                        flush=True,
                    )
                continue

            arrays = prepare_orbscan_filtration(
                image_path=row[IMAGE_PATH_COLUMNS[view]],
                view=view,
                eye=eye,
                config=config,
            )
            filtration = arrays["filtration"]
            mask = arrays["mask"] > 0.5
            pdgm_path = pdgm_dir / f"{sample_id}_{view}.pdgm"
            pdlist = compute_homcloud_pd(filtration, pdgm_path, compute_volume=not args.skip_volume)
            view_rows: list[dict[str, Any]] = []
            try:
                all_pairs: dict[int, list[dict[str, Any]]] = {}
                selected: dict[int, list[dict[str, Any]]] = {}
                for dim in (0, 1):
                    diagram = pdlist.dth_diagram(dim)
                    if args.no_figures:
                        all_pairs[dim] = []
                    else:
                        all_pairs[dim] = select_pairs(diagram, top_k=10_000, min_lifetime=0.0)
                    selected[dim] = select_pairs(diagram, top_k=args.top_k, min_lifetime=args.min_lifetime)

                h0_items: list[tuple[dict[str, Any], dict[str, Any]]] = []
                for info in selected[0]:
                    h0_items.append((info, localize_h0_pair(filtration, mask, info)))

                h1_items: list[tuple[dict[str, Any], dict[str, Any]]] = []
                for info in selected[1]:
                    h1_items.append(
                        (
                            info,
                            localize_h1_pair(
                                info,
                                filtration.shape,
                                args.cutoff_radius,
                                compute_volume=not args.skip_volume,
                            ),
                        )
                    )

                figure_path = figure_dir / f"{sample_id}_{view}_homcloud_representatives.png"
                if not args.no_figures:
                    plot_representatives(
                        sample_id=sample_id,
                        label_text=label_text,
                        view=view,
                        arrays=arrays,
                        h0_items=h0_items,
                        h1_items=h1_items,
                        all_pairs=all_pairs,
                        output_path=figure_path,
                    )

                for dimension, items in [(0, h0_items), (1, h1_items)]:
                    for rank, (info, rep) in enumerate(items, start=1):
                        view_rows.append(
                            {
                                "patient_eye_id": sample_id,
                                "label": int(row["label"]),
                                "label_text": label_text,
                                "view": view,
                                "dimension": int(dimension),
                                "rank": int(rank),
                                "birth": float(info["birth"]),
                                "death": float(info["death"]),
                                "lifetime": float(info["lifetime"]),
                                "birth_row": int(rep["birth_row"]),
                                "birth_col": int(rep["birth_col"]),
                                "death_row": int(rep["death_row"]),
                                "death_col": int(rep["death_col"]),
                                "h0_component_area_px": int(rep.get("component_area_px", 0)),
                                "h1_cycle_status": str(rep.get("cycle_status", "")),
                                "h1_volume_status": str(rep.get("volume_status", "")),
                                "h1_cycle_area_px": int(rep.get("cycle_area_px", 0)),
                                "h1_volume_area_px": int(rep.get("volume_area_px", 0)),
                                "pdgm_path": str(pdgm_path) if args.keep_pdgm else "",
                                "figure_path": "" if args.no_figures else str(figure_path),
                            }
                        )
            finally:
                pdlist.close()
                if not args.keep_pdgm and pdgm_path.exists():
                    pdgm_path.unlink()

            rows.extend(view_rows)
            append_rows_csv(partial_csv, view_rows)
            if args.progress_every > 0 and completed_tasks % args.progress_every == 0:
                elapsed = max(1e-6, time.time() - started_at)
                rate = completed_tasks / elapsed
                remaining = max(0, total_tasks - completed_tasks)
                eta_min = remaining / max(rate, 1e-6) / 60.0
                print(
                    f"[progress] {completed_tasks}/{total_tasks} "
                    f"({completed_tasks / total_tasks:.1%}), elapsed {elapsed / 60:.1f} min, "
                    f"ETA {eta_min:.1f} min",
                    flush=True,
                )

    summary_table = pd.DataFrame(rows)
    summary_csv = final_csv
    summary_table.to_csv(summary_csv, index=False, encoding="utf-8-sig")

    if not args.keep_pdgm:
        try:
            pdgm_dir.rmdir()
        except OSError:
            pass

    manifest = {
        "config": asdict(config),
        "sample_ids": sample_ids,
        "views": list(args.views),
        "top_k": int(args.top_k),
        "min_lifetime": float(args.min_lifetime),
        "cutoff_radius": None if args.cutoff_radius is None else float(args.cutoff_radius),
        "skip_volume": bool(args.skip_volume),
        "all_samples": bool(args.all_samples),
        "no_figures": bool(args.no_figures),
        "resume": bool(args.resume),
        "partial_csv": str(partial_csv),
        "keep_pdgm": bool(args.keep_pdgm),
        "num_representatives": int(len(summary_table)),
        "summary_csv": str(summary_csv),
        "figure_dir": str(figure_dir),
        "interpretation_note": (
            "H1 representatives use HomCloud optimal_1_cycle and, when feasible, "
            "optimal_volume on the cubical bitmap filtration. H0 representatives "
            "use HomCloud H0 birth-death pairs plus a thresholded connected "
            "component localized at the birth position. Results localize "
            "rendered-map topology and should not be interpreted as raw corneal "
            "surface topology."
        ),
    }
    manifest_path = output_dir / "homcloud_representative_manifest.json"
    with manifest_path.open("w", encoding="utf-8") as fp:
        json.dump(manifest, fp, ensure_ascii=False, indent=2)
    return manifest


def main() -> None:
    args = parse_args()
    manifest = run(args)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
