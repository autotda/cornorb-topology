from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

import gudhi as gd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import ndimage

from orbscan_experiment.tda import (
    DEFAULT_TDA_VIEWS,
    IMAGE_PATH_COLUMNS,
    CubicalTDAConfig,
    prepare_orbscan_filtration,
)


STRUCTURE_4 = np.array(
    [
        [0, 1, 0],
        [1, 1, 1],
        [0, 1, 0],
    ],
    dtype=bool,
)


DEFAULT_SAMPLE_IDS = ("125GC_OD", "125GC_OS", "15UG2_OD", "15UG2_OS")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Localize GUDHI persistence-pair anchored representatives for "
            "cubical TDA on rendered Orbscan maps."
        )
    )
    parser.add_argument("--project-dir", default=".")
    parser.add_argument("--metadata-csv", default="experiment_setup/metadata_clean.csv")
    parser.add_argument("--output-dir", default="runs/gudhi_representatives_v1")
    parser.add_argument("--sample-ids", nargs="*", default=list(DEFAULT_SAMPLE_IDS))
    parser.add_argument("--views", nargs="*", default=list(DEFAULT_TDA_VIEWS))
    parser.add_argument("--top-k", type=int, default=2)
    parser.add_argument("--min-lifetime", type=float, default=0.02)
    parser.add_argument(
        "--include-boundary-touching",
        action="store_true",
        help="Allow selected representatives that touch the circular mask boundary.",
    )
    parser.add_argument(
        "--max-support-fraction",
        type=float,
        default=0.30,
        help="Maximum representative support area as a fraction of the circular mask area.",
    )
    parser.add_argument("--image-size", type=int, default=192)
    parser.add_argument("--crop-ratio", type=float, default=0.84)
    parser.add_argument("--mask-radius-ratio", type=float, default=0.48)
    parser.add_argument("--radial-bins", type=int, default=64)
    parser.add_argument("--anomaly-clip-quantile", type=float, default=0.995)
    parser.add_argument("--scalarization", default="luminance_rank")
    parser.add_argument("--no-align-left-right", action="store_true")
    return parser.parse_args()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def flat_index_to_row_col(index: int, shape: tuple[int, int]) -> tuple[int, int]:
    # GUDHI reports top-dimensional cell indices in Fortran order.
    row, col = np.unravel_index(int(index), shape, order="F")
    return int(row), int(col)


def get_persistence_pair_records(
    filtration: np.ndarray,
    *,
    max_dimension: int = 1,
    min_lifetime: float = 0.0,
) -> list[dict[str, Any]]:
    complex_ = gd.CubicalComplex(top_dimensional_cells=filtration.astype(float))
    complex_.compute_persistence(homology_coeff_field=2, min_persistence=-1.0)
    regular_pairs, essential_pairs = complex_.cofaces_of_persistence_pairs()
    flat = filtration.ravel(order="F")

    records: list[dict[str, Any]] = []
    for dimension in range(min(max_dimension + 1, len(regular_pairs))):
        pairs = np.asarray(regular_pairs[dimension], dtype=int)
        if pairs.size == 0:
            continue
        for pair_index, (birth_index, death_index) in enumerate(pairs):
            birth = float(flat[birth_index])
            death = float(flat[death_index])
            lifetime = death - birth
            if not np.isfinite(lifetime) or lifetime < min_lifetime:
                continue
            birth_row, birth_col = flat_index_to_row_col(int(birth_index), filtration.shape)
            death_row, death_col = flat_index_to_row_col(int(death_index), filtration.shape)
            records.append(
                {
                    "dimension": int(dimension),
                    "pair_index": int(pair_index),
                    "birth_index": int(birth_index),
                    "death_index": int(death_index),
                    "birth": birth,
                    "death": death,
                    "lifetime": float(lifetime),
                    "birth_row": birth_row,
                    "birth_col": birth_col,
                    "death_row": death_row,
                    "death_col": death_col,
                }
            )

    for dimension in range(min(max_dimension + 1, len(essential_pairs))):
        for pair_index, birth_index in enumerate(np.asarray(essential_pairs[dimension], dtype=int).reshape(-1)):
            birth = float(flat[birth_index])
            birth_row, birth_col = flat_index_to_row_col(int(birth_index), filtration.shape)
            records.append(
                {
                    "dimension": int(dimension),
                    "pair_index": int(pair_index),
                    "birth_index": int(birth_index),
                    "death_index": -1,
                    "birth": birth,
                    "death": np.inf,
                    "lifetime": np.inf,
                    "birth_row": birth_row,
                    "birth_col": birth_col,
                    "death_row": -1,
                    "death_col": -1,
                }
            )
    return records


def top_records(records: list[dict[str, Any]], *, dimension: int, top_k: int) -> list[dict[str, Any]]:
    selected = [record for record in records if int(record["dimension"]) == dimension and np.isfinite(record["lifetime"])]
    selected.sort(key=lambda item: float(item["lifetime"]), reverse=True)
    return selected[:top_k]


def sorted_records(records: list[dict[str, Any]], *, dimension: int) -> list[dict[str, Any]]:
    selected = [record for record in records if int(record["dimension"]) == dimension and np.isfinite(record["lifetime"])]
    selected.sort(key=lambda item: float(item["lifetime"]), reverse=True)
    return selected


def component_containing(binary: np.ndarray, row: int, col: int) -> tuple[np.ndarray, int]:
    labels, num_labels = ndimage.label(binary.astype(bool), structure=STRUCTURE_4)
    if row < 0 or col < 0 or row >= binary.shape[0] or col >= binary.shape[1]:
        return np.zeros_like(binary, dtype=bool), int(num_labels)
    label = int(labels[row, col])
    if label == 0:
        return np.zeros_like(binary, dtype=bool), int(num_labels)
    return labels == label, int(num_labels)


def touches_mask_boundary(region: np.ndarray, mask: np.ndarray) -> bool:
    eroded = ndimage.binary_erosion(mask.astype(bool), structure=STRUCTURE_4, border_value=0)
    boundary = mask.astype(bool) & ~eroded
    return bool(np.any(region & boundary))


def representative_for_pair(
    filtration: np.ndarray,
    mask: np.ndarray,
    record: dict[str, Any],
) -> dict[str, Any]:
    dimension = int(record["dimension"])
    lifetime = float(record["lifetime"])
    epsilon = max(1e-6, 0.01 * lifetime)
    threshold = float(record["death"]) - epsilon
    active = (filtration <= threshold) & mask.astype(bool)

    if dimension == 0:
        support, _ = component_containing(
            active,
            int(record["birth_row"]),
            int(record["birth_col"]),
        )
        boundary = support & ~ndimage.binary_erosion(support, structure=STRUCTURE_4, border_value=0)
        return {
            "kind": "H0_component",
            "threshold": threshold,
            "support": support,
            "hole": np.zeros_like(support, dtype=bool),
            "boundary": boundary,
            "support_area": int(support.sum()),
            "boundary_area": int(boundary.sum()),
            "touches_mask_boundary": touches_mask_boundary(support, mask),
        }

    if dimension == 1:
        inactive = (filtration > threshold) & mask.astype(bool)
        hole, _ = component_containing(
            inactive,
            int(record["death_row"]),
            int(record["death_col"]),
        )
        # Active cells adjacent to the death-anchored inactive region form a
        # practical cubical representative boundary for the persistent hole.
        dilated_hole = ndimage.binary_dilation(hole, structure=STRUCTURE_4)
        boundary = dilated_hole & active
        support = hole | boundary
        return {
            "kind": "H1_hole_boundary",
            "threshold": threshold,
            "support": support,
            "hole": hole,
            "boundary": boundary,
            "support_area": int(support.sum()),
            "boundary_area": int(boundary.sum()),
            "touches_mask_boundary": touches_mask_boundary(hole, mask),
        }

    raise ValueError(f"Unsupported representative dimension: {dimension}")


def select_representatives(
    *,
    filtration: np.ndarray,
    mask: np.ndarray,
    records: list[dict[str, Any]],
    dimension: int,
    top_k: int,
    include_boundary_touching: bool,
    max_support_fraction: float,
) -> list[tuple[dict[str, Any], dict[str, Any]]]:
    mask_area = max(1, int(mask.astype(bool).sum()))
    max_support_area = int(max_support_fraction * mask_area)
    selected: list[tuple[dict[str, Any], dict[str, Any]]] = []
    fallback: list[tuple[dict[str, Any], dict[str, Any], str]] = []

    for record in sorted_records(records, dimension=dimension):
        representative = representative_for_pair(filtration, mask, record)
        reasons: list[str] = []
        if int(representative["support_area"]) <= 0:
            reasons.append("empty_support")
        if not include_boundary_touching and bool(representative["touches_mask_boundary"]):
            reasons.append("touches_mask_boundary")
        if int(representative["support_area"]) > max_support_area:
            reasons.append("support_too_large")

        if not reasons:
            record_with_rank = dict(record)
            record_with_rank["selected_as_fallback"] = False
            record_with_rank["selection_note"] = "central_nonboundary"
            selected.append((record_with_rank, representative))
            if len(selected) >= top_k:
                break
        elif "empty_support" not in reasons:
            fallback.append((record, representative, ";".join(reasons)))

    if len(selected) < top_k:
        for record, representative, reasons in fallback:
            record_with_rank = dict(record)
            record_with_rank["selected_as_fallback"] = True
            record_with_rank["selection_note"] = f"fallback:{reasons}"
            selected.append((record_with_rank, representative))
            if len(selected) >= top_k:
                break

    for rank, (record, _) in enumerate(selected, start=1):
        record["rank"] = rank
    return selected


def overlay_mask(
    image: np.ndarray,
    mask: np.ndarray,
    color: tuple[float, float, float],
    alpha: float,
) -> np.ndarray:
    rgb = image.astype(np.float32).copy()
    if rgb.max() > 1.0:
        rgb /= 255.0
    color_array = np.asarray(color, dtype=np.float32)
    mask_bool = mask.astype(bool)
    rgb[mask_bool] = (1.0 - alpha) * rgb[mask_bool] + alpha * color_array
    return np.clip(rgb, 0.0, 1.0)


def normalize_gray(array: np.ndarray) -> np.ndarray:
    arr = np.asarray(array, dtype=np.float32)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return np.zeros_like(arr)
    low, high = np.quantile(finite, [0.01, 0.99])
    if high <= low:
        return np.zeros_like(arr)
    return np.clip((arr - low) / (high - low), 0.0, 1.0)


def plot_representatives(
    *,
    sample_id: str,
    label_text: str,
    view: str,
    arrays: dict[str, np.ndarray],
    h0_items: list[tuple[dict[str, Any], dict[str, Any]]],
    h1_items: list[tuple[dict[str, Any], dict[str, Any]]],
    records: list[dict[str, Any]],
    output_path: Path,
) -> None:
    rgb = arrays["rgb"]
    anomaly = normalize_gray(arrays["anomaly"])
    filtration = arrays["filtration"]

    h0_overlay = rgb.copy()
    h1_overlay = rgb.copy()
    colors_h0 = [(0.0, 0.85, 1.0), (0.0, 1.0, 0.45), (1.0, 0.85, 0.0)]
    colors_h1_boundary = [(1.0, 0.05, 0.05), (1.0, 0.45, 0.0), (0.85, 0.0, 1.0)]
    colors_h1_hole = [(0.1, 0.35, 1.0), (0.2, 0.75, 1.0), (0.6, 0.2, 1.0)]

    for index, (_, rep) in enumerate(h0_items):
        h0_overlay = overlay_mask(h0_overlay, rep["support"], colors_h0[index % len(colors_h0)], 0.42)

    for index, (_, rep) in enumerate(h1_items):
        h1_overlay = overlay_mask(h1_overlay, rep["hole"], colors_h1_hole[index % len(colors_h1_hole)], 0.28)
        h1_overlay = overlay_mask(h1_overlay, rep["boundary"], colors_h1_boundary[index % len(colors_h1_boundary)], 0.72)

    fig, axes = plt.subplots(1, 5, figsize=(18, 4.2))
    fig.suptitle(f"{sample_id} ({label_text}) - {view}", fontsize=13, weight="bold")

    axes[0].imshow(rgb)
    axes[0].set_title("Rendered map")
    axes[0].axis("off")

    axes[1].imshow(anomaly, cmap="inferno")
    axes[1].set_title("Anomaly field")
    axes[1].axis("off")

    axes[2].imshow(h0_overlay)
    axes[2].set_title("H0 components")
    axes[2].axis("off")

    axes[3].imshow(h1_overlay)
    axes[3].set_title("H1 hole boundaries")
    axes[3].axis("off")

    for item, marker, color, label in [
        (h0_items, "o", "#08a6c2", "H0 selected"),
        (h1_items, "^", "#d62828", "H1 selected"),
    ]:
        if item:
            axes[4].scatter(
                [record["birth"] for record, _ in item],
                [record["death"] for record, _ in item],
                s=62,
                marker=marker,
                color=color,
                label=label,
                edgecolor="black",
                linewidth=0.4,
            )
    all_finite = [record for record in records if np.isfinite(record["death"]) and record["dimension"] in {0, 1}]
    for dimension, color in [(0, "#8ecae6"), (1, "#f4a0a3")]:
        points = [record for record in all_finite if int(record["dimension"]) == dimension]
        if points:
            axes[4].scatter(
                [record["birth"] for record in points],
                [record["death"] for record in points],
                s=7,
                alpha=0.18,
                color=color,
            )
    axes[4].plot([0, 1.1], [0, 1.1], "--", color="#6b7280", linewidth=0.8)
    axes[4].set_xlim(0, min(1.08, max(1.0, float(np.nanmax(filtration)))))
    axes[4].set_ylim(0, min(1.08, max(1.0, float(np.nanmax(filtration)))))
    axes[4].set_title("Persistence pairs")
    axes[4].set_xlabel("Birth")
    axes[4].set_ylabel("Death")
    axes[4].legend(loc="lower right", fontsize=7)
    axes[4].grid(alpha=0.2)

    for item in h0_items + h1_items:
        record, _ = item
        for key, axis, color in [
            ("birth", axes[1], "#00ff66"),
            ("death", axes[1], "#ff00ff"),
        ]:
            if np.isfinite(record[key]):
                row = int(record[f"{key}_row"])
                col = int(record[f"{key}_col"])
                if row >= 0 and col >= 0:
                    axis.scatter([col], [row], s=20, color=color, edgecolor="black", linewidth=0.3)

    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def run(args: argparse.Namespace) -> dict[str, Any]:
    project_dir = Path(args.project_dir)
    output_dir = project_dir / args.output_dir
    figure_dir = output_dir / "figures"
    ensure_dir(figure_dir)

    metadata = pd.read_csv(project_dir / args.metadata_csv)
    sample_ids = list(args.sample_ids or DEFAULT_SAMPLE_IDS)
    metadata = metadata[metadata["patient_eye_id"].astype(str).isin(sample_ids)].copy()
    if metadata.empty:
        raise ValueError(f"No requested sample ids were found: {sample_ids}")
    metadata["sample_order"] = metadata["patient_eye_id"].astype(str).map({sid: index for index, sid in enumerate(sample_ids)})
    metadata = metadata.sort_values("sample_order")

    config = CubicalTDAConfig(
        project_dir=args.project_dir,
        metadata_csv=args.metadata_csv,
        output_dir=args.output_dir,
        views=tuple(args.views),
        image_size=args.image_size,
        crop_ratio=args.crop_ratio,
        mask_radius_ratio=args.mask_radius_ratio,
        radial_bins=args.radial_bins,
        anomaly_clip_quantile=args.anomaly_clip_quantile,
        scalarization=args.scalarization,
        align_left_right=not args.no_align_left_right,
    )

    rows: list[dict[str, Any]] = []
    for _, row in metadata.iterrows():
        sample_id = str(row["patient_eye_id"])
        label_text = str(row.get("label_text", row.get("label", "")))
        eye = str(row["eye"])
        for view in args.views:
            arrays = prepare_orbscan_filtration(
                image_path=row[IMAGE_PATH_COLUMNS[view]],
                view=view,
                eye=eye,
                config=config,
            )
            filtration = arrays["filtration"]
            mask = arrays["mask"] > 0.5
            records = get_persistence_pair_records(
                filtration,
                max_dimension=1,
                min_lifetime=args.min_lifetime,
            )

            h0_items = select_representatives(
                filtration=filtration,
                mask=mask,
                records=records,
                dimension=0,
                top_k=args.top_k,
                include_boundary_touching=args.include_boundary_touching,
                max_support_fraction=args.max_support_fraction,
            )
            h1_items = select_representatives(
                filtration=filtration,
                mask=mask,
                records=records,
                dimension=1,
                top_k=args.top_k,
                include_boundary_touching=args.include_boundary_touching,
                max_support_fraction=args.max_support_fraction,
            )

            figure_path = figure_dir / f"{sample_id}_{view}_gudhi_representatives.png"
            plot_representatives(
                sample_id=sample_id,
                label_text=label_text,
                view=view,
                arrays=arrays,
                h0_items=h0_items,
                h1_items=h1_items,
                records=records,
                output_path=figure_path,
            )

            for record, representative in h0_items + h1_items:
                rows.append(
                    {
                        "patient_eye_id": sample_id,
                        "label": int(row["label"]),
                        "label_text": label_text,
                        "view": view,
                        "dimension": int(record["dimension"]),
                        "rank": int(record["rank"]),
                        "birth": float(record["birth"]),
                        "death": float(record["death"]),
                        "lifetime": float(record["lifetime"]),
                        "birth_row": int(record["birth_row"]),
                        "birth_col": int(record["birth_col"]),
                        "death_row": int(record["death_row"]),
                        "death_col": int(record["death_col"]),
                        "representative_kind": representative["kind"],
                        "threshold": float(representative["threshold"]),
                        "support_area_px": int(representative["support_area"]),
                        "boundary_area_px": int(representative["boundary_area"]),
                        "touches_mask_boundary": bool(representative["touches_mask_boundary"]),
                        "selected_as_fallback": bool(record.get("selected_as_fallback", False)),
                        "selection_note": str(record.get("selection_note", "")),
                        "figure_path": str(figure_path),
                    }
                )

    representative_table = pd.DataFrame(rows)
    representative_table.to_csv(output_dir / "gudhi_representative_summary.csv", index=False, encoding="utf-8-sig")

    summary = {
        "config": asdict(config),
        "sample_ids": sample_ids,
        "views": list(args.views),
        "top_k": int(args.top_k),
        "min_lifetime": float(args.min_lifetime),
        "include_boundary_touching": bool(args.include_boundary_touching),
        "max_support_fraction": float(args.max_support_fraction),
        "num_representatives": int(len(representative_table)),
        "summary_csv": str(output_dir / "gudhi_representative_summary.csv"),
        "figure_dir": str(figure_dir),
        "interpretation_note": (
            "H0 representatives are death-epsilon connected abnormal components. "
            "H1 representatives are death-coface anchored inactive holes and their active boundaries. "
            "They localize GUDHI persistence pairs in rendered-map space and should not be overclaimed "
            "as a separate cycle-minimization algorithm."
        ),
    }
    with (output_dir / "gudhi_representative_manifest.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    args = parse_args()
    summary = run(args)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
