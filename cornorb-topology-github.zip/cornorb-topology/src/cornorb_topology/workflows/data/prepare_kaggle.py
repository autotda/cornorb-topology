from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit


KAGGLE_VIEWS = ("ct_a", "ec_a", "ec_p", "elv_a", "elv_p", "sag_a", "sag_p")
VIEW_SUFFIXES = {
    "ct_a": "CT_A",
    "ec_a": "EC_A",
    "ec_p": "EC_P",
    "elv_a": "Elv_A",
    "elv_p": "Elv_P",
    "sag_a": "Sag_A",
    "sag_p": "Sag_P",
}
CLASS_TO_LABEL = {"Normal": 0, "Keratoconus": 1, "Suspect": -1}


def _find_split_root(dataset_root: Path, split_name: str) -> Path:
    candidates = [
        dataset_root / split_name / split_name,
        dataset_root / split_name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Cannot find split root for {split_name} under {dataset_root}")


def _find_view_file(case_dir: Path, suffix: str) -> Path:
    matches = [path for path in case_dir.glob("*.jpg") if path.stem.endswith(suffix)]
    if len(matches) != 1:
        raise ValueError(f"Expected one *_{suffix}.jpg in {case_dir}, found {len(matches)}")
    return matches[0]


def _scan_split(split_root: Path, split_source: str) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for class_name, label in CLASS_TO_LABEL.items():
        class_dir = split_root / class_name
        if not class_dir.exists():
            continue
        for case_dir in sorted([path for path in class_dir.iterdir() if path.is_dir()], key=lambda p: p.name.lower()):
            patient_eye_id = f"kaggle_{split_source}_{class_name.lower()}_{case_dir.name.lower()}"
            row: dict[str, object] = {
                "patient_eye_id": patient_eye_id,
                "patient_code": patient_eye_id,
                "eye": "OD",
                "case_id": case_dir.name,
                "split_source": split_source,
                "label": label,
                "label_text": class_name,
            }
            for view, suffix in VIEW_SUFFIXES.items():
                row[f"image_{view}_path"] = str(_find_view_file(case_dir, suffix).resolve())
            rows.append(row)
    return rows


def prepare_manifests(
    dataset_root: Path,
    output_dir: Path,
    *,
    valid_fraction: float,
    seed: int,
) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    train_valid_root = _find_split_root(dataset_root, "Train_Validation sets")
    test_root = _find_split_root(dataset_root, "Independent Test Set")

    rows = []
    rows.extend(_scan_split(train_valid_root, split_source="train_validation"))
    rows.extend(_scan_split(test_root, split_source="independent_test"))
    manifest = pd.DataFrame(rows)
    manifest.to_csv(output_dir / "kaggle_all_manifest.csv", index=False, encoding="utf-8-sig")

    development_binary = manifest[
        (manifest["split_source"] == "train_validation") & manifest["label"].isin([0, 1])
    ].reset_index(drop=True)
    test_binary = manifest[
        (manifest["split_source"] == "independent_test") & manifest["label"].isin([0, 1])
    ].reset_index(drop=True)
    test_suspect = manifest[
        (manifest["split_source"] == "independent_test") & (manifest["label_text"] == "Suspect")
    ].reset_index(drop=True)

    splitter = StratifiedShuffleSplit(n_splits=1, test_size=valid_fraction, random_state=seed)
    train_idx, valid_idx = next(splitter.split(development_binary, development_binary["label"]))
    train_binary = development_binary.iloc[train_idx].sort_values("patient_eye_id").reset_index(drop=True)
    valid_binary = development_binary.iloc[valid_idx].sort_values("patient_eye_id").reset_index(drop=True)

    development_binary.to_csv(output_dir / "development_binary.csv", index=False, encoding="utf-8-sig")
    train_binary.to_csv(output_dir / "train_binary.csv", index=False, encoding="utf-8-sig")
    valid_binary.to_csv(output_dir / "valid_binary.csv", index=False, encoding="utf-8-sig")
    test_binary.to_csv(output_dir / "test_binary.csv", index=False, encoding="utf-8-sig")
    test_suspect.to_csv(output_dir / "test_suspect.csv", index=False, encoding="utf-8-sig")

    counts = (
        manifest.groupby(["split_source", "label_text"], as_index=False)
        .size()
        .rename(columns={"size": "num_cases"})
        .sort_values(["split_source", "label_text"])
    )
    counts.to_csv(output_dir / "class_counts.csv", index=False, encoding="utf-8-sig")

    summary = {
        "dataset_root": str(dataset_root.resolve()),
        "output_dir": str(output_dir.resolve()),
        "views": list(KAGGLE_VIEWS),
        "valid_fraction": valid_fraction,
        "seed": seed,
        "manifest_rows": int(len(manifest)),
        "development_binary_rows": int(len(development_binary)),
        "train_binary_rows": int(len(train_binary)),
        "valid_binary_rows": int(len(valid_binary)),
        "test_binary_rows": int(len(test_binary)),
        "test_suspect_rows": int(len(test_suspect)),
        "class_counts": counts.to_dict(orient="records"),
    }
    with (output_dir / "manifest_summary.json").open("w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare Kaggle keratoconus exploratory-replication manifests.")
    parser.add_argument("--dataset-root", required=True, help="Locally downloaded Kaggle dataset directory.")
    parser.add_argument("--output-dir", default="experiment_setup/kaggle_replication")
    parser.add_argument("--valid-fraction", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=20260507)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = prepare_manifests(
        dataset_root=Path(args.dataset_root),
        output_dir=Path(args.output_dir),
        valid_fraction=args.valid_fraction,
        seed=args.seed,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
