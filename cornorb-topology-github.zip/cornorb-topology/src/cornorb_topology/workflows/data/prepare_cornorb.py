from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit


PROJECT_DIR = Path.cwd()
DATASET_ROOT = Path("data/cornorb")
IMAGE_ROOT = DATASET_ROOT / "ORBSCAN_Dataset" / "ORBSCAN_Dataset"
CSV_PATH = DATASET_ROOT / "clinical_data_and_labels.csv"
OUTPUT_DIR = PROJECT_DIR / "experiment_setup"
SPLIT_DIR = OUTPUT_DIR / "splits"
NESTED_DIR = SPLIT_DIR / "nested_cv"

SEED = 20260320
LOCKED_TEST_RATIO = 0.15
OUTER_FOLDS = 5
OUTER_REPEATS = 3
INNER_FOLDS = 4

MODALITIES = ["Anterior", "Posterior", "Axial", "Pachymetry"]
NUMERIC_COLUMNS = [
    "age_years",
    "astig_value_D",
    "astig_axis_deg",
    "kmax_value_D",
    "kmax_axis_deg",
    "pachy_central_um",
    "pachy_thinnest_um",
    "pachy_thinnest_x",
    "pachy_thinnest_y",
    "asphericity_anterior",
    "asphericity_posterior",
]
CATEGORICAL_COLUMNS = ["gender", "label"]


@dataclass
class SplitCounts:
    patients: int
    eyes: int
    positives: int
    negatives: int


def ensure_directories() -> None:
    for path in [OUTPUT_DIR, SPLIT_DIR, NESTED_DIR]:
        path.mkdir(parents=True, exist_ok=True)


def load_raw_clinical() -> pd.DataFrame:
    df = pd.read_csv(CSV_PATH, dtype={"patient_code": str, "eye": str})
    df.insert(0, "source_row_number", np.arange(2, len(df) + 2))
    df["patient_code"] = df["patient_code"].replace({"3E+132": "3E132"})
    df["eye"] = df["eye"].astype(str).str.upper().str.strip()
    df["gender"] = df["gender"].astype(str).str.lower().str.strip()
    for col in NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["label"] = pd.to_numeric(df["label"], errors="coerce").astype("Int64")
    return df


def collect_image_manifest() -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for patient_dir in sorted(IMAGE_ROOT.iterdir()):
        if not patient_dir.is_dir():
            continue
        patient_code = patient_dir.name
        for eye_dir in sorted(patient_dir.iterdir()):
            if not eye_dir.is_dir():
                continue
            eye = eye_dir.name.upper().strip()
            record: dict[str, object] = {
                "patient_code": patient_code,
                "eye": eye,
                "image_dir": str(eye_dir),
            }
            found_modalities = set()
            for image_path in sorted(eye_dir.glob("*.png")):
                for modality in MODALITIES:
                    suffix = f"_{modality}.png"
                    if image_path.name.endswith(suffix):
                        key = f"image_{modality.lower()}_path"
                        record[key] = str(image_path)
                        found_modalities.add(modality)
                        break
            record["image_count"] = len(found_modalities)
            record["has_all_modalities"] = len(found_modalities) == len(MODALITIES)
            rows.append(record)
    manifest = pd.DataFrame(rows)
    missing_cols = [f"image_{m.lower()}_path" for m in MODALITIES if f"image_{m.lower()}_path" not in manifest.columns]
    for col in missing_cols:
        manifest[col] = pd.NA
    return manifest.sort_values(["patient_code", "eye"]).reset_index(drop=True)


def _mode_or_first(series: pd.Series):
    valid = series.dropna()
    if valid.empty:
        return pd.NA
    modes = valid.mode(dropna=True)
    return modes.iloc[0] if not modes.empty else valid.iloc[0]


def aggregate_clinical(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    clean_rows: list[dict[str, object]] = []
    conflict_rows: list[dict[str, object]] = []

    grouped = df.groupby(["patient_code", "eye"], sort=True, dropna=False)
    for (patient_code, eye), group in grouped:
        row: dict[str, object] = {
            "patient_code": patient_code,
            "eye": eye,
            "source_row_count": int(len(group)),
            "source_row_numbers": ";".join(str(x) for x in group["source_row_number"].tolist()),
        }

        conflict_fields: list[str] = []
        for col in NUMERIC_COLUMNS:
            row[col] = float(group[col].median()) if group[col].notna().any() else np.nan
            unique_values = group[col].dropna().round(6).unique()
            if len(unique_values) > 1:
                conflict_fields.append(col)
        for col in CATEGORICAL_COLUMNS:
            row[col] = _mode_or_first(group[col])
            unique_values = group[col].dropna().astype(str).unique()
            if len(unique_values) > 1:
                conflict_fields.append(col)

        row["had_duplicate_rows"] = bool(len(group) > 1)
        row["had_conflicting_clinical_values"] = bool(len(conflict_fields) > 0)
        row["conflict_fields"] = ";".join(conflict_fields)

        clean_rows.append(row)

        if len(group) > 1:
            audit_row: dict[str, object] = {
                "patient_code": patient_code,
                "eye": eye,
                "source_row_count": int(len(group)),
                "conflict_fields": ";".join(conflict_fields),
                "source_row_numbers": ";".join(str(x) for x in group["source_row_number"].tolist()),
            }
            for col in NUMERIC_COLUMNS:
                non_null = group[col].dropna()
                audit_row[f"{col}_values"] = ";".join(str(x) for x in non_null.tolist())
                audit_row[f"{col}_min"] = float(non_null.min()) if not non_null.empty else np.nan
                audit_row[f"{col}_max"] = float(non_null.max()) if not non_null.empty else np.nan
                audit_row[f"{col}_range"] = (
                    float(non_null.max() - non_null.min()) if len(non_null) >= 2 else 0.0
                )
            for col in CATEGORICAL_COLUMNS:
                audit_row[f"{col}_values"] = ";".join(str(x) for x in group[col].tolist())
            conflict_rows.append(audit_row)

    clean_df = pd.DataFrame(clean_rows).sort_values(["patient_code", "eye"]).reset_index(drop=True)
    audit_df = pd.DataFrame(conflict_rows).sort_values(["patient_code", "eye"]).reset_index(drop=True)
    clean_df["label"] = clean_df["label"].astype(int)
    return clean_df, audit_df


def build_metadata(clean_clinical: pd.DataFrame, image_manifest: pd.DataFrame) -> pd.DataFrame:
    metadata = image_manifest.merge(clean_clinical, on=["patient_code", "eye"], how="left", validate="one_to_one")
    if metadata[["gender", "label"]].isna().any().any():
        missing = metadata[metadata["label"].isna()][["patient_code", "eye"]]
        raise ValueError(f"Metadata has image rows without labels: {missing.to_dict(orient='records')[:5]}")
    metadata["patient_eye_id"] = metadata["patient_code"] + "_" + metadata["eye"]
    metadata["n_modalities"] = metadata["image_count"].astype(int)
    metadata["label_text"] = metadata["label"].map({0: "normal", 1: "keratoconus"})
    ordered_cols = (
        ["patient_eye_id", "patient_code", "eye", "label", "label_text", "gender"]
        + NUMERIC_COLUMNS
        + [
            "image_dir",
            "image_anterior_path",
            "image_posterior_path",
            "image_axial_path",
            "image_pachymetry_path",
            "n_modalities",
            "has_all_modalities",
            "source_row_count",
            "had_duplicate_rows",
            "had_conflicting_clinical_values",
            "conflict_fields",
            "source_row_numbers",
        ]
    )
    return metadata[ordered_cols].sort_values(["patient_code", "eye"]).reset_index(drop=True)


def build_patient_profile(metadata: pd.DataFrame) -> pd.DataFrame:
    patient_rows: list[dict[str, object]] = []
    for patient_code, group in metadata.groupby("patient_code", sort=True):
        labels = sorted(group["label"].astype(int).tolist())
        n_eyes = int(len(group))
        n_positive = int(sum(labels))
        n_negative = int(n_eyes - n_positive)
        if n_eyes == 1 and labels == [0]:
            profile = "single_normal"
        elif n_eyes == 1 and labels == [1]:
            profile = "single_kc"
        elif n_eyes == 2 and labels == [0, 0]:
            profile = "bilateral_normal"
        elif n_eyes == 2 and labels == [1, 1]:
            profile = "bilateral_kc"
        elif n_eyes == 2 and labels == [0, 1]:
            profile = "bilateral_mixed"
        else:
            profile = "other"
        patient_rows.append(
            {
                "patient_code": patient_code,
                "patient_profile": profile,
                "n_eyes": n_eyes,
                "n_positive_eyes": n_positive,
                "n_negative_eyes": n_negative,
                "label_pattern": "-".join(str(x) for x in labels),
                "had_any_duplicate_rows": bool(group["had_duplicate_rows"].any()),
                "had_any_conflicting_clinical_values": bool(group["had_conflicting_clinical_values"].any()),
            }
        )
    return pd.DataFrame(patient_rows).sort_values("patient_code").reset_index(drop=True)


def summarize_subset(metadata: pd.DataFrame, patients: pd.DataFrame) -> SplitCounts:
    patient_codes = set(patients["patient_code"].tolist())
    eyes = metadata[metadata["patient_code"].isin(patient_codes)]
    positives = int((eyes["label"] == 1).sum())
    negatives = int((eyes["label"] == 0).sum())
    return SplitCounts(
        patients=int(len(patients)),
        eyes=int(len(eyes)),
        positives=positives,
        negatives=negatives,
    )


def write_subset_csvs(base_dir: Path, metadata: pd.DataFrame, patients: pd.DataFrame, prefix: str) -> None:
    base_dir.mkdir(parents=True, exist_ok=True)
    patient_codes = set(patients["patient_code"].tolist())
    eyes = metadata[metadata["patient_code"].isin(patient_codes)].copy()
    patients.to_csv(base_dir / f"{prefix}_patients.csv", index=False, encoding="utf-8-sig")
    eyes.to_csv(base_dir / f"{prefix}_eyes.csv", index=False, encoding="utf-8-sig")


def split_locked_test(patient_profile: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    splitter = StratifiedShuffleSplit(
        n_splits=1,
        test_size=LOCKED_TEST_RATIO,
        random_state=SEED,
    )
    X = patient_profile[["patient_code"]]
    y = patient_profile["patient_profile"]
    train_idx, test_idx = next(splitter.split(X, y))
    development = patient_profile.iloc[train_idx].sort_values("patient_code").reset_index(drop=True)
    locked_test = patient_profile.iloc[test_idx].sort_values("patient_code").reset_index(drop=True)
    return development, locked_test


def generate_nested_cv(metadata: pd.DataFrame, development: pd.DataFrame) -> dict[str, object]:
    nested_records_patients: list[dict[str, object]] = []
    nested_records_eyes: list[dict[str, object]] = []
    summary: dict[str, object] = {"outer_repeats": []}

    dev_codes = set(development["patient_code"].tolist())
    dev_eyes = metadata[metadata["patient_code"].isin(dev_codes)].copy()

    X_dev = development[["patient_code"]]
    y_dev = development["patient_profile"]

    for repeat_idx in range(1, OUTER_REPEATS + 1):
        repeat_seed = SEED + repeat_idx
        outer_cv = StratifiedKFold(n_splits=OUTER_FOLDS, shuffle=True, random_state=repeat_seed)
        repeat_summary: dict[str, object] = {"repeat": repeat_idx, "folds": []}

        for fold_idx, (outer_train_idx, outer_valid_idx) in enumerate(outer_cv.split(X_dev, y_dev), start=1):
            outer_dir = NESTED_DIR / f"repeat_{repeat_idx:02d}" / f"outer_fold_{fold_idx:02d}"
            outer_dir.mkdir(parents=True, exist_ok=True)

            outer_train_patients = development.iloc[outer_train_idx].sort_values("patient_code").reset_index(drop=True)
            outer_valid_patients = development.iloc[outer_valid_idx].sort_values("patient_code").reset_index(drop=True)

            write_subset_csvs(outer_dir, metadata, outer_train_patients, "outer_train")
            write_subset_csvs(outer_dir, metadata, outer_valid_patients, "outer_valid")

            for _, row in outer_train_patients.iterrows():
                nested_records_patients.append(
                    {
                        "repeat": repeat_idx,
                        "outer_fold": fold_idx,
                        "split": "outer_train",
                        **row.to_dict(),
                    }
                )
            for _, row in outer_valid_patients.iterrows():
                nested_records_patients.append(
                    {
                        "repeat": repeat_idx,
                        "outer_fold": fold_idx,
                        "split": "outer_valid",
                        **row.to_dict(),
                    }
                )

            outer_train_codes = set(outer_train_patients["patient_code"].tolist())
            outer_valid_codes = set(outer_valid_patients["patient_code"].tolist())
            for _, row in dev_eyes[dev_eyes["patient_code"].isin(outer_train_codes)].iterrows():
                nested_records_eyes.append(
                    {
                        "repeat": repeat_idx,
                        "outer_fold": fold_idx,
                        "split": "outer_train",
                        "patient_eye_id": row["patient_eye_id"],
                        "patient_code": row["patient_code"],
                        "eye": row["eye"],
                        "label": row["label"],
                    }
                )
            for _, row in dev_eyes[dev_eyes["patient_code"].isin(outer_valid_codes)].iterrows():
                nested_records_eyes.append(
                    {
                        "repeat": repeat_idx,
                        "outer_fold": fold_idx,
                        "split": "outer_valid",
                        "patient_eye_id": row["patient_eye_id"],
                        "patient_code": row["patient_code"],
                        "eye": row["eye"],
                        "label": row["label"],
                    }
                )

            inner_summary_rows: list[dict[str, object]] = []
            inner_records_patients: list[dict[str, object]] = []
            inner_records_eyes: list[dict[str, object]] = []

            inner_cv = StratifiedKFold(
                n_splits=INNER_FOLDS,
                shuffle=True,
                random_state=SEED + 100 * repeat_idx + fold_idx,
            )
            X_inner = outer_train_patients[["patient_code"]]
            y_inner = outer_train_patients["patient_profile"]

            for inner_fold_idx, (inner_train_idx, inner_valid_idx) in enumerate(inner_cv.split(X_inner, y_inner), start=1):
                inner_train_patients = outer_train_patients.iloc[inner_train_idx].sort_values("patient_code").reset_index(drop=True)
                inner_valid_patients = outer_train_patients.iloc[inner_valid_idx].sort_values("patient_code").reset_index(drop=True)

                inner_train_codes = set(inner_train_patients["patient_code"].tolist())
                inner_valid_codes = set(inner_valid_patients["patient_code"].tolist())

                for _, row in inner_train_patients.iterrows():
                    inner_records_patients.append(
                        {
                            "inner_fold": inner_fold_idx,
                            "split": "inner_train",
                            **row.to_dict(),
                        }
                    )
                for _, row in inner_valid_patients.iterrows():
                    inner_records_patients.append(
                        {
                            "inner_fold": inner_fold_idx,
                            "split": "inner_valid",
                            **row.to_dict(),
                        }
                    )

                for _, row in dev_eyes[dev_eyes["patient_code"].isin(inner_train_codes)].iterrows():
                    inner_records_eyes.append(
                        {
                            "inner_fold": inner_fold_idx,
                            "split": "inner_train",
                            "patient_eye_id": row["patient_eye_id"],
                            "patient_code": row["patient_code"],
                            "eye": row["eye"],
                            "label": row["label"],
                        }
                    )
                for _, row in dev_eyes[dev_eyes["patient_code"].isin(inner_valid_codes)].iterrows():
                    inner_records_eyes.append(
                        {
                            "inner_fold": inner_fold_idx,
                            "split": "inner_valid",
                            "patient_eye_id": row["patient_eye_id"],
                            "patient_code": row["patient_code"],
                            "eye": row["eye"],
                            "label": row["label"],
                        }
                    )

                inner_summary_rows.append(
                    {
                        "inner_fold": inner_fold_idx,
                        "inner_train_patients": int(len(inner_train_patients)),
                        "inner_valid_patients": int(len(inner_valid_patients)),
                        "inner_train_eyes": int((dev_eyes["patient_code"].isin(inner_train_codes)).sum()),
                        "inner_valid_eyes": int((dev_eyes["patient_code"].isin(inner_valid_codes)).sum()),
                    }
                )

            pd.DataFrame(inner_records_patients).to_csv(
                outer_dir / "inner_folds_patients.csv", index=False, encoding="utf-8-sig"
            )
            pd.DataFrame(inner_records_eyes).to_csv(
                outer_dir / "inner_folds_eyes.csv", index=False, encoding="utf-8-sig"
            )
            pd.DataFrame(inner_summary_rows).to_csv(
                outer_dir / "inner_folds_summary.csv", index=False, encoding="utf-8-sig"
            )

            train_counts = summarize_subset(metadata, outer_train_patients)
            valid_counts = summarize_subset(metadata, outer_valid_patients)
            repeat_summary["folds"].append(
                {
                    "outer_fold": fold_idx,
                    "outer_train_patients": train_counts.patients,
                    "outer_train_eyes": train_counts.eyes,
                    "outer_train_positive_eyes": train_counts.positives,
                    "outer_valid_patients": valid_counts.patients,
                    "outer_valid_eyes": valid_counts.eyes,
                    "outer_valid_positive_eyes": valid_counts.positives,
                }
            )

        summary["outer_repeats"].append(repeat_summary)

    pd.DataFrame(nested_records_patients).to_csv(
        SPLIT_DIR / "nested_cv_assignments_patients.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(nested_records_eyes).to_csv(
        SPLIT_DIR / "nested_cv_assignments_eyes.csv", index=False, encoding="utf-8-sig"
    )
    return summary


def write_protocol_markdown() -> None:
    text = f"""# Strict Experiment Protocol

## Scope
- Dataset root: `{DATASET_ROOT}`
- Canonical image root: `{IMAGE_ROOT}`
- Raw clinical CSV: `{CSV_PATH}`

## Cleaning rules
- Use image directories as the canonical eye-level inventory.
- Normalize patient code `3E+132` to `3E132`.
- Use `(patient_code, eye)` as the unique key.
- Aggregate duplicated clinical rows by median for numeric fields and mode for categorical fields.
- Keep duplicate/conflict audit columns so the repeated-eye issue remains traceable.

## Split rules
- Unit of leakage control: `patient_code`
- Locked test set: `{int(LOCKED_TEST_RATIO * 100)}%` of patients, stratified by patient profile.
- Development set: remaining patients only.
- Outer CV: `{OUTER_REPEATS}` repeats x `{OUTER_FOLDS}` folds, stratified at patient level.
- Inner CV: `{INNER_FOLDS}` folds inside each outer-train partition.

## Patient profiles used for stratification
- `single_normal`
- `single_kc`
- `bilateral_normal`
- `bilateral_kc`
- `bilateral_mixed` (reserved when present)

## Red lines
- Never split two eyes from the same patient across different folds.
- Never fit normalization, calibration, feature selection, or thresholding outside the current training fold.
- Never use locked test results for hyperparameter tuning.
"""
    (OUTPUT_DIR / "split_protocol.md").write_text(text, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare CornOrb metadata and patient-grouped nested CV splits.")
    parser.add_argument("--dataset-root", required=True, help="Directory containing the original CSV and extracted images.")
    parser.add_argument("--project-dir", default=".", help="Local experiment workspace.")
    parser.add_argument("--image-root", default=None, help="Override the extracted ORBSCAN_Dataset/ORBSCAN_Dataset image directory.")
    parser.add_argument("--clinical-csv", default=None, help="Override the original clinical CSV.")
    parser.add_argument("--output-dir", default="experiment_setup", help="Manifest directory, relative to project-dir unless absolute.")
    parser.add_argument("--seed", type=int, default=20260320)
    parser.add_argument("--locked-test-ratio", type=float, default=0.15)
    parser.add_argument("--outer-folds", type=int, default=5)
    parser.add_argument("--outer-repeats", type=int, default=3)
    parser.add_argument("--inner-folds", type=int, default=4)
    return parser.parse_args()


def main() -> None:
    global PROJECT_DIR, DATASET_ROOT, IMAGE_ROOT, CSV_PATH, OUTPUT_DIR, SPLIT_DIR, NESTED_DIR
    global SEED, LOCKED_TEST_RATIO, OUTER_FOLDS, OUTER_REPEATS, INNER_FOLDS
    args = parse_args()
    if not 0 < args.locked_test_ratio < 1:
        raise ValueError("locked-test-ratio must be between 0 and 1.")
    if args.outer_folds < 2 or args.inner_folds < 2 or args.outer_repeats < 1:
        raise ValueError("CV requires at least two folds and one repeat.")
    PROJECT_DIR = Path(args.project_dir).resolve()
    DATASET_ROOT = Path(args.dataset_root).resolve()
    IMAGE_ROOT = Path(args.image_root).resolve() if args.image_root else DATASET_ROOT / "ORBSCAN_Dataset" / "ORBSCAN_Dataset"
    CSV_PATH = Path(args.clinical_csv).resolve() if args.clinical_csv else DATASET_ROOT / "clinical_data_and_labels.csv"
    OUTPUT_DIR = PROJECT_DIR / args.output_dir
    SPLIT_DIR = OUTPUT_DIR / "splits"
    NESTED_DIR = SPLIT_DIR / "nested_cv"
    SEED, LOCKED_TEST_RATIO = args.seed, args.locked_test_ratio
    OUTER_FOLDS, OUTER_REPEATS, INNER_FOLDS = args.outer_folds, args.outer_repeats, args.inner_folds
    if not CSV_PATH.is_file():
        raise FileNotFoundError(f"Clinical CSV not found: {CSV_PATH}")
    if not IMAGE_ROOT.is_dir():
        raise FileNotFoundError(f"Image directory not found: {IMAGE_ROOT}; use --image-root for a different extraction layout.")
    if (OUTPUT_DIR / "metadata_clean.csv").exists() or SPLIT_DIR.exists():
        raise FileExistsError("Manifest/split output already exists. Use a new --output-dir; existing split definitions are not overwritten.")
    ensure_directories()
    raw_clinical = load_raw_clinical()
    image_manifest = collect_image_manifest()
    clean_clinical, duplicate_audit = aggregate_clinical(raw_clinical)
    metadata = build_metadata(clean_clinical, image_manifest)
    patient_profile = build_patient_profile(metadata)

    metadata_clean_path = OUTPUT_DIR / "metadata_clean.csv"
    metadata_high_conf_path = OUTPUT_DIR / "metadata_high_confidence.csv"
    patient_profile_path = OUTPUT_DIR / "patient_profile.csv"
    duplicate_audit_path = OUTPUT_DIR / "duplicate_conflict_audit.csv"

    metadata.to_csv(metadata_clean_path, index=False, encoding="utf-8-sig")
    metadata[~metadata["had_conflicting_clinical_values"]].to_csv(
        metadata_high_conf_path, index=False, encoding="utf-8-sig"
    )
    patient_profile.to_csv(patient_profile_path, index=False, encoding="utf-8-sig")
    duplicate_audit.to_csv(duplicate_audit_path, index=False, encoding="utf-8-sig")

    development, locked_test = split_locked_test(patient_profile)
    write_subset_csvs(SPLIT_DIR, metadata, development, "development")
    write_subset_csvs(SPLIT_DIR, metadata, locked_test, "locked_test")

    nested_summary = generate_nested_cv(metadata, development)
    write_protocol_markdown()

    summary = {
        "seed": SEED,
        "locked_test_ratio": LOCKED_TEST_RATIO,
        "outer_repeats": OUTER_REPEATS,
        "outer_folds": OUTER_FOLDS,
        "inner_folds": INNER_FOLDS,
        "raw_csv_rows": int(len(raw_clinical)),
        "image_eye_rows": int(len(image_manifest)),
        "clean_eye_rows": int(len(metadata)),
        "high_confidence_eye_rows": int((~metadata["had_conflicting_clinical_values"]).sum()),
        "duplicate_groups": int((clean_clinical["source_row_count"] > 1).sum()),
        "conflicting_duplicate_groups": int(duplicate_audit["conflict_fields"].astype(str).ne("").sum()),
        "patient_profiles": patient_profile["patient_profile"].value_counts().to_dict(),
        "development_counts": summarize_subset(metadata, development).__dict__,
        "locked_test_counts": summarize_subset(metadata, locked_test).__dict__,
        "nested_summary": nested_summary,
    }
    with (OUTPUT_DIR / "split_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
