"""Local dataset manifests and split preparation."""
