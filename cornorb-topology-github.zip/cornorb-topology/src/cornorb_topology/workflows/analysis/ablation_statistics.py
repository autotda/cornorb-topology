from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon


DEFAULT_GROUPS = (
    "image_only",
    "clinical_only",
    "tda_only",
    "image_clinical",
    "image_tda",
    "image_clinical_tda",
)

DEFAULT_SUMMARY_METRICS = (
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "precision",
    "recall",
    "specificity",
    "mcc",
    "brier_score",
    "ece_10",
    "recall_at_95_specificity",
)

DEFAULT_COMPARISON_METRICS = (
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "mcc",
)

DEFAULT_COMPARISONS = (
    ("tda_only", "clinical_only"),
    ("tda_only", "image_only"),
    ("image_clinical_tda", "image_only"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compute 95% CI and paired significance tests for ablation results.")
    parser.add_argument("--runs-root", default="runs/ablation_suite_v1", help="Root directory containing ablation outputs.")
    parser.add_argument("--output-dir", default="runs/ablation_suite_v1/statistics", help="Directory for statistics outputs.")
    parser.add_argument("--bootstrap-samples", type=int, default=10000, help="Bootstrap resamples for CI estimation.")
    parser.add_argument("--seed", type=int, default=20260326, help="Random seed for bootstrap.")
    return parser.parse_args()


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_metrics_table(runs_root: Path, group: str) -> pd.DataFrame:
    path = runs_root / group / "outer_cv_metrics.csv"
    df = pd.read_csv(path)
    df["group"] = group
    return df


def _bootstrap_mean_ci(values: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    if values.size == 0:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(n_boot, values.size))
    means = values[indices].mean(axis=1)
    lower, upper = np.quantile(means, [0.025, 0.975])
    return float(lower), float(upper)


def _bootstrap_diff_ci(differences: np.ndarray, *, n_boot: int, seed: int) -> tuple[float, float]:
    return _bootstrap_mean_ci(differences, n_boot=n_boot, seed=seed)


def _wilcoxon_pvalue(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    diff = a - b
    if np.allclose(diff, 0.0):
        return 0.0, 1.0
    stat, pvalue = wilcoxon(a, b, zero_method="wilcox", alternative="two-sided", method="auto")
    return float(stat), float(pvalue)


def _holm_adjust(pvalues: Iterable[float]) -> list[float]:
    pvalues = list(float(p) for p in pvalues)
    m = len(pvalues)
    indexed = sorted(enumerate(pvalues), key=lambda item: item[1])
    adjusted = [0.0] * m
    running_max = 0.0
    for rank, (original_idx, pvalue) in enumerate(indexed, start=1):
        adj = min(1.0, (m - rank + 1) * pvalue)
        running_max = max(running_max, adj)
        adjusted[original_idx] = running_max
    return adjusted


def build_summary_table(
    tables: dict[str, pd.DataFrame],
    metrics: Iterable[str],
    *,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for group, df in tables.items():
        for metric in metrics:
            values = df[metric].to_numpy(dtype=float)
            ci_low, ci_high = _bootstrap_mean_ci(values, n_boot=n_boot, seed=seed)
            rows.append(
                {
                    "group": group,
                    "metric": metric,
                    "n_folds": int(values.size),
                    "mean": float(values.mean()),
                    "std": float(values.std(ddof=0)),
                    "ci95_low": ci_low,
                    "ci95_high": ci_high,
                }
            )
    return pd.DataFrame(rows)


def build_pairwise_table(
    tables: dict[str, pd.DataFrame],
    comparisons: Iterable[tuple[str, str]],
    metrics: Iterable[str],
    *,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for group_a, group_b in comparisons:
        df_a = tables[group_a].sort_values(["repeat", "outer_fold"]).reset_index(drop=True)
        df_b = tables[group_b].sort_values(["repeat", "outer_fold"]).reset_index(drop=True)
        if not df_a[["repeat", "outer_fold"]].equals(df_b[["repeat", "outer_fold"]]):
            raise ValueError(f"Fold assignments do not align for {group_a} vs {group_b}.")
        for metric in metrics:
            values_a = df_a[metric].to_numpy(dtype=float)
            values_b = df_b[metric].to_numpy(dtype=float)
            differences = values_a - values_b
            ci_low, ci_high = _bootstrap_diff_ci(differences, n_boot=n_boot, seed=seed)
            stat, pvalue = _wilcoxon_pvalue(values_a, values_b)
            rows.append(
                {
                    "group_a": group_a,
                    "group_b": group_b,
                    "metric": metric,
                    "n_pairs": int(differences.size),
                    "mean_a": float(values_a.mean()),
                    "mean_b": float(values_b.mean()),
                    "mean_diff": float(differences.mean()),
                    "diff_ci95_low": ci_low,
                    "diff_ci95_high": ci_high,
                    "wilcoxon_stat": stat,
                    "p_value": pvalue,
                }
            )

    pairwise_df = pd.DataFrame(rows)
    adjusted_parts: list[pd.DataFrame] = []
    for metric, metric_df in pairwise_df.groupby("metric", sort=False):
        metric_df = metric_df.copy()
        metric_df["p_value_holm"] = _holm_adjust(metric_df["p_value"].tolist())
        adjusted_parts.append(metric_df)
    return pd.concat(adjusted_parts, ignore_index=True)


def build_paper_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    primary_metrics = ["auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc"]
    subset = summary_df[summary_df["metric"].isin(primary_metrics)].copy()
    subset["display"] = subset.apply(
        lambda row: f"{row['mean']:.4f} +/- {row['std']:.4f} [{row['ci95_low']:.4f}, {row['ci95_high']:.4f}]",
        axis=1,
    )
    paper = subset.pivot(index="group", columns="metric", values="display").reset_index()
    return paper[
        ["group", "auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc"]
    ].sort_values("group")


def main() -> None:
    args = parse_args()
    runs_root = Path(args.runs_root)
    output_dir = Path(args.output_dir)
    _ensure_dir(output_dir)

    tables = {group: _load_metrics_table(runs_root, group) for group in DEFAULT_GROUPS}
    summary_df = build_summary_table(
        tables,
        DEFAULT_SUMMARY_METRICS,
        n_boot=args.bootstrap_samples,
        seed=args.seed,
    )
    pairwise_df = build_pairwise_table(
        tables,
        DEFAULT_COMPARISONS,
        DEFAULT_COMPARISON_METRICS,
        n_boot=args.bootstrap_samples,
        seed=args.seed + 101,
    )
    paper_df = build_paper_table(summary_df)

    summary_df.to_csv(output_dir / "ablation_metric_summary_with_ci.csv", index=False, encoding="utf-8-sig")
    pairwise_df.to_csv(output_dir / "ablation_pairwise_significance.csv", index=False, encoding="utf-8-sig")
    paper_df.to_csv(output_dir / "ablation_paper_table.csv", index=False, encoding="utf-8-sig")

    payload = {
        "runs_root": str(runs_root),
        "groups": list(DEFAULT_GROUPS),
        "comparisons": [{"group_a": a, "group_b": b} for a, b in DEFAULT_COMPARISONS],
        "summary": summary_df.to_dict(orient="records"),
        "pairwise": pairwise_df.to_dict(orient="records"),
        "paper_table": paper_df.to_dict(orient="records"),
    }
    with (output_dir / "ablation_statistics.json").open("w", encoding="utf-8") as fp:
        json.dump(payload, fp, ensure_ascii=False, indent=2)

    print(json.dumps({"output_dir": str(output_dir), "summary_rows": len(summary_df), "pairwise_rows": len(pairwise_df)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
