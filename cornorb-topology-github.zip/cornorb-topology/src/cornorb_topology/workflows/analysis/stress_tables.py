from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl.styles import Font, PatternFill


HEADER_FILL = PatternFill(fill_type="solid", fgColor="D9EAF7")
HEADER_FONT = Font(bold=True, color="000000")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a full master workbook for strict-CV stress experiments.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument(
        "--strict-summary-dir",
        default="runs/extreme_stress_strict_cv_v1/summary_tables",
        help="Strict-CV stress summary directory.",
    )
    parser.add_argument(
        "--ablation-stats-dir",
        default="runs/ablation_suite_v1/statistics",
        help="Main ablation statistics directory.",
    )
    parser.add_argument(
        "--output-dir",
        default="runs/extreme_stress_strict_cv_v1/summary_tables",
        help="Output directory for the full master workbook.",
    )
    return parser.parse_args()


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _safe_read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing required CSV: {path}")
    return pd.read_csv(path)


def _safe_read_optional_csv(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    return pd.read_csv(path)


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _build_metadata_frame(
    *,
    manifest: dict[str, Any],
    clean_folds: pd.DataFrame,
    stress_folds: pd.DataFrame,
    all_folds: pd.DataFrame,
    all_conditions: pd.DataFrame,
    overview: pd.DataFrame,
) -> pd.DataFrame:
    rows = [
        {"item": "expected_tasks", "value": manifest.get("expected_tasks")},
        {"item": "completed_tasks", "value": manifest.get("completed_tasks")},
        {"item": "clean_reference_rows", "value": int(len(clean_folds))},
        {"item": "stress_task_rows", "value": int(len(stress_folds))},
        {"item": "master_all_fold_rows", "value": int(len(all_folds))},
        {"item": "all_condition_rows", "value": int(len(all_conditions))},
        {"item": "overview_rows", "value": int(len(overview))},
    ]
    return pd.DataFrame(rows)


def _style_workbook(workbook_path: Path) -> None:
    from openpyxl import load_workbook

    workbook = load_workbook(workbook_path)
    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions
        for cell in worksheet[1]:
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
        for column_cells in worksheet.columns:
            values = ["" if cell.value is None else str(cell.value) for cell in column_cells[:200]]
            width = max(len(value) for value in values) + 2 if values else 12
            width = min(max(width, 10), 40)
            worksheet.column_dimensions[column_cells[0].column_letter].width = width
    workbook.save(workbook_path)


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir).resolve()
    strict_summary_dir = (project_dir / args.strict_summary_dir).resolve()
    ablation_stats_dir = (project_dir / args.ablation_stats_dir).resolve()
    output_dir = (project_dir / args.output_dir).resolve()
    _ensure_dir(output_dir)

    clean_folds = _safe_read_csv(strict_summary_dir / "strict_cv_clean_reference_task_table.csv")
    clean_summary = _safe_read_csv(strict_summary_dir / "strict_cv_clean_reference_summary.csv")
    stress_folds = _safe_read_csv(strict_summary_dir / "strict_cv_stress_task_table.csv")
    stress_condition_summary = _safe_read_csv(strict_summary_dir / "strict_cv_stress_condition_summary.csv")
    overview = _safe_read_csv(strict_summary_dir / "strict_cv_stress_overview.csv")
    manifest = _load_json(strict_summary_dir / "summary_manifest.json")

    master_all_folds = pd.concat([clean_folds, stress_folds], ignore_index=True, sort=False)
    all_condition_summary = pd.concat([clean_summary, stress_condition_summary], ignore_index=True, sort=False)
    metadata = _build_metadata_frame(
        manifest=manifest,
        clean_folds=clean_folds,
        stress_folds=stress_folds,
        all_folds=master_all_folds,
        all_conditions=all_condition_summary,
        overview=overview,
    )

    ablation_paper = _safe_read_optional_csv(ablation_stats_dir / "ablation_paper_table.csv")
    ablation_ci = _safe_read_optional_csv(ablation_stats_dir / "ablation_metric_summary_with_ci.csv")
    ablation_significance = _safe_read_optional_csv(ablation_stats_dir / "ablation_pairwise_significance.csv")

    master_all_folds_path = output_dir / "strict_cv_master_all_folds.csv"
    all_condition_path = output_dir / "strict_cv_all_condition_summary.csv"
    workbook_path = output_dir / "strict_cv_total_big_table.xlsx"

    master_all_folds.to_csv(master_all_folds_path, index=False, encoding="utf-8-sig")
    all_condition_summary.to_csv(all_condition_path, index=False, encoding="utf-8-sig")

    sheets: dict[str, pd.DataFrame] = {
        "readme": metadata,
        "all_folds_master": master_all_folds,
        "clean_ref_folds": clean_folds,
        "clean_ref_summary": clean_summary,
        "stress_task_table": stress_folds,
        "all_condition_summary": all_condition_summary,
        "stress_overview": overview,
    }
    if ablation_paper is not None:
        sheets["ablation_paper"] = ablation_paper
    if ablation_ci is not None:
        sheets["ablation_ci"] = ablation_ci
    if ablation_significance is not None:
        sheets["ablation_significance"] = ablation_significance

    with pd.ExcelWriter(workbook_path) as writer:
        for sheet_name, frame in sheets.items():
            frame.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    _style_workbook(workbook_path)

    output_manifest = {
        "strict_summary_dir": str(strict_summary_dir),
        "output_dir": str(output_dir),
        "master_all_fold_rows": int(len(master_all_folds)),
        "all_condition_rows": int(len(all_condition_summary)),
        "files": {
            "strict_cv_master_all_folds": str(master_all_folds_path),
            "strict_cv_all_condition_summary": str(all_condition_path),
            "strict_cv_total_big_table": str(workbook_path),
        },
    }
    (output_dir / "strict_cv_total_big_table_manifest.json").write_text(
        json.dumps(output_manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(output_manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
