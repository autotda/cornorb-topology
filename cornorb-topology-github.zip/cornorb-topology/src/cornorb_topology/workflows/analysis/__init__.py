"""Metric summaries and paired statistical comparisons."""
