from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


FAMILY_ORDER = [
    "clean_reference",
    "train_stress",
    "image_input",
    "missing_view",
    "clinical_modality",
    "tda_feature",
    "combo_train",
    "combo_extreme",
]

MODEL_ORDER = [
    "clinical_only",
    "tda_only",
    "image_only",
    "image_clinical_tda",
]

PRIMARY_METRICS = [
    "loss",
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "precision",
    "recall",
    "specificity",
    "npv",
    "mcc",
    "brier_score",
    "ece_10",
    "recall_at_95_specificity",
]

RETENTION_METRICS = [
    "auroc_retention",
    "auprc_retention",
    "accuracy_retention",
    "balanced_accuracy_retention",
    "f1_retention",
    "mcc_retention",
    "recall_retention",
]

KEY_METRICS = ["auroc", "auprc", "accuracy", "balanced_accuracy", "f1", "mcc"]

STRESS_SOURCES = [
    ("train_stress", "train_stress_combined.csv"),
    ("image_input", "image_input_stress_combined.csv"),
    ("missing_view", "missing_view_stress_combined.csv"),
    ("clinical_modality", "clinical_modality_stress_combined.csv"),
    ("tda_feature", "tda_feature_stress_combined.csv"),
    ("combo_train", "combo_train_stress_combined.csv"),
    ("combo_extreme", "combo_extreme_combined.csv"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build master summary tables for Orbscan main and stress experiments.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--stress-root", default="runs/extreme_stress_v3", help="Stress experiment root.")
    parser.add_argument("--ablation-stats-dir", default="runs/ablation_suite_v1/statistics", help="Ablation statistics directory.")
    parser.add_argument("--output-dir", default="runs/extreme_stress_v3/summary_tables", help="Output directory.")
    return parser.parse_args()


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _safe_read_csv(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    return pd.read_csv(path)


def _ordered_sort(frame: pd.DataFrame) -> pd.DataFrame:
    working = frame.copy()
    if "family" in working.columns:
        working["family_order"] = working["family"].map({name: idx for idx, name in enumerate(FAMILY_ORDER)}).fillna(999)
    else:
        working["family_order"] = 999
    if "model_name" in working.columns:
        working["model_order"] = working["model_name"].map({name: idx for idx, name in enumerate(MODEL_ORDER)}).fillna(999)
    else:
        working["model_order"] = 999
    sort_columns = [column for column in ["family_order", "model_order", "condition_name"] if column in working.columns]
    working = working.sort_values(sort_columns, kind="stable").drop(columns=["family_order", "model_order"], errors="ignore")
    return working.reset_index(drop=True)


def _build_clean_reference(project_dir: Path, stress_root: Path) -> pd.DataFrame:
    manifest = _load_json(stress_root / "clean_models_manifest.json")
    rows: list[dict[str, Any]] = []
    for model_name, payload in manifest.items():
        history_path = project_dir / payload["history_path"]
        history = _load_json(history_path)
        row = {
            "family": "clean_reference",
            "model_name": model_name,
            "condition_name": "clean_reference",
            "source_file": str(history_path),
            "selection": json.dumps(payload.get("selection", {}), ensure_ascii=False, sort_keys=True),
        }
        row.update(history.get("best_metrics", {}))
        rows.append(row)
    return pd.DataFrame(rows)


def _load_stress_family(stress_root: Path, family: str, filename: str) -> pd.DataFrame | None:
    path = stress_root / filename
    frame = _safe_read_csv(path)
    if frame is None:
        return None
    if "name" in frame.columns:
        frame = frame.rename(columns={"name": "condition_name"})
    if "combo_name" in frame.columns:
        frame = frame.rename(columns={"combo_name": "condition_name"})
    frame.insert(0, "family", family)
    frame["source_file"] = str(path)
    return frame


def _coalesce_report_metric(frame: pd.DataFrame, metric: str) -> pd.Series:
    base = frame[metric] if metric in frame.columns else pd.Series(pd.NA, index=frame.index, dtype="object")
    eval_column = f"eval_{metric}"
    if eval_column in frame.columns:
        return frame[eval_column].combine_first(base)
    return base


def _add_report_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    working = frame.copy()
    for metric in PRIMARY_METRICS + RETENTION_METRICS:
        working[f"report_{metric}"] = _coalesce_report_metric(working, metric)
    return working


def _build_master_long(project_dir: Path, stress_root: Path) -> pd.DataFrame:
    frames = [_build_clean_reference(project_dir, stress_root)]
    for family, filename in STRESS_SOURCES:
        frame = _load_stress_family(stress_root, family, filename)
        if frame is not None and not frame.empty:
            frames.append(frame)
    master = pd.concat(frames, ignore_index=True, sort=False)
    master = _add_report_metrics(master)
    return _ordered_sort(master)


def _build_key_metric_pivot(master: pd.DataFrame) -> pd.DataFrame:
    pivot_source = master[["family", "condition_name", "model_name"] + [f"report_{metric}" for metric in KEY_METRICS]].copy()
    pivot = pivot_source.pivot_table(
        index=["family", "condition_name"],
        columns="model_name",
        values=[f"report_{metric}" for metric in KEY_METRICS],
        aggfunc="first",
    )
    pivot = pivot.sort_index(axis=1)
    pivot.columns = [f"{model_name}__{metric.replace('report_', '')}" for metric, model_name in pivot.columns]
    return pivot.reset_index()


def _pick_worst_row(frame: pd.DataFrame, metric: str) -> pd.Series:
    candidate = frame[frame["condition_name"] != "clean"].copy()
    candidate = candidate[candidate["condition_name"] != "clean_reference"].copy()
    if candidate.empty:
        candidate = frame.copy()
    candidate = candidate.sort_values([f"report_{metric}", "condition_name"], ascending=[True, True], kind="stable")
    return candidate.iloc[0]


def _build_family_overview(master: pd.DataFrame) -> pd.DataFrame:
    clean_reference = master[master["family"] == "clean_reference"].copy()
    clean_lookup = clean_reference.set_index("model_name")
    stress_only = master[master["family"] != "clean_reference"].copy()
    rows: list[dict[str, Any]] = []
    for (family, model_name), group in stress_only.groupby(["family", "model_name"], sort=False):
        group = group.reset_index(drop=True)
        clean_row = clean_lookup.loc[model_name] if model_name in clean_lookup.index else None
        worst_auroc = _pick_worst_row(group, "auroc")
        worst_bal_acc = _pick_worst_row(group, "balanced_accuracy")
        worst_f1 = _pick_worst_row(group, "f1")
        row = {
            "family": family,
            "model_name": model_name,
            "num_conditions": int(len(group)),
            "clean_auroc": None if clean_row is None else clean_row.get("report_auroc"),
            "clean_balanced_accuracy": None if clean_row is None else clean_row.get("report_balanced_accuracy"),
            "clean_f1": None if clean_row is None else clean_row.get("report_f1"),
            "clean_mcc": None if clean_row is None else clean_row.get("report_mcc"),
            "worst_auroc_condition": worst_auroc["condition_name"],
            "worst_auroc": worst_auroc["report_auroc"],
            "worst_balanced_accuracy_condition": worst_bal_acc["condition_name"],
            "worst_balanced_accuracy": worst_bal_acc["report_balanced_accuracy"],
            "worst_f1_condition": worst_f1["condition_name"],
            "worst_f1": worst_f1["report_f1"],
        }
        for metric in ["auroc_retention", "balanced_accuracy_retention", "f1_retention", "mcc_retention"]:
            report_metric = f"report_{metric}"
            numeric = pd.to_numeric(group[report_metric], errors="coerce")
            row[f"mean_{metric}"] = float(numeric.mean()) if numeric.notna().any() else None
            row[f"min_{metric}"] = float(numeric.min()) if numeric.notna().any() else None
        rows.append(row)
    overview = pd.DataFrame(rows)
    return _ordered_sort(overview)


def _load_optional_tables(ablation_stats_dir: Path) -> dict[str, pd.DataFrame]:
    optional_tables: dict[str, pd.DataFrame] = {}
    table_specs = {
        "ablation_paper_table": "ablation_paper_table.csv",
        "ablation_metric_summary_with_ci": "ablation_metric_summary_with_ci.csv",
        "ablation_pairwise_significance": "ablation_pairwise_significance.csv",
    }
    for key, filename in table_specs.items():
        frame = _safe_read_csv(ablation_stats_dir / filename)
        if frame is not None:
            optional_tables[key] = frame
    return optional_tables


def _write_excel(output_path: Path, sheets: dict[str, pd.DataFrame]) -> bool:
    try:
        with pd.ExcelWriter(output_path) as writer:
            for sheet_name, frame in sheets.items():
                frame.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        return True
    except Exception:
        return False


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir)
    stress_root = project_dir / args.stress_root
    ablation_stats_dir = project_dir / args.ablation_stats_dir
    output_dir = project_dir / args.output_dir
    _ensure_dir(output_dir)

    master = _build_master_long(project_dir, stress_root)
    pivot = _build_key_metric_pivot(master)
    overview = _build_family_overview(master)
    optional_tables = _load_optional_tables(ablation_stats_dir)

    master_path = output_dir / "stress_master_long_table.csv"
    pivot_path = output_dir / "stress_key_metric_pivot.csv"
    overview_path = output_dir / "stress_family_overview.csv"
    master.to_csv(master_path, index=False, encoding="utf-8-sig")
    pivot.to_csv(pivot_path, index=False, encoding="utf-8-sig")
    overview.to_csv(overview_path, index=False, encoding="utf-8-sig")

    excel_sheets = {
        "clean_reference": master[master["family"] == "clean_reference"].reset_index(drop=True),
        "stress_master_long": master,
        "stress_key_pivot": pivot,
        "stress_overview": overview,
    }
    excel_sheets.update(optional_tables)
    excel_path = output_dir / "total_summary_workbook.xlsx"
    excel_written = _write_excel(excel_path, excel_sheets)

    manifest = {
        "output_dir": str(output_dir),
        "master_rows": int(len(master)),
        "pivot_rows": int(len(pivot)),
        "overview_rows": int(len(overview)),
        "excel_written": excel_written,
        "files": {
            "stress_master_long_table": str(master_path),
            "stress_key_metric_pivot": str(pivot_path),
            "stress_family_overview": str(overview_path),
            "total_summary_workbook": str(excel_path) if excel_written else None,
        },
    }
    (output_dir / "summary_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
