"""Historical non-strict stress workflows; not the primary paper protocol."""
