from __future__ import annotations

import argparse
import json

from orbscan_experiment.runner import RunnerConfig
from orbscan_experiment.stress import (
    EvalStressSpec,
    TrainStressSpec,
    run_eval_stress,
    run_eval_stress_suite,
    run_train_stress,
    run_train_stress_suite,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Strict stress benchmark runner for Orbscan experiments.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Directory containing split CSVs.")
    parser.add_argument("--output-dir", default="runs/stress_benchmark_v1", help="Directory for stress results.")
    parser.add_argument("--model-name", choices=["deep_mv_fusion", "deep_mv_tda_fusion"], default="deep_mv_fusion")
    parser.add_argument("--tda-features-csv", default="runs/cubical_tda_v1/cubical_tda_features.csv", help="TDA feature CSV for fusion checkpoints and train-side stress.")
    parser.add_argument("--clean-history", default="", help="Optional clean locked-test history.json used for train-side retention metrics.")
    parser.add_argument(
        "--checkpoint",
        default="runs/deep_mv_fusion_full_outer_v1/locked_test/best_model.pt",
        help="Clean locked-test checkpoint used for eval-side stress.",
    )
    parser.add_argument(
        "--run-scope",
        choices=["eval-suite", "eval-single", "train-suite", "train-single"],
        default="eval-suite",
    )
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--token-dim", type=int, default=384)
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--num-layers", type=int, default=3)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--freeze-backbone-epochs", type=int, default=1)
    parser.add_argument("--no-clinical", action="store_true")
    parser.add_argument("--seed", type=int, default=20260321)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--max-train-batches", type=int, default=-1)
    parser.add_argument("--max-val-batches", type=int, default=-1)
    parser.add_argument("--max-conditions", type=int, default=-1)
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--no-amp", action="store_true")

    parser.add_argument("--name", default="custom", help="Custom stress condition name for single-run mode.")
    parser.add_argument(
        "--corruption",
        choices=["gaussian_noise", "gaussian_blur", "jpeg", "brightness", "contrast", "hue_shift", "cutout", "affine"],
        default=None,
    )
    parser.add_argument("--severity", type=int, default=1, choices=[1, 2, 3])
    parser.add_argument("--missing-views", default="", help="Comma-separated views to mask at eval time.")
    parser.add_argument("--keep-only-views", default="", help="Comma-separated views to keep at eval time.")
    parser.add_argument("--mask-clinical", action="store_true", help="Zero out the clinical token at eval time.")
    parser.add_argument("--clinical-noise-std", type=float, default=0.0, help="Add Gaussian noise to normalized clinical features.")
    parser.add_argument("--mask-tda", action="store_true", help="Zero out the TDA token at eval time.")
    parser.add_argument("--tda-noise-std", type=float, default=0.0, help="Add Gaussian noise to normalized TDA features.")
    parser.add_argument("--low-shot", type=float, default=1.0)
    parser.add_argument("--positive-patient-fraction", type=float, default=1.0)
    parser.add_argument("--label-noise", type=float, default=0.0)
    return parser.parse_args()


def _parse_views(raw: str) -> tuple[str, ...]:
    return tuple(part.strip().lower() for part in raw.split(",") if part.strip())


def main() -> None:
    args = parse_args()
    config = RunnerConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=args.output_dir,
        model_name=args.model_name,
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        num_workers=args.num_workers,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        token_dim=args.token_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        dropout=args.dropout,
        freeze_backbone_epochs=args.freeze_backbone_epochs,
        include_clinical=not args.no_clinical,
        include_tda=args.model_name == "deep_mv_tda_fusion",
        tda_features_csv=args.tda_features_csv,
        clean_reference_history=args.clean_history,
        pretrained_backbone=not args.no_pretrained,
        seed=args.seed,
        amp=not args.no_amp,
        device=args.device,
        max_train_batches=args.max_train_batches,
        max_val_batches=args.max_val_batches,
    )

    if args.run_scope == "eval-suite":
        result = run_eval_stress_suite(
            config=config,
            checkpoint_path=args.checkpoint,
            output_root=args.output_dir,
            max_conditions=args.max_conditions,
        )
    elif args.run_scope == "eval-single":
        spec = EvalStressSpec(
            name=args.name,
            corruption=args.corruption,
            severity=args.severity,
            missing_views=_parse_views(args.missing_views),
            keep_only_views=_parse_views(args.keep_only_views),
            mask_clinical=args.mask_clinical,
            clinical_noise_std=args.clinical_noise_std,
            mask_tda=args.mask_tda,
            tda_noise_std=args.tda_noise_std,
        )
        result = run_eval_stress(
            config=config,
            checkpoint_path=args.checkpoint,
            spec=spec,
            output_root=args.output_dir,
        )
    elif args.run_scope == "train-suite":
        result = run_train_stress_suite(
            config=config,
            output_root=args.output_dir,
            max_conditions=args.max_conditions,
        )
    else:
        spec = TrainStressSpec(
            name=args.name,
            low_shot_fraction=args.low_shot,
            positive_patient_fraction=args.positive_patient_fraction,
            label_noise_fraction=args.label_noise,
        )
        result = run_train_stress(
            config=config,
            spec=spec,
            output_root=args.output_dir,
        )

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
