from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from orbscan_experiment.clinical_baseline import (
    CLINICAL_FEATURE_COLUMNS,
    ClinicalBaselineConfig,
    run_fixed_split as run_clinical_fixed_split,
    run_locked_test as run_clinical_locked_test,
)
from orbscan_experiment.dataset import load_tda_feature_table
from orbscan_experiment.runner import RunnerConfig, run_locked_test as run_deep_locked_test
from orbscan_experiment.stress import (
    _augment_with_retention,
    _load_clean_reference_metrics,
    _prepare_train_stress_split,
    EvalStressSpec,
    TrainStressSpec,
    build_requested_clinical_modality_stress_suite,
    build_requested_combo_eval_suite,
    build_requested_combo_train_stress_suite,
    build_requested_image_input_stress_suite,
    build_requested_missing_view_stress_suite,
    build_requested_train_stress_suite,
    build_requested_tda_feature_stress_suite,
    run_eval_stress,
    run_eval_stress_suite,
    run_train_stress,
    run_train_stress_suite,
)
from orbscan_experiment.tda_baseline import (
    TDABaselineConfig,
    run_fixed_split as run_tda_fixed_split,
    run_locked_test as run_tda_locked_test,
)


PRIMARY_TRAIN_MODELS = ("clinical_only", "tda_only", "image_only", "image_clinical_tda")
PRIMARY_IMAGE_MODELS = ("image_only", "image_clinical_tda")
PRIMARY_CLINICAL_MODELS = ("clinical_only", "image_clinical_tda")
PRIMARY_TDA_MODELS = ("tda_only", "image_clinical_tda")
PRIMARY_COMBO_IMAGE_MODELS = ("image_only", "image_clinical_tda")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the requested extreme stress experiments for Orbscan models.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Directory containing split CSVs.")
    parser.add_argument("--ablation-root", default="runs/ablation_suite_v1", help="Root directory containing six-group ablation outputs.")
    parser.add_argument("--output-dir", default="runs/extreme_stress_v1", help="Directory for stress outputs.")
    parser.add_argument(
        "--run-scope",
        choices=["all", "prepare-clean", "train", "image-input", "missing-view", "clinical", "tda", "combo", "extra"],
        default="all",
    )
    parser.add_argument("--tda-features-csv", default="runs/cubical_tda_v1/cubical_tda_features.csv", help="TDA feature CSV.")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--token-dim", type=int, default=384)
    parser.add_argument("--num-heads", type=int, default=8)
    parser.add_argument("--num-layers", type=int, default=3)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--freeze-backbone-epochs", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260326)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--max-train-batches", type=int, default=-1)
    parser.add_argument("--max-val-batches", type=int, default=-1)
    parser.add_argument("--max-conditions", type=int, default=-1)
    parser.add_argument("--no-pretrained", action="store_true")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--resume-existing", action="store_true")
    parser.add_argument(
        "--artifact-mode",
        choices=["metrics-only", "full"],
        default="metrics-only",
        help="metrics-only keeps summary/history files but skips bulky per-condition artifacts.",
    )
    return parser.parse_args()


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    _ensure_dir(path.parent)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _pick_frequency_mode(rows: list[dict[str, Any]], key: str) -> Any:
    if not rows:
        raise ValueError(f"Cannot select mode for {key}: frequency rows are empty.")
    max_count = max(int(row["count"]) for row in rows)
    candidates = sorted(row[key] for row in rows if int(row["count"]) == max_count)
    return candidates[0]


def _load_reference_selection(project_dir: Path, ablation_root: Path) -> dict[str, dict[str, Any]]:
    clinical_summary = _load_json(project_dir / ablation_root / "clinical_only" / "outer_cv_summary.json")
    tda_summary = _load_json(project_dir / ablation_root / "tda_only" / "outer_cv_summary.json")
    image_summary = _load_json(project_dir / ablation_root / "image_only" / "outer_cv_summary.json")
    fusion_summary = _load_json(project_dir / ablation_root / "image_clinical_tda" / "outer_cv_summary.json")
    return {
        "clinical_only": {
            "C": float(_pick_frequency_mode(clinical_summary["selected_params_frequency"], "C")),
            "l1_ratio": float(_pick_frequency_mode(clinical_summary["selected_params_frequency"], "l1_ratio")),
        },
        "tda_only": {
            "C": float(_pick_frequency_mode(tda_summary["selected_params_frequency"], "C")),
            "l1_ratio": float(_pick_frequency_mode(tda_summary["selected_params_frequency"], "l1_ratio")),
        },
        "image_only": {
            "locked_selected_epoch": int(_pick_frequency_mode(image_summary["selected_epoch_frequency"], "selected_epoch")),
        },
        "image_clinical_tda": {
            "locked_selected_epoch": int(_pick_frequency_mode(fusion_summary["selected_epoch_frequency"], "selected_epoch")),
        },
    }


def _build_runner_config(args: argparse.Namespace, *, output_dir: Path, model_name: str) -> RunnerConfig:
    include_clinical = model_name != "image_only"
    include_tda = model_name == "image_clinical_tda"
    deep_model_name = "deep_mv_tda_fusion" if include_tda else "deep_mv_fusion"
    return RunnerConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=str(output_dir),
        model_name=deep_model_name,
        image_size=args.image_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        num_workers=args.num_workers,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        token_dim=args.token_dim,
        num_heads=args.num_heads,
        num_layers=args.num_layers,
        dropout=args.dropout,
        freeze_backbone_epochs=args.freeze_backbone_epochs,
        include_clinical=include_clinical,
        include_tda=include_tda,
        tda_features_csv=args.tda_features_csv,
        selection_policy="nested_inner_cv",
        pretrained_backbone=not args.no_pretrained,
        seed=args.seed,
        amp=not args.no_amp,
        device=args.device,
        max_train_batches=args.max_train_batches,
        max_val_batches=args.max_val_batches,
        resume_existing=args.resume_existing,
    )


def _build_clinical_config(args: argparse.Namespace, *, output_dir: Path) -> ClinicalBaselineConfig:
    return ClinicalBaselineConfig(
        project_dir=args.project_dir,
        splits_dir=args.splits_dir,
        output_dir=str(output_dir),
        seed=args.seed,
        c_grid=(1.0,),
        l1_ratio_grid=(0.0,),
        max_iter=4000,
        use_class_weight=True,
        resume_existing=args.resume_existing,
    )


def _build_tda_config(args: argparse.Namespace, *, output_dir: Path) -> TDABaselineConfig:
    return TDABaselineConfig(
        project_dir=args.project_dir,
        features_csv=args.tda_features_csv,
        splits_dir=args.splits_dir,
        output_dir=str(output_dir),
        seed=args.seed,
        c_grid=(0.01,),
        l1_ratio_grid=(0.0,),
        max_iter=4000,
        use_class_weight=True,
        resume_existing=args.resume_existing,
    )


def _build_clinical_valid_postprocess(spec: EvalStressSpec, *, seed: int):
    numeric_columns = list(CLINICAL_FEATURE_COLUMNS[:-1])
    group_map = {
        "astigmatism": ["astig_value_D", "astig_axis_deg"],
        "kmax": ["kmax_value_D", "kmax_axis_deg"],
        "pachy": ["pachy_central_um", "pachy_thinnest_um", "pachy_thinnest_x", "pachy_thinnest_y"],
    }

    def _postprocess(frame: pd.DataFrame) -> pd.DataFrame:
        updated = frame.copy()
        rng = np.random.default_rng(seed)
        if spec.mask_clinical:
            updated.loc[:, CLINICAL_FEATURE_COLUMNS] = 0.0
            return updated
        for group_name in spec.clinical_drop_groups:
            for column in group_map.get(group_name.lower(), []):
                if column in updated.columns:
                    updated.loc[:, column] = 0.0
        if spec.clinical_missing_fraction > 0.0 and numeric_columns:
            mask = rng.random((len(updated), len(numeric_columns))) >= spec.clinical_missing_fraction
            updated.loc[:, numeric_columns] = updated.loc[:, numeric_columns].to_numpy(dtype=float) * mask
        if spec.clinical_noise_std > 0.0 and numeric_columns:
            noise = rng.normal(loc=0.0, scale=spec.clinical_noise_std, size=(len(updated), len(numeric_columns)))
            updated.loc[:, numeric_columns] = updated.loc[:, numeric_columns].to_numpy(dtype=float) + noise
        return updated

    return _postprocess


def _build_tda_valid_postprocess(spec: EvalStressSpec, *, feature_columns: list[str], seed: int):
    view_prefixes = tuple(f"{view.lower()}_" for view in spec.tda_drop_views)
    keep_homology = spec.tda_keep_homology.lower().strip()

    def _postprocess(frame: pd.DataFrame) -> pd.DataFrame:
        updated = frame.copy()
        rng = np.random.default_rng(seed)
        if spec.mask_tda:
            updated.loc[:, feature_columns] = 0.0
            return updated
        if view_prefixes:
            for column in feature_columns:
                if any(column.startswith(prefix) for prefix in view_prefixes):
                    updated.loc[:, column] = 0.0
        if keep_homology in {"h0", "h1"}:
            token = f"_{keep_homology}"
            drop_columns = [column for column in feature_columns if token not in column]
            if drop_columns:
                updated.loc[:, drop_columns] = 0.0
        if spec.tda_dropout_fraction > 0.0:
            mask = rng.random((len(updated), len(feature_columns))) >= spec.tda_dropout_fraction
            updated.loc[:, feature_columns] = updated.loc[:, feature_columns].to_numpy(dtype=float) * mask
        if spec.tda_noise_std > 0.0:
            noise = rng.normal(loc=0.0, scale=spec.tda_noise_std, size=(len(updated), len(feature_columns)))
            updated.loc[:, feature_columns] = updated.loc[:, feature_columns].to_numpy(dtype=float) + noise
        return updated

    return _postprocess


def _prepare_clean_models(
    args: argparse.Namespace,
    *,
    selections: dict[str, dict[str, Any]],
    project_dir: Path,
    output_root: Path,
) -> dict[str, dict[str, Any]]:
    clean_root = output_root / "clean_models"
    manifest: dict[str, dict[str, Any]] = {}
    metrics_only = args.artifact_mode == "metrics-only"

    clinical_output = clean_root / "clinical_only"
    clinical_history = clinical_output / "locked_test" / "history.json"
    if not (args.resume_existing and clinical_history.exists()):
        clinical_config = _build_clinical_config(args, output_dir=clinical_output)
        run_clinical_locked_test(
            clinical_config,
            C=float(selections["clinical_only"]["C"]),
            l1_ratio=float(selections["clinical_only"]["l1_ratio"]),
            save_predictions=not metrics_only,
        )
    manifest["clinical_only"] = {
        "history_path": str(clinical_history),
        "selection": selections["clinical_only"],
    }

    tda_output = clean_root / "tda_only"
    tda_history = tda_output / "locked_test" / "history.json"
    if not (args.resume_existing and tda_history.exists()):
        tda_config = _build_tda_config(args, output_dir=tda_output)
        run_tda_locked_test(
            tda_config,
            C=float(selections["tda_only"]["C"]),
            l1_ratio=float(selections["tda_only"]["l1_ratio"]),
            save_predictions=not metrics_only,
        )
    manifest["tda_only"] = {
        "history_path": str(tda_history),
        "selection": selections["tda_only"],
    }

    for model_name in PRIMARY_IMAGE_MODELS:
        model_output = clean_root / model_name
        checkpoint_path = model_output / "locked_test" / "best_model.pt"
        history_path = model_output / "locked_test" / "history.json"
        if not (args.resume_existing and checkpoint_path.exists() and history_path.exists()):
            config = _build_runner_config(args, output_dir=model_output, model_name=model_name)
            config.locked_selected_epoch = int(selections[model_name]["locked_selected_epoch"])
            run_deep_locked_test(
                config,
                save_checkpoint=True,
                save_predictions=not metrics_only,
            )
        manifest[model_name] = {
            "history_path": str(history_path),
            "checkpoint_path": str(checkpoint_path),
            "selection": selections[model_name],
        }

    _write_json(output_root / "clean_models_manifest.json", manifest)
    return manifest


def _run_baseline_train_stress_suite(
    *,
    args: argparse.Namespace,
    model_name: str,
    output_root: Path,
    selections: dict[str, Any],
    clean_history_path: Path,
    specs: list[TrainStressSpec] | None = None,
    suite_name: str = "requested_train_stress",
    output_subdir: str = "train_stress",
) -> dict[str, Any]:
    specs = list(specs or build_requested_train_stress_suite())
    if args.max_conditions > 0:
        specs = specs[: args.max_conditions]

    project_dir = Path(args.project_dir)
    splits_dir = project_dir / args.splits_dir
    base_train_csv = splits_dir / "development_eyes.csv"
    valid_csv = splits_dir / "locked_test_eyes.csv"
    model_root = output_root / model_name
    clean_metrics = _load_clean_reference_metrics(clean_history_path)
    metrics_only = args.artifact_mode == "metrics-only"

    if model_name == "clinical_only":
        config = _build_clinical_config(args, output_dir=model_root)
    else:
        config = _build_tda_config(args, output_dir=model_root)

    results: list[dict[str, Any]] = []
    for spec in specs:
        condition_dir = model_root / output_subdir / spec.name
        history_path = condition_dir / "history.json"
        if args.resume_existing and history_path.exists():
            result = _load_json(history_path)
        else:
            _ensure_dir(condition_dir)
            stressed_train_df = _prepare_train_stress_split(base_train_csv, spec=spec, seed=args.seed)
            stressed_train_csv = condition_dir / "stressed_train_split.csv"
            stressed_train_df.to_csv(stressed_train_csv, index=False, encoding="utf-8-sig")
            if model_name == "clinical_only":
                result = run_clinical_fixed_split(
                    config,
                    train_csv=stressed_train_csv,
                    valid_csv=valid_csv,
                    C=float(selections["C"]),
                    l1_ratio=float(selections["l1_ratio"]),
                    output_dir=condition_dir,
                    split_name="train_stress",
                    meta={"stress_type": "train_stress", "spec": spec.__dict__, "base_train_csv": str(base_train_csv)},
                    save_predictions=not metrics_only,
                )
            else:
                result = run_tda_fixed_split(
                    config,
                    train_csv=stressed_train_csv,
                    valid_csv=valid_csv,
                    C=float(selections["C"]),
                    l1_ratio=float(selections["l1_ratio"]),
                    output_dir=condition_dir,
                    split_name="train_stress",
                    meta={"stress_type": "train_stress", "spec": spec.__dict__, "base_train_csv": str(base_train_csv)},
                    save_predictions=not metrics_only,
                )
            result["best_metrics"] = _augment_with_retention(result.get("best_metrics", {}), clean_metrics)
            _write_json(history_path, result)
            if metrics_only and stressed_train_csv.exists():
                stressed_train_csv.unlink()
        results.append(result)

    summary = {
        "suite_name": suite_name,
        "model_name": model_name,
        "num_conditions": len(results),
        "results": results,
    }
    rows = [{"name": item["spec"]["name"], **item["best_metrics"]} for item in results]
    summary_csv_path = model_root / "train_stress_summary.csv" if output_subdir == "train_stress" else model_root / output_subdir / "train_stress_summary.csv"
    summary_json_path = model_root / "train_stress_summary.json" if output_subdir == "train_stress" else model_root / output_subdir / "train_stress_summary.json"
    pd.DataFrame(rows).to_csv(summary_csv_path, index=False, encoding="utf-8-sig")
    _write_json(summary_json_path, summary)
    return summary


def _combine_summaries(model_roots: dict[str, Path], *, relative_summary_path: str, output_path: Path) -> None:
    frames: list[pd.DataFrame] = []
    for model_name, model_root in model_roots.items():
        summary_path = model_root / relative_summary_path
        if not summary_path.exists():
            continue
        df = pd.read_csv(summary_path)
        df.insert(0, "model_name", model_name)
        frames.append(df)
    if not frames:
        return
    combined = pd.concat(frames, ignore_index=True)
    combined.to_csv(output_path, index=False, encoding="utf-8-sig")


def _write_weakest_single_view_summary(model_root: Path) -> None:
    summary_path = model_root / "missing_view" / "eval_stress_summary.csv"
    if not summary_path.exists():
        return
    df = pd.read_csv(summary_path)
    only_view_df = df[df["name"].astype(str).str.startswith("only_")].copy()
    if only_view_df.empty:
        return
    weakest = only_view_df.sort_values(
        ["auroc", "balanced_accuracy", "f1", "mcc", "name"],
        ascending=[True, True, True, True, True],
    ).iloc[0]
    payload = {
        "weakest_view": str(weakest["name"]).replace("only_", ""),
        "condition_name": str(weakest["name"]),
        "metrics": weakest.to_dict(),
    }
    _write_json(model_root / "missing_view" / "weakest_single_view.json", payload)


def _run_deep_combo_train_eval(
    *,
    args: argparse.Namespace,
    model_name: str,
    model_root: Path,
    clean_history_path: Path,
    checkpoint_path: Path,
    train_spec: TrainStressSpec,
    eval_spec: EvalStressSpec,
    selections: dict[str, Any],
) -> dict[str, Any]:
    combo_name = f"{train_spec.name}__{eval_spec.name}"
    combo_root = model_root / "combo_extreme" / combo_name
    train_root = combo_root / "train_component"
    eval_root = combo_root / "eval_component"
    summary_path = combo_root / "combo_summary.json"
    train_history_path = train_root / "train_stress" / train_spec.name / "history.json"
    eval_result_path = eval_root / "eval_stress" / eval_spec.name / "result.json"
    if args.resume_existing:
        if summary_path.exists():
            return _load_json(summary_path)
        if train_history_path.exists() and eval_result_path.exists():
            train_payload = _load_json(train_history_path)
            eval_payload = _load_json(eval_result_path)
            summary_payload = {
                "model_name": model_name,
                "combo_name": combo_name,
                "train_spec": train_spec.__dict__,
                "eval_spec": eval_spec.__dict__,
                "train_metrics": train_payload.get("best_metrics", {}),
                "eval_metrics": eval_payload.get("metrics", {}),
            }
            _write_json(summary_path, summary_payload)
            return summary_payload

    config = _build_runner_config(args, output_dir=model_root, model_name=model_name)
    config.locked_selected_epoch = int(selections["locked_selected_epoch"])
    config.clean_reference_history = str(clean_history_path)
    metrics_only = args.artifact_mode == "metrics-only"

    train_result = run_train_stress(
        config=config,
        spec=train_spec,
        output_root=train_root,
        resume_existing=args.resume_existing,
        persist_stressed_split=not metrics_only,
        save_checkpoint=True,
        save_predictions=not metrics_only,
    )
    train_checkpoint = train_root / "train_stress" / train_spec.name / "best_model.pt"
    if not train_checkpoint.exists():
        raise FileNotFoundError(f"Expected combo checkpoint not found: {train_checkpoint}")
    eval_result = run_eval_stress(
        config=config,
        checkpoint_path=train_checkpoint,
        spec=eval_spec,
        output_root=eval_root,
        resume_existing=args.resume_existing,
        save_predictions=not metrics_only,
    )
    summary_payload = {
        "model_name": model_name,
        "combo_name": combo_name,
        "train_spec": train_spec.__dict__,
        "eval_spec": eval_spec.__dict__,
        "train_metrics": train_result.get("best_metrics", {}),
        "eval_metrics": eval_result.get("metrics", {}),
    }
    _write_json(summary_path, summary_payload)
    if metrics_only and train_checkpoint.exists():
        train_checkpoint.unlink()
    return summary_payload


def _collect_combo_rows(model_root: Path) -> list[dict[str, Any]]:
    combo_dir = model_root / "combo_extreme"
    rows: list[dict[str, Any]] = []
    if not combo_dir.exists():
        return rows
    for summary_path in combo_dir.rglob("combo_summary.json"):
        payload = _load_json(summary_path)
        row = {
            "model_name": payload["model_name"],
            "combo_name": payload["combo_name"],
            **{f"train_{key}": value for key, value in payload.get("train_metrics", {}).items()},
            **{f"eval_{key}": value for key, value in payload.get("eval_metrics", {}).items()},
        }
        rows.append(row)
    return rows


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir)
    ablation_root = Path(args.ablation_root)
    output_root = project_dir / args.output_dir
    _ensure_dir(output_root)

    selections = _load_reference_selection(project_dir, ablation_root)
    clean_manifest = _prepare_clean_models(
        args,
        selections=selections,
        project_dir=project_dir,
        output_root=output_root,
    )

    model_roots = {model_name: output_root / model_name for model_name in PRIMARY_TRAIN_MODELS}
    metrics_only = args.artifact_mode == "metrics-only"

    if args.run_scope in {"all", "train"}:
        for model_name in PRIMARY_TRAIN_MODELS:
            if model_name == "image_only":
                config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
                config.locked_selected_epoch = int(selections[model_name]["locked_selected_epoch"])
                config.clean_reference_history = clean_manifest[model_name]["history_path"]
                run_train_stress_suite(
                    config=config,
                    output_root=model_roots[model_name],
                    specs=build_requested_train_stress_suite(),
                    max_conditions=args.max_conditions,
                    resume_existing=args.resume_existing,
                    persist_stressed_split=not metrics_only,
                    save_checkpoint=not metrics_only,
                    save_predictions=not metrics_only,
                )
            elif model_name == "image_clinical_tda":
                config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
                config.locked_selected_epoch = int(selections[model_name]["locked_selected_epoch"])
                config.clean_reference_history = clean_manifest[model_name]["history_path"]
                run_train_stress_suite(
                    config=config,
                    output_root=model_roots[model_name],
                    specs=build_requested_train_stress_suite(),
                    max_conditions=args.max_conditions,
                    resume_existing=args.resume_existing,
                    persist_stressed_split=not metrics_only,
                    save_checkpoint=not metrics_only,
                    save_predictions=not metrics_only,
                )
            else:
                _run_baseline_train_stress_suite(
                    args=args,
                    model_name=model_name,
                    output_root=output_root,
                    selections=selections[model_name],
                    clean_history_path=Path(clean_manifest[model_name]["history_path"]),
                )
        _combine_summaries(
            model_roots,
            relative_summary_path="train_stress_summary.csv",
            output_path=output_root / "train_stress_combined.csv",
        )

    if args.run_scope in {"all", "image-input"}:
        specs = build_requested_image_input_stress_suite()
        if args.max_conditions > 0:
            specs = specs[: args.max_conditions]
        for model_name in PRIMARY_IMAGE_MODELS:
            config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
            run_eval_stress_suite(
                config=config,
                checkpoint_path=clean_manifest[model_name]["checkpoint_path"],
                output_root=model_roots[model_name] / "image_input",
                specs=specs,
                max_conditions=args.max_conditions,
                resume_existing=args.resume_existing,
                save_predictions=not metrics_only,
            )
        _combine_summaries(
            {model_name: model_roots[model_name] / "image_input" for model_name in PRIMARY_IMAGE_MODELS},
            relative_summary_path="eval_stress_summary.csv",
            output_path=output_root / "image_input_stress_combined.csv",
        )

    if args.run_scope in {"all", "missing-view"}:
        specs = build_requested_missing_view_stress_suite()
        if args.max_conditions > 0:
            specs = specs[: args.max_conditions]
        for model_name in PRIMARY_IMAGE_MODELS:
            config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
            run_eval_stress_suite(
                config=config,
                checkpoint_path=clean_manifest[model_name]["checkpoint_path"],
                output_root=model_roots[model_name] / "missing_view",
                specs=specs,
                max_conditions=args.max_conditions,
                resume_existing=args.resume_existing,
                save_predictions=not metrics_only,
            )
            _write_weakest_single_view_summary(model_roots[model_name])
        _combine_summaries(
            {model_name: model_roots[model_name] / "missing_view" for model_name in PRIMARY_IMAGE_MODELS},
            relative_summary_path="eval_stress_summary.csv",
            output_path=output_root / "missing_view_stress_combined.csv",
        )

    if args.run_scope in {"all", "clinical", "extra"}:
        clinical_specs = build_requested_clinical_modality_stress_suite()
        if args.max_conditions > 0:
            clinical_specs = clinical_specs[: args.max_conditions]
        for model_name in PRIMARY_CLINICAL_MODELS:
            if model_name == "clinical_only":
                # clinical_only has no checkpoint-based eval path; reuse fixed split evaluation through the clean baseline
                config_clinical = _build_clinical_config(args, output_dir=model_roots[model_name])
                rows: list[dict[str, Any]] = []
                for spec in clinical_specs:
                    condition_dir = model_roots[model_name] / "clinical_modality" / "eval_stress" / spec.name
                    result_path = condition_dir / "result.json"
                    if args.resume_existing and result_path.exists():
                        result = _load_json(result_path)
                    else:
                        train_csv = Path(args.project_dir) / args.splits_dir / "development_eyes.csv"
                        valid_csv = Path(args.project_dir) / args.splits_dir / "locked_test_eyes.csv"
                        result = run_clinical_fixed_split(
                            config_clinical,
                            train_csv=train_csv,
                            valid_csv=valid_csv,
                            C=float(selections["clinical_only"]["C"]),
                            l1_ratio=float(selections["clinical_only"]["l1_ratio"]),
                            output_dir=condition_dir,
                            split_name="eval_stress",
                            meta={"stress_type": "clinical_modality_eval", "spec": spec.__dict__},
                            save_predictions=not metrics_only,
                            valid_frame_postprocess=_build_clinical_valid_postprocess(spec, seed=args.seed + 900),
                        )
                        result["best_metrics"] = _augment_with_retention(
                            result.get("best_metrics", {}),
                            _load_clean_reference_metrics(Path(clean_manifest["clinical_only"]["history_path"])),
                        )
                        _write_json(result_path, {"metrics": result["best_metrics"], "spec": spec.__dict__, "stress_type": "clinical_modality_eval"})
                    rows.append({"name": spec.name, **_load_json(result_path)["metrics"]})
                pd.DataFrame(rows).to_csv(model_roots[model_name] / "clinical_modality" / "eval_stress_summary.csv", index=False, encoding="utf-8-sig")
                _write_json(model_roots[model_name] / "clinical_modality" / "eval_stress_summary.json", {"suite_name": "clinical_modality", "results": rows})
            else:
                config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
                run_eval_stress_suite(
                    config=config,
                    checkpoint_path=clean_manifest[model_name]["checkpoint_path"],
                    output_root=model_roots[model_name] / "clinical_modality",
                    specs=clinical_specs,
                    max_conditions=args.max_conditions,
                    resume_existing=args.resume_existing,
                    save_predictions=not metrics_only,
                )
        _combine_summaries(
            {model_name: model_roots[model_name] / "clinical_modality" for model_name in PRIMARY_CLINICAL_MODELS},
            relative_summary_path="eval_stress_summary.csv",
            output_path=output_root / "clinical_modality_stress_combined.csv",
        )

    if args.run_scope in {"all", "tda", "extra"}:
        tda_specs = build_requested_tda_feature_stress_suite()
        if args.max_conditions > 0:
            tda_specs = tda_specs[: args.max_conditions]
        for model_name in PRIMARY_TDA_MODELS:
            if model_name == "image_clinical_tda":
                config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
                run_eval_stress_suite(
                    config=config,
                    checkpoint_path=clean_manifest[model_name]["checkpoint_path"],
                    output_root=model_roots[model_name] / "tda_feature",
                    specs=tda_specs,
                    max_conditions=args.max_conditions,
                    resume_existing=args.resume_existing,
                    save_predictions=not metrics_only,
                )
            else:
                config_tda = _build_tda_config(args, output_dir=model_roots[model_name])
                rows: list[dict[str, Any]] = []
                train_csv = Path(args.project_dir) / args.splits_dir / "development_eyes.csv"
                valid_csv = Path(args.project_dir) / args.splits_dir / "locked_test_eyes.csv"
                _, tda_feature_columns = load_tda_feature_table(Path(args.project_dir) / args.tda_features_csv)
                for spec in tda_specs:
                    condition_dir = model_roots[model_name] / "tda_feature" / "eval_stress" / spec.name
                    result_path = condition_dir / "result.json"
                    if args.resume_existing and result_path.exists():
                        result_payload = _load_json(result_path)
                    else:
                        result = run_tda_fixed_split(
                            config_tda,
                            train_csv=train_csv,
                            valid_csv=valid_csv,
                            C=float(selections["tda_only"]["C"]),
                            l1_ratio=float(selections["tda_only"]["l1_ratio"]),
                            output_dir=condition_dir,
                            split_name="eval_stress",
                            meta={"stress_type": "tda_feature_eval", "spec": spec.__dict__},
                            save_predictions=not metrics_only,
                            valid_frame_postprocess=_build_tda_valid_postprocess(
                                spec,
                                feature_columns=tda_feature_columns,
                                seed=args.seed + 950,
                            ),
                        )
                        result_payload = {
                            "metrics": _augment_with_retention(
                                result["best_metrics"],
                                _load_clean_reference_metrics(Path(clean_manifest["tda_only"]["history_path"])),
                            ),
                            "spec": spec.__dict__,
                            "stress_type": "tda_feature_eval",
                        }
                        _write_json(result_path, result_payload)
                    rows.append({"name": spec.name, **result_payload["metrics"]})
                pd.DataFrame(rows).to_csv(model_roots[model_name] / "tda_feature" / "eval_stress_summary.csv", index=False, encoding="utf-8-sig")
                _write_json(model_roots[model_name] / "tda_feature" / "eval_stress_summary.json", {"suite_name": "tda_feature", "results": rows})
        _combine_summaries(
            {model_name: model_roots[model_name] / "tda_feature" for model_name in PRIMARY_TDA_MODELS},
            relative_summary_path="eval_stress_summary.csv",
            output_path=output_root / "tda_feature_stress_combined.csv",
        )

    if args.run_scope in {"all", "combo", "extra"}:
        combo_train_specs = build_requested_combo_train_stress_suite()
        combo_eval_specs = build_requested_combo_eval_suite()
        if args.max_conditions > 0:
            combo_train_specs = combo_train_specs[: args.max_conditions]
            combo_eval_specs = combo_eval_specs[: args.max_conditions]
        for model_name in PRIMARY_TRAIN_MODELS:
            if model_name in {"clinical_only", "tda_only"}:
                _run_baseline_train_stress_suite(
                    args=args,
                    model_name=model_name,
                    output_root=output_root,
                    selections=selections[model_name],
                    clean_history_path=Path(clean_manifest[model_name]["history_path"]),
                    specs=combo_train_specs,
                    suite_name="combo_train_stress",
                    output_subdir="combo_train",
                )
            else:
                config = _build_runner_config(args, output_dir=model_roots[model_name], model_name=model_name)
                config.locked_selected_epoch = int(selections[model_name]["locked_selected_epoch"])
                config.clean_reference_history = clean_manifest[model_name]["history_path"]
                run_train_stress_suite(
                    config=config,
                    output_root=model_roots[model_name] / "combo_train",
                    specs=combo_train_specs,
                    max_conditions=args.max_conditions,
                    resume_existing=args.resume_existing,
                    persist_stressed_split=not metrics_only,
                    save_checkpoint=not metrics_only,
                    save_predictions=not metrics_only,
                )
        combo_rows: list[dict[str, Any]] = []
        _combine_summaries(
            {model_name: model_roots[model_name] / "combo_train" for model_name in PRIMARY_TRAIN_MODELS},
            relative_summary_path="train_stress_summary.csv",
            output_path=output_root / "combo_train_stress_combined.csv",
        )
        for model_name in PRIMARY_COMBO_IMAGE_MODELS:
            model_root = model_roots[model_name]
            for eval_spec in combo_eval_specs:
                if eval_spec.name == "combo_clinical_missing40_tda_dropout30" and model_name != "image_clinical_tda":
                    continue
                config = _build_runner_config(args, output_dir=model_root, model_name=model_name)
                result = run_eval_stress(
                    config=config,
                    checkpoint_path=clean_manifest[model_name]["checkpoint_path"],
                    spec=eval_spec,
                    output_root=model_root / "combo_eval",
                    resume_existing=args.resume_existing,
                    save_predictions=not metrics_only,
                )
                combo_rows.append({"model_name": model_name, "combo_name": eval_spec.name, **result["metrics"]})
            train_eval_summary = _run_deep_combo_train_eval(
                args=args,
                model_name=model_name,
                model_root=model_root,
                clean_history_path=Path(clean_manifest[model_name]["history_path"]),
                checkpoint_path=Path(clean_manifest[model_name]["checkpoint_path"]),
                train_spec=TrainStressSpec(name="combo_positive_retention_10", positive_patient_fraction=0.10),
                eval_spec=EvalStressSpec(name="combo_blur2_res96", corruption="gaussian_blur", severity=2, downsample_size=96),
                selections=selections[model_name],
            )
            combo_rows.append(
                {
                    "model_name": model_name,
                    "combo_name": train_eval_summary["combo_name"],
                    **{f"train_{k}": v for k, v in train_eval_summary["train_metrics"].items()},
                    **{f"eval_{k}": v for k, v in train_eval_summary["eval_metrics"].items()},
                }
            )
        if combo_rows:
            pd.DataFrame(combo_rows).to_csv(output_root / "combo_extreme_combined.csv", index=False, encoding="utf-8-sig")

    payload = {
        "output_root": str(output_root),
        "run_scope": args.run_scope,
        "artifact_mode": args.artifact_mode,
        "clean_models_manifest": str(output_root / "clean_models_manifest.json"),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
