from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import torch

from orbscan_experiment.clinical_baseline import (
    CLINICAL_FEATURE_COLUMNS,
    ClinicalBaselineConfig,
    run_fixed_split as run_clinical_fixed_split,
)
from orbscan_experiment.dataset import load_tda_feature_table
from orbscan_experiment.runner import RunnerConfig
from orbscan_experiment.stress import (
    EvalStressSpec,
    TrainStressSpec,
    _augment_with_retention,
    _prepare_train_stress_split,
    build_requested_clinical_modality_stress_suite,
    build_requested_combo_eval_suite,
    build_requested_combo_train_stress_suite,
    build_requested_image_input_stress_suite,
    build_requested_missing_view_stress_suite,
    build_requested_tda_feature_stress_suite,
    build_requested_train_stress_suite,
    run_eval_stress,
    run_train_stress,
)
from orbscan_experiment.tda_baseline import TDABaselineConfig, run_fixed_split as run_tda_fixed_split


DEFAULT_MODELS = ("clinical_only", "tda_only", "image_only", "image_clinical_tda")
SUPPORTED_MODELS = ("clinical_only", "tda_only", "image_only", "image_clinical", "image_tda", "image_clinical_tda")
PRIMARY_TRAIN_MODELS = ("clinical_only", "tda_only", "image_only", "image_clinical", "image_tda", "image_clinical_tda")
PRIMARY_IMAGE_MODELS = ("image_only", "image_clinical", "image_tda", "image_clinical_tda")
PRIMARY_CLINICAL_MODELS = ("clinical_only", "image_clinical", "image_clinical_tda")
PRIMARY_TDA_MODELS = ("tda_only", "image_tda", "image_clinical_tda")
PRIMARY_COMBO_IMAGE_MODELS = ("image_only", "image_clinical", "image_tda", "image_clinical_tda")
RUNNER_FIELD_NAMES = {field.name for field in fields(RunnerConfig)}
CLINICAL_CONFIG_FIELD_NAMES = {field.name for field in fields(ClinicalBaselineConfig)}
TDA_CONFIG_FIELD_NAMES = {field.name for field in fields(TDABaselineConfig)}
METRIC_COLUMNS = (
    "loss",
    "auroc",
    "auprc",
    "accuracy",
    "balanced_accuracy",
    "f1",
    "precision",
    "recall",
    "specificity",
    "npv",
    "mcc",
    "brier_score",
    "ece_10",
    "recall_at_95_specificity",
    "auroc_retention",
    "auprc_retention",
    "accuracy_retention",
    "balanced_accuracy_retention",
    "f1_retention",
    "mcc_retention",
    "recall_retention",
)


@dataclass(frozen=True)
class StressTask:
    family: str
    model_name: str
    repeat: int
    outer_fold: int
    condition_name: str
    handler: str
    payload: dict[str, Any]


class ProgressTracker:
    def __init__(self, *, total: int, completed: int, progress_path: Path) -> None:
        self.total = total
        self.completed = completed
        self.progress_path = progress_path
        self.started_at = time.perf_counter()
        self.run_processed = 0
        self.run_completed = 0
        self._write(status="initialized", current_task=None)

    def _format_duration(self, seconds: float | None) -> str:
        if seconds is None or math.isnan(seconds) or math.isinf(seconds):
            return "--:--:--"
        seconds_int = max(0, int(seconds))
        hours, remainder = divmod(seconds_int, 3600)
        minutes, secs = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    def _bar(self, width: int = 24) -> str:
        if self.total <= 0:
            return "[" + "-" * width + "]"
        ratio = min(max(self.completed / self.total, 0.0), 1.0)
        filled = int(round(ratio * width))
        return "[" + "#" * filled + "-" * (width - filled) + "]"

    def _eta_seconds(self) -> float | None:
        if self.run_completed <= 0:
            return None
        elapsed = time.perf_counter() - self.started_at
        avg = elapsed / self.run_completed
        remaining = max(self.total - self.completed, 0)
        return avg * remaining

    def _write(self, *, status: str, current_task: str | None, error: str | None = None) -> None:
        elapsed = time.perf_counter() - self.started_at
        payload = {
            "status": status,
            "completed": self.completed,
            "total": self.total,
            "percent": 0.0 if self.total == 0 else self.completed / self.total,
            "elapsed_seconds": elapsed,
            "elapsed_hms": self._format_duration(elapsed),
            "eta_seconds": self._eta_seconds(),
            "eta_hms": self._format_duration(self._eta_seconds()),
            "current_task": current_task,
            "error": error,
        }
        self.progress_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def log_skip(self, label: str) -> None:
        self.completed += 1
        print(
            f"{self._bar()} {self.completed}/{self.total} "
            f"({(self.completed / self.total * 100.0) if self.total else 0.0:5.1f}%) "
            f"skip  elapsed={self._format_duration(time.perf_counter() - self.started_at)} "
            f"eta={self._format_duration(self._eta_seconds())}  {label}",
            flush=True,
        )
        self._write(status="running", current_task=label)

    def log_done(self, label: str) -> None:
        self.completed += 1
        self.run_processed += 1
        self.run_completed += 1
        print(
            f"{self._bar()} {self.completed}/{self.total} "
            f"({(self.completed / self.total * 100.0) if self.total else 0.0:5.1f}%) "
            f"done  elapsed={self._format_duration(time.perf_counter() - self.started_at)} "
            f"eta={self._format_duration(self._eta_seconds())}  {label}",
            flush=True,
        )
        self._write(status="running", current_task=label)

    def log_start(self, label: str) -> None:
        print(
            f"{self._bar()} {self.completed}/{self.total} "
            f"({(self.completed / self.total * 100.0) if self.total else 0.0:5.1f}%) "
            f"run   elapsed={self._format_duration(time.perf_counter() - self.started_at)} "
            f"eta={self._format_duration(self._eta_seconds())}  {label}",
            flush=True,
        )
        self._write(status="running", current_task=label)

    def log_error(self, label: str, error: str) -> None:
        self.run_processed += 1
        print(
            f"{self._bar()} {self.completed}/{self.total} "
            f"({(self.completed / self.total * 100.0) if self.total else 0.0:5.1f}%) "
            f"error elapsed={self._format_duration(time.perf_counter() - self.started_at)} "
            f"eta={self._format_duration(self._eta_seconds())}  {label}",
            flush=True,
        )
        self._write(status="error", current_task=label, error=error)

    def finalize(self) -> None:
        self._write(status="completed", current_task=None)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run 15-fold strict-CV stress experiments with progress and ETA.")
    parser.add_argument("--project-dir", default=".", help="Project root.")
    parser.add_argument("--splits-dir", default="experiment_setup/splits", help="Split directory.")
    parser.add_argument("--ablation-root", default="runs/ablation_suite_v1", help="Completed strict-CV main experiment root.")
    parser.add_argument("--output-dir", default="runs/extreme_stress_strict_cv_v1", help="Strict-CV stress output root.")
    parser.add_argument(
        "--run-scope",
        choices=["all", "train", "image-input", "missing-view", "clinical", "tda", "combo"],
        default="all",
    )
    parser.add_argument("--models", default=",".join(DEFAULT_MODELS), help="Comma-separated subset of models to include.")
    parser.add_argument(
        "--conditions",
        default="",
        help="Optional comma-separated condition names to include after building the selected stress family.",
    )
    parser.add_argument("--max-conditions", type=int, default=-1, help="Limit conditions per family for smoke/debug runs.")
    parser.add_argument("--max-folds", type=int, default=-1, help="Limit the number of outer folds for smoke/debug runs.")
    parser.add_argument("--seed", type=int, default=20260331, help="Base seed for stress perturbations.")
    parser.add_argument("--device", default="cuda", help="Execution device.")
    parser.add_argument("--batch-size", type=int, default=-1, help="Override batch size for deep-model eval/train if > 0.")
    parser.add_argument("--num-workers", type=int, default=-1, help="Override num_workers for deep-model training if > 0.")
    parser.add_argument("--max-train-batches", type=int, default=-1, help="Debug limit for train batches.")
    parser.add_argument("--max-val-batches", type=int, default=-1, help="Debug limit for validation batches.")
    parser.add_argument("--resume-existing", action="store_true", help="Skip tasks with existing canonical task_result.json.")
    parser.add_argument("--no-amp", action="store_true", help="Disable AMP for deep models.")
    parser.add_argument(
        "--artifact-mode",
        choices=["metrics-only", "full"],
        default="metrics-only",
        help="metrics-only removes bulky transient artifacts when possible.",
    )
    return parser.parse_args()


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    _ensure_dir(path.parent)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _parse_models(raw: str) -> tuple[str, ...]:
    models = tuple(part.strip().lower() for part in raw.split(",") if part.strip())
    invalid = [model for model in models if model not in SUPPORTED_MODELS]
    if invalid:
        raise ValueError(f"Unsupported models: {invalid}")
    return models


def _parse_conditions(raw: str) -> set[str]:
    return {part.strip() for part in raw.split(",") if part.strip()}


def _selected_folds(max_folds: int) -> list[tuple[int, int]]:
    folds = [(repeat, outer_fold) for repeat in range(1, 4) for outer_fold in range(1, 6)]
    return folds[:max_folds] if max_folds > 0 else folds


def _limit_specs(specs: list[Any], max_conditions: int) -> list[Any]:
    return specs[:max_conditions] if max_conditions > 0 else specs


def _task_label(task: StressTask) -> str:
    return f"{task.family}/{task.model_name}/r{task.repeat:02d}f{task.outer_fold:02d}/{task.condition_name}"


def _task_root(output_root: Path, task: StressTask) -> Path:
    return output_root / task.family / task.model_name / f"repeat_{task.repeat:02d}" / f"outer_fold_{task.outer_fold:02d}" / task.condition_name


def _task_result_path(output_root: Path, task: StressTask) -> Path:
    return _task_root(output_root, task) / "task_result.json"


def _build_clinical_valid_postprocess(spec: EvalStressSpec, *, seed: int):
    numeric_columns = list(CLINICAL_FEATURE_COLUMNS[:-1])
    group_map = {
        "astigmatism": ["astig_value_D", "astig_axis_deg"],
        "kmax": ["kmax_value_D", "kmax_axis_deg"],
        "pachy": ["pachy_central_um", "pachy_thinnest_um", "pachy_thinnest_x", "pachy_thinnest_y"],
    }

    def _postprocess(frame: pd.DataFrame) -> pd.DataFrame:
        updated = frame.copy()
        rng = torch.Generator().manual_seed(seed)
        if spec.mask_clinical:
            updated.loc[:, CLINICAL_FEATURE_COLUMNS] = 0.0
            return updated
        for group_name in spec.clinical_drop_groups:
            for column in group_map.get(group_name.lower(), []):
                if column in updated.columns:
                    updated.loc[:, column] = 0.0
        if spec.clinical_missing_fraction > 0.0 and numeric_columns:
            random_values = torch.rand((len(updated), len(numeric_columns)), generator=rng).numpy()
            mask = random_values >= spec.clinical_missing_fraction
            updated.loc[:, numeric_columns] = updated.loc[:, numeric_columns].to_numpy(dtype=float) * mask
        if spec.clinical_noise_std > 0.0 and numeric_columns:
            noise = torch.randn((len(updated), len(numeric_columns)), generator=rng).numpy() * spec.clinical_noise_std
            updated.loc[:, numeric_columns] = updated.loc[:, numeric_columns].to_numpy(dtype=float) + noise
        return updated

    return _postprocess


def _build_tda_valid_postprocess(spec: EvalStressSpec, *, feature_columns: list[str], seed: int):
    view_prefixes = tuple(f"{view.lower()}_" for view in spec.tda_drop_views)
    keep_homology = spec.tda_keep_homology.lower().strip()

    def _postprocess(frame: pd.DataFrame) -> pd.DataFrame:
        updated = frame.copy()
        rng = torch.Generator().manual_seed(seed)
        if spec.mask_tda:
            updated.loc[:, feature_columns] = 0.0
            return updated
        if view_prefixes:
            for column in feature_columns:
                if any(column.startswith(prefix) for prefix in view_prefixes):
                    updated.loc[:, column] = 0.0
        if keep_homology in {"h0", "h1"}:
            token = f"_{keep_homology}"
            drop_columns = [column for column in feature_columns if token not in column]
            if drop_columns:
                updated.loc[:, drop_columns] = 0.0
        if spec.tda_dropout_fraction > 0.0:
            random_values = torch.rand((len(updated), len(feature_columns)), generator=rng).numpy()
            mask = random_values >= spec.tda_dropout_fraction
            updated.loc[:, feature_columns] = updated.loc[:, feature_columns].to_numpy(dtype=float) * mask
        if spec.tda_noise_std > 0.0:
            noise = torch.randn((len(updated), len(feature_columns)), generator=rng).numpy() * spec.tda_noise_std
            updated.loc[:, feature_columns] = updated.loc[:, feature_columns].to_numpy(dtype=float) + noise
        return updated

    return _postprocess


def _load_deep_runner_config(
    args: argparse.Namespace,
    checkpoint_path: Path,
    *,
    output_dir: str,
) -> RunnerConfig:
    payload = torch.load(checkpoint_path, map_location="cpu")
    saved = dict(payload.get("config", {}))
    config_values = asdict(RunnerConfig())
    for key, value in saved.items():
        if key in RUNNER_FIELD_NAMES:
            config_values[key] = value
    config_values["project_dir"] = args.project_dir
    config_values["splits_dir"] = args.splits_dir
    config_values["output_dir"] = output_dir
    config_values["device"] = args.device
    config_values["resume_existing"] = args.resume_existing
    config_values["seed"] = args.seed
    config_values["amp"] = False if args.no_amp else bool(config_values.get("amp", True))
    config_values["max_train_batches"] = args.max_train_batches
    config_values["max_val_batches"] = args.max_val_batches
    if args.batch_size > 0:
        config_values["batch_size"] = args.batch_size
    if args.num_workers >= 0:
        config_values["num_workers"] = args.num_workers
    return RunnerConfig(**config_values)


def _load_baseline_template_config(
    args: argparse.Namespace,
    ablation_root: Path,
    model_name: str,
    *,
    output_dir: str,
) -> ClinicalBaselineConfig | TDABaselineConfig:
    summary_path = ablation_root / model_name / "outer_cv_summary.json"
    summary = _load_json(summary_path)
    config_payload = dict(summary.get("config", {}))
    if model_name == "clinical_only":
        config_values = asdict(ClinicalBaselineConfig())
        field_names = CLINICAL_CONFIG_FIELD_NAMES
        config_cls = ClinicalBaselineConfig
    else:
        config_values = asdict(TDABaselineConfig())
        field_names = TDA_CONFIG_FIELD_NAMES
        config_cls = TDABaselineConfig
    for key, value in config_payload.items():
        if key in field_names:
            config_values[key] = value
    config_values["project_dir"] = args.project_dir
    config_values["splits_dir"] = args.splits_dir
    config_values["output_dir"] = output_dir
    config_values["resume_existing"] = args.resume_existing
    config_values["seed"] = args.seed
    return config_cls(**config_values)


def _build_task_result(
    *,
    task: StressTask,
    metrics: dict[str, Any],
    source_path: Path,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = {
        "family": task.family,
        "model_name": task.model_name,
        "repeat": task.repeat,
        "outer_fold": task.outer_fold,
        "condition_name": task.condition_name,
        "handler": task.handler,
        "metrics": metrics,
        "source_path": str(source_path),
    }
    if extra:
        payload.update(extra)
    return payload


FAMILY_ORDER = [
    "clean_reference",
    "train_stress",
    "image_input",
    "missing_view",
    "clinical_modality",
    "tda_feature",
    "combo_train",
    "combo_extreme",
]

MODEL_ORDER = list(SUPPORTED_MODELS)


def _task_seed(base_seed: int, task: StressTask, *, extra: int = 0) -> int:
    condition_score = sum(ord(ch) for ch in f"{task.family}:{task.model_name}:{task.condition_name}")
    return int(base_seed + task.repeat * 10_000 + task.outer_fold * 1_000 + condition_score + extra)


def _ordered_sort(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    working = frame.copy()
    if "family" in working.columns:
        working["family_order"] = working["family"].map({name: idx for idx, name in enumerate(FAMILY_ORDER)}).fillna(999)
    else:
        working["family_order"] = 999
    if "model_name" in working.columns:
        working["model_order"] = working["model_name"].map({name: idx for idx, name in enumerate(MODEL_ORDER)}).fillna(999)
    else:
        working["model_order"] = 999
    sort_columns = [
        column
        for column in ["family_order", "model_order", "repeat", "outer_fold", "condition_name"]
        if column in working.columns
    ]
    working = working.sort_values(sort_columns, kind="stable").drop(columns=["family_order", "model_order"], errors="ignore")
    return working.reset_index(drop=True)


def _jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _collect_clean_reference_rows(
    *,
    ablation_root: Path,
    models: Iterable[str],
    folds: list[tuple[int, int]],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for model_name in models:
        for repeat, outer_fold in folds:
            history_path = ablation_root / model_name / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}" / "history.json"
            if not history_path.exists():
                continue
            history = _load_json(history_path)
            row = {
                "family": "clean_reference",
                "model_name": model_name,
                "repeat": repeat,
                "outer_fold": outer_fold,
                "condition_name": "clean_reference",
                "handler": "clean_reference",
                "source_path": str(history_path),
            }
            row.update(history.get("best_metrics", {}))
            if model_name in PRIMARY_IMAGE_MODELS:
                row["selected_epoch"] = history.get("selected_epoch")
            else:
                params = history.get("best_params") or history.get("chosen_params") or {}
                row["chosen_params"] = json.dumps(params, ensure_ascii=False, sort_keys=True)
            rows.append(row)
    return _ordered_sort(pd.DataFrame(rows))


def _collect_task_rows(output_root: Path) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for result_path in sorted(output_root.rglob("task_result.json")):
        payload = _load_json(result_path)
        row = {"task_result_path": str(result_path)}
        for key, value in payload.items():
            if key == "metrics":
                continue
            row[key] = _jsonable(value)
        for metric_name, metric_value in dict(payload.get("metrics", {})).items():
            row[metric_name] = metric_value
        rows.append(row)
    return _ordered_sort(pd.DataFrame(rows))


def _summarize_frame(frame: pd.DataFrame, *, group_keys: list[str]) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame()
    metric_columns = [column for column in METRIC_COLUMNS if column in frame.columns]
    rows: list[dict[str, Any]] = []
    for key_values, group in frame.groupby(group_keys, sort=False, dropna=False):
        if not isinstance(key_values, tuple):
            key_values = (key_values,)
        row = {key: value for key, value in zip(group_keys, key_values)}
        row["n_folds"] = int(len(group))
        if "repeat" in group.columns:
            row["n_repeats"] = int(pd.to_numeric(group["repeat"], errors="coerce").dropna().nunique())
        for metric_name in metric_columns:
            series = pd.to_numeric(group[metric_name], errors="coerce").dropna()
            if series.empty:
                continue
            mean_value = float(series.mean())
            std_pop = float(series.std(ddof=0)) if len(series) > 1 else 0.0
            std_sample = float(series.std(ddof=1)) if len(series) > 1 else 0.0
            ci_half = 1.96 * std_sample / math.sqrt(len(series)) if len(series) > 1 else 0.0
            row[f"{metric_name}_mean"] = mean_value
            row[f"{metric_name}_std"] = std_pop
            row[f"{metric_name}_ci95_low"] = mean_value - ci_half
            row[f"{metric_name}_ci95_high"] = mean_value + ci_half
            row[f"{metric_name}_min"] = float(series.min())
            row[f"{metric_name}_max"] = float(series.max())
        rows.append(row)
    return _ordered_sort(pd.DataFrame(rows))


def _build_overview(condition_summary: pd.DataFrame, clean_summary: pd.DataFrame) -> pd.DataFrame:
    if condition_summary.empty:
        return pd.DataFrame()
    clean_lookup = clean_summary.set_index("model_name") if not clean_summary.empty else pd.DataFrame()
    rows: list[dict[str, Any]] = []

    def _pick_worst(group: pd.DataFrame, metric_name: str) -> pd.Series | None:
        metric_column = f"{metric_name}_mean"
        if metric_column not in group.columns:
            return None
        candidate = group[group["condition_name"] != "clean"].copy()
        if candidate.empty:
            candidate = group.copy()
        candidate = candidate[pd.to_numeric(candidate[metric_column], errors="coerce").notna()].copy()
        if candidate.empty:
            return None
        candidate = candidate.sort_values([metric_column, "condition_name"], ascending=[True, True], kind="stable")
        return candidate.iloc[0]

    for (family, model_name), group in condition_summary.groupby(["family", "model_name"], sort=False, dropna=False):
        group = group.reset_index(drop=True)
        clean_row = clean_lookup.loc[model_name] if not clean_lookup.empty and model_name in clean_lookup.index else None
        worst_auroc = _pick_worst(group, "auroc")
        worst_bal_acc = _pick_worst(group, "balanced_accuracy")
        worst_f1 = _pick_worst(group, "f1")
        row = {
            "family": family,
            "model_name": model_name,
            "num_conditions": int(len(group)),
            "clean_auroc_mean": None if clean_row is None else clean_row.get("auroc_mean"),
            "clean_balanced_accuracy_mean": None if clean_row is None else clean_row.get("balanced_accuracy_mean"),
            "clean_f1_mean": None if clean_row is None else clean_row.get("f1_mean"),
            "clean_mcc_mean": None if clean_row is None else clean_row.get("mcc_mean"),
        }
        if worst_auroc is not None:
            row["worst_auroc_condition"] = worst_auroc["condition_name"]
            row["worst_auroc_mean"] = worst_auroc.get("auroc_mean")
        if worst_bal_acc is not None:
            row["worst_balanced_accuracy_condition"] = worst_bal_acc["condition_name"]
            row["worst_balanced_accuracy_mean"] = worst_bal_acc.get("balanced_accuracy_mean")
        if worst_f1 is not None:
            row["worst_f1_condition"] = worst_f1["condition_name"]
            row["worst_f1_mean"] = worst_f1.get("f1_mean")
        for metric_name in ("auroc_retention", "balanced_accuracy_retention", "f1_retention", "mcc_retention"):
            metric_column = f"{metric_name}_mean"
            if metric_column not in group.columns:
                continue
            series = pd.to_numeric(group[metric_column], errors="coerce").dropna()
            if series.empty:
                continue
            row[f"mean_{metric_name}"] = float(series.mean())
            row[f"min_{metric_name}"] = float(series.min())
        rows.append(row)
    return _ordered_sort(pd.DataFrame(rows))


def _write_excel(output_path: Path, sheets: dict[str, pd.DataFrame]) -> bool:
    try:
        with pd.ExcelWriter(output_path) as writer:
            for sheet_name, frame in sheets.items():
                frame.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        return True
    except Exception:
        return False


def _write_summary_outputs(
    *,
    output_root: Path,
    ablation_root: Path,
    models: tuple[str, ...],
    folds: list[tuple[int, int]],
    expected_tasks: int,
) -> dict[str, Any]:
    summary_dir = output_root / "summary_tables"
    _ensure_dir(summary_dir)

    clean_task_table = _collect_clean_reference_rows(ablation_root=ablation_root, models=models, folds=folds)
    clean_summary = _summarize_frame(clean_task_table, group_keys=["model_name", "condition_name"])
    stress_task_table = _collect_task_rows(output_root)
    condition_summary = _summarize_frame(stress_task_table, group_keys=["family", "model_name", "condition_name"])
    overview = _build_overview(condition_summary, clean_summary)

    clean_task_path = summary_dir / "strict_cv_clean_reference_task_table.csv"
    clean_summary_path = summary_dir / "strict_cv_clean_reference_summary.csv"
    task_path = summary_dir / "strict_cv_stress_task_table.csv"
    condition_path = summary_dir / "strict_cv_stress_condition_summary.csv"
    overview_path = summary_dir / "strict_cv_stress_overview.csv"

    clean_task_table.to_csv(clean_task_path, index=False, encoding="utf-8-sig")
    clean_summary.to_csv(clean_summary_path, index=False, encoding="utf-8-sig")
    stress_task_table.to_csv(task_path, index=False, encoding="utf-8-sig")
    condition_summary.to_csv(condition_path, index=False, encoding="utf-8-sig")
    overview.to_csv(overview_path, index=False, encoding="utf-8-sig")

    workbook_path = summary_dir / "strict_cv_stress_workbook.xlsx"
    excel_written = _write_excel(
        workbook_path,
        {
            "clean_reference_tasks": clean_task_table,
            "clean_reference_summary": clean_summary,
            "stress_task_table": stress_task_table,
            "condition_summary": condition_summary,
            "overview": overview,
        },
    )

    manifest = {
        "output_dir": str(output_root),
        "summary_dir": str(summary_dir),
        "expected_tasks": int(expected_tasks),
        "completed_tasks": int(len(stress_task_table)),
        "clean_reference_rows": int(len(clean_task_table)),
        "condition_rows": int(len(condition_summary)),
        "overview_rows": int(len(overview)),
        "excel_written": excel_written,
        "files": {
            "strict_cv_clean_reference_task_table": str(clean_task_path),
            "strict_cv_clean_reference_summary": str(clean_summary_path),
            "strict_cv_stress_task_table": str(task_path),
            "strict_cv_stress_condition_summary": str(condition_path),
            "strict_cv_stress_overview": str(overview_path),
            "strict_cv_stress_workbook": str(workbook_path) if excel_written else None,
        },
    }
    _write_json(summary_dir / "summary_manifest.json", manifest)
    return manifest


def _build_tasks(
    *,
    args: argparse.Namespace,
    splits_dir: Path,
    ablation_root: Path,
) -> tuple[list[StressTask], tuple[str, ...], list[tuple[int, int]]]:
    selected_models = _parse_models(args.models)
    folds = _selected_folds(args.max_folds)
    selected_model_set = set(selected_models)
    fold_info_cache: dict[tuple[str, int, int], dict[str, Any]] = {}

    def _fold_info(model_name: str, repeat: int, outer_fold: int) -> dict[str, Any]:
        cache_key = (model_name, repeat, outer_fold)
        if cache_key in fold_info_cache:
            return dict(fold_info_cache[cache_key])
        fold_root = ablation_root / model_name / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
        history_path = fold_root / "history.json"
        if not history_path.exists():
            raise FileNotFoundError(f"Missing clean fold history: {history_path}")
        outer_root = splits_dir / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{outer_fold:02d}"
        train_csv = outer_root / "outer_train_eyes.csv"
        valid_csv = outer_root / "outer_valid_eyes.csv"
        history = _load_json(history_path)
        info = {
            "fold_root": str(fold_root),
            "clean_history_path": str(history_path),
            "train_csv": str(train_csv),
            "valid_csv": str(valid_csv),
        }
        if model_name in PRIMARY_IMAGE_MODELS:
            checkpoint_path = fold_root / "best_model.pt"
            if not checkpoint_path.exists():
                raise FileNotFoundError(f"Missing clean fold checkpoint: {checkpoint_path}")
            info["checkpoint_path"] = str(checkpoint_path)
            info["selected_epoch"] = int(history.get("selected_epoch", 0) or 0)
        else:
            best_params = history.get("best_params") or history.get("chosen_params")
            if not best_params:
                raise ValueError(f"Missing best params in {history_path}")
            info["best_params"] = dict(best_params)
        fold_info_cache[cache_key] = dict(info)
        return dict(info)

    tasks: list[StressTask] = []
    requested_families: list[str] = []
    if args.run_scope in {"all", "train"}:
        requested_families.append("train_stress")
    if args.run_scope in {"all", "image-input"}:
        requested_families.append("image_input")
    if args.run_scope in {"all", "missing-view"}:
        requested_families.append("missing_view")
    if args.run_scope in {"all", "clinical"}:
        requested_families.append("clinical_modality")
    if args.run_scope in {"all", "tda"}:
        requested_families.append("tda_feature")
    if args.run_scope in {"all", "combo"}:
        requested_families.extend(["combo_train", "combo_extreme"])

    for family in requested_families:
        if family == "train_stress":
            specs = _limit_specs(build_requested_train_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_TRAIN_MODELS:
                if model_name not in selected_model_set:
                    continue
                if model_name == "clinical_only":
                    handler = "clinical_train"
                elif model_name == "tda_only":
                    handler = "tda_train"
                else:
                    handler = "deep_train"
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler=handler,
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "image_input":
            specs = _limit_specs(build_requested_image_input_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_IMAGE_MODELS:
                if model_name not in selected_model_set:
                    continue
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler="deep_eval",
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "missing_view":
            specs = _limit_specs(build_requested_missing_view_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_IMAGE_MODELS:
                if model_name not in selected_model_set:
                    continue
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler="deep_eval",
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "clinical_modality":
            specs = _limit_specs(build_requested_clinical_modality_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_CLINICAL_MODELS:
                if model_name not in selected_model_set:
                    continue
                handler = "clinical_eval" if model_name == "clinical_only" else "deep_eval"
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler=handler,
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "tda_feature":
            specs = _limit_specs(build_requested_tda_feature_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_TDA_MODELS:
                if model_name not in selected_model_set:
                    continue
                handler = "tda_eval" if model_name == "tda_only" else "deep_eval"
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler=handler,
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "combo_train":
            specs = _limit_specs(build_requested_combo_train_stress_suite(), args.max_conditions)
            for model_name in PRIMARY_TRAIN_MODELS:
                if model_name not in selected_model_set:
                    continue
                if model_name == "clinical_only":
                    handler = "clinical_train"
                elif model_name == "tda_only":
                    handler = "tda_train"
                else:
                    handler = "deep_train"
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for spec in specs:
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=spec.name,
                                handler=handler,
                                payload={**info, "spec": spec},
                            )
                        )
        elif family == "combo_extreme":
            combo_definitions: list[tuple[str, dict[str, Any]]] = [
                ("deep_eval", {"spec": spec}) for spec in build_requested_combo_eval_suite()
            ]
            combo_name = "combo_positive_retention10_blur2_res96"
            combo_definitions.append(
                (
                    "deep_combo_train_eval",
                    {
                        "train_spec": TrainStressSpec(name=combo_name, positive_patient_fraction=0.10),
                        "eval_spec": EvalStressSpec(
                            name=combo_name,
                            corruption="gaussian_blur",
                            severity=2,
                            downsample_size=96,
                        ),
                    },
                )
            )
            if args.max_conditions > 0:
                combo_definitions = combo_definitions[: args.max_conditions]
            for model_name in PRIMARY_COMBO_IMAGE_MODELS:
                if model_name not in selected_model_set:
                    continue
                for repeat, outer_fold in folds:
                    info = _fold_info(model_name, repeat, outer_fold)
                    for handler, definition in combo_definitions:
                        if handler == "deep_eval":
                            spec = definition["spec"]
                            if model_name == "image_only" and spec.name == "combo_clinical_missing40_tda_dropout30":
                                continue
                            condition_name = spec.name
                        else:
                            condition_name = definition["eval_spec"].name
                        tasks.append(
                            StressTask(
                                family=family,
                                model_name=model_name,
                                repeat=repeat,
                                outer_fold=outer_fold,
                                condition_name=condition_name,
                                handler=handler,
                                payload={**info, **definition},
                            )
                        )
        else:
            raise ValueError(f"Unsupported family: {family}")

    selected_conditions = _parse_conditions(args.conditions)
    if selected_conditions:
        tasks = [task for task in tasks if task.condition_name in selected_conditions]

    return tasks, selected_models, folds


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir).resolve()
    splits_dir = (project_dir / args.splits_dir).resolve()
    ablation_root = (project_dir / args.ablation_root).resolve()
    output_root = (project_dir / args.output_dir).resolve()
    _ensure_dir(output_root)

    tasks, selected_models, folds = _build_tasks(args=args, splits_dir=splits_dir, ablation_root=ablation_root)
    if not tasks:
        raise ValueError("No strict-CV stress tasks were generated. Check --run-scope and --models.")

    pending_tasks: list[StressTask] = []
    completed_before_start = 0
    for task in tasks:
        if args.resume_existing and _task_result_path(output_root, task).exists():
            completed_before_start += 1
        else:
            pending_tasks.append(task)

    tracker = ProgressTracker(
        total=len(tasks),
        completed=completed_before_start,
        progress_path=output_root / "progress.json",
    )

    deep_config_cache: dict[tuple[str, int, int], RunnerConfig] = {}
    baseline_config_cache: dict[str, ClinicalBaselineConfig | TDABaselineConfig] = {}
    tda_feature_columns_cache: list[str] | None = None

    def _clone_deep_config(task: StressTask) -> RunnerConfig:
        cache_key = (task.model_name, task.repeat, task.outer_fold)
        if cache_key not in deep_config_cache:
            checkpoint_path = Path(task.payload["checkpoint_path"])
            deep_config_cache[cache_key] = _load_deep_runner_config(
                args,
                checkpoint_path,
                output_dir=str(output_root / "_template_configs" / task.model_name),
            )
        config = RunnerConfig(**asdict(deep_config_cache[cache_key]))
        config.project_dir = str(project_dir)
        config.splits_dir = str(Path(args.splits_dir))
        config.output_dir = str(output_root)
        config.device = args.device
        config.resume_existing = args.resume_existing
        config.seed = _task_seed(args.seed, task)
        if args.batch_size > 0:
            config.batch_size = args.batch_size
        if args.num_workers >= 0:
            config.num_workers = args.num_workers
        config.max_train_batches = args.max_train_batches
        config.max_val_batches = args.max_val_batches
        config.amp = False if args.no_amp else config.amp
        return config

    def _baseline_config(model_name: str) -> ClinicalBaselineConfig | TDABaselineConfig:
        if model_name not in baseline_config_cache:
            baseline_config_cache[model_name] = _load_baseline_template_config(
                args,
                ablation_root,
                model_name,
                output_dir=str(output_root / "_template_configs" / model_name),
            )
        config = baseline_config_cache[model_name]
        cloned = type(config)(**asdict(config))
        cloned.project_dir = str(project_dir)
        cloned.splits_dir = str(Path(args.splits_dir))
        cloned.output_dir = str(output_root)
        cloned.resume_existing = args.resume_existing
        cloned.seed = args.seed
        return cloned

    def _tda_feature_columns() -> list[str]:
        nonlocal tda_feature_columns_cache
        if tda_feature_columns_cache is None:
            _, columns = load_tda_feature_table(project_dir / _baseline_config("tda_only").features_csv)
            tda_feature_columns_cache = list(columns)
        return list(tda_feature_columns_cache)

    def _run_task(task: StressTask) -> dict[str, Any]:
        task_root = _task_root(output_root, task)
        runtime_root = task_root.parent
        _ensure_dir(task_root)
        _ensure_dir(runtime_root)
        task_seed = _task_seed(args.seed, task)
        metrics_only = args.artifact_mode == "metrics-only"
        base_extra = {
            "task_root": str(task_root),
            "runtime_root": str(runtime_root),
            "fold_root": task.payload["fold_root"],
            "clean_history_path": task.payload["clean_history_path"],
            "train_csv": task.payload["train_csv"],
            "valid_csv": task.payload["valid_csv"],
        }

        if task.handler == "deep_eval":
            spec: EvalStressSpec = task.payload["spec"]
            config = _clone_deep_config(task)
            result = run_eval_stress(
                config=config,
                checkpoint_path=Path(task.payload["checkpoint_path"]),
                spec=spec,
                output_root=runtime_root,
                resume_existing=args.resume_existing,
                save_predictions=not metrics_only,
                train_csv=Path(task.payload["train_csv"]),
                valid_csv=Path(task.payload["valid_csv"]),
                clean_history_path=Path(task.payload["clean_history_path"]),
            )
            return _build_task_result(
                task=task,
                metrics=dict(result.get("metrics", {})),
                source_path=runtime_root / "eval_stress" / spec.name / "result.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "checkpoint_path": task.payload["checkpoint_path"],
                    "seed": task_seed,
                },
            )

        if task.handler == "deep_train":
            spec: TrainStressSpec = task.payload["spec"]
            config = _clone_deep_config(task)
            result = run_train_stress(
                config=config,
                spec=spec,
                output_root=runtime_root,
                resume_existing=args.resume_existing,
                persist_stressed_split=not metrics_only,
                save_checkpoint=not metrics_only,
                save_predictions=not metrics_only,
                base_train_csv=Path(task.payload["train_csv"]),
                valid_csv=Path(task.payload["valid_csv"]),
                clean_history_path=Path(task.payload["clean_history_path"]),
                fixed_selected_epoch=int(task.payload.get("selected_epoch", 0) or 0) or None,
                extra_meta={
                    "repeat": task.repeat,
                    "outer_fold": task.outer_fold,
                    "family": task.family,
                    "condition_name": task.condition_name,
                },
            )
            return _build_task_result(
                task=task,
                metrics=dict(result.get("best_metrics", {})),
                source_path=runtime_root / "train_stress" / spec.name / "history.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "selected_epoch": int(task.payload.get("selected_epoch", 0) or 0) or None,
                    "seed": task_seed,
                    "stressed_train_csv": result.get("stressed_train_csv"),
                },
            )

        if task.handler == "clinical_eval":
            spec: EvalStressSpec = task.payload["spec"]
            config = _baseline_config("clinical_only")
            output_dir = runtime_root / "eval_stress" / spec.name
            clean_metrics = dict(_load_json(Path(task.payload["clean_history_path"])).get("best_metrics", {}))
            result = run_clinical_fixed_split(
                config,
                train_csv=Path(task.payload["train_csv"]),
                valid_csv=Path(task.payload["valid_csv"]),
                C=float(task.payload["best_params"]["C"]),
                l1_ratio=float(task.payload["best_params"]["l1_ratio"]),
                output_dir=output_dir,
                split_name=f"{task.family}_{spec.name}",
                meta={
                    "repeat": task.repeat,
                    "outer_fold": task.outer_fold,
                    "family": task.family,
                    "condition_name": task.condition_name,
                },
                save_predictions=not metrics_only,
                valid_frame_postprocess=_build_clinical_valid_postprocess(spec, seed=task_seed),
            )
            metrics = _augment_with_retention(dict(result.get("best_metrics", {})), clean_metrics)
            result["best_metrics"] = metrics
            _write_json(output_dir / "history.json", result)
            return _build_task_result(
                task=task,
                metrics=metrics,
                source_path=output_dir / "history.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "chosen_params": task.payload["best_params"],
                    "seed": task_seed,
                },
            )

        if task.handler == "tda_eval":
            spec: EvalStressSpec = task.payload["spec"]
            config = _baseline_config("tda_only")
            output_dir = runtime_root / "eval_stress" / spec.name
            clean_metrics = dict(_load_json(Path(task.payload["clean_history_path"])).get("best_metrics", {}))
            result = run_tda_fixed_split(
                config,
                train_csv=Path(task.payload["train_csv"]),
                valid_csv=Path(task.payload["valid_csv"]),
                C=float(task.payload["best_params"]["C"]),
                l1_ratio=float(task.payload["best_params"]["l1_ratio"]),
                output_dir=output_dir,
                split_name=f"{task.family}_{spec.name}",
                meta={
                    "repeat": task.repeat,
                    "outer_fold": task.outer_fold,
                    "family": task.family,
                    "condition_name": task.condition_name,
                },
                save_predictions=not metrics_only,
                valid_frame_postprocess=_build_tda_valid_postprocess(
                    spec,
                    feature_columns=_tda_feature_columns(),
                    seed=task_seed,
                ),
            )
            metrics = _augment_with_retention(dict(result.get("best_metrics", {})), clean_metrics)
            result["best_metrics"] = metrics
            _write_json(output_dir / "history.json", result)
            return _build_task_result(
                task=task,
                metrics=metrics,
                source_path=output_dir / "history.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "chosen_params": task.payload["best_params"],
                    "seed": task_seed,
                },
            )

        if task.handler == "clinical_train":
            spec: TrainStressSpec = task.payload["spec"]
            config = _baseline_config("clinical_only")
            output_dir = runtime_root / "train_stress" / spec.name
            _ensure_dir(output_dir)
            stressed_train_df = _prepare_train_stress_split(
                Path(task.payload["train_csv"]),
                spec=spec,
                seed=task_seed,
            )
            stressed_train_csv = output_dir / ("stressed_train_split.csv" if not metrics_only else "__tmp_stressed_train_split.csv")
            stressed_train_df.to_csv(stressed_train_csv, index=False, encoding="utf-8-sig")
            clean_metrics = dict(_load_json(Path(task.payload["clean_history_path"])).get("best_metrics", {}))
            metrics: dict[str, Any] = {}
            try:
                result = run_clinical_fixed_split(
                    config,
                    train_csv=stressed_train_csv,
                    valid_csv=Path(task.payload["valid_csv"]),
                    C=float(task.payload["best_params"]["C"]),
                    l1_ratio=float(task.payload["best_params"]["l1_ratio"]),
                    output_dir=output_dir,
                    split_name=f"{task.family}_{spec.name}",
                    meta={
                        "repeat": task.repeat,
                        "outer_fold": task.outer_fold,
                        "family": task.family,
                        "condition_name": task.condition_name,
                        "base_train_csv": task.payload["train_csv"],
                        "selection_policy": "fixed_reference_params",
                        "stress_type": "train_stress",
                        "spec": asdict(spec),
                    },
                    save_predictions=not metrics_only,
                )
                metrics = _augment_with_retention(dict(result.get("best_metrics", {})), clean_metrics)
                result["best_metrics"] = metrics
                result["stressed_train_csv"] = str(stressed_train_csv)
                _write_json(output_dir / "history.json", result)
            finally:
                if metrics_only and stressed_train_csv.exists():
                    stressed_train_csv.unlink()
            return _build_task_result(
                task=task,
                metrics=metrics,
                source_path=output_dir / "history.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "chosen_params": task.payload["best_params"],
                    "seed": task_seed,
                    "stressed_train_csv": None if metrics_only else str(stressed_train_csv),
                },
            )

        if task.handler == "tda_train":
            spec: TrainStressSpec = task.payload["spec"]
            config = _baseline_config("tda_only")
            output_dir = runtime_root / "train_stress" / spec.name
            _ensure_dir(output_dir)
            stressed_train_df = _prepare_train_stress_split(
                Path(task.payload["train_csv"]),
                spec=spec,
                seed=task_seed,
            )
            stressed_train_csv = output_dir / ("stressed_train_split.csv" if not metrics_only else "__tmp_stressed_train_split.csv")
            stressed_train_df.to_csv(stressed_train_csv, index=False, encoding="utf-8-sig")
            clean_metrics = dict(_load_json(Path(task.payload["clean_history_path"])).get("best_metrics", {}))
            metrics: dict[str, Any] = {}
            try:
                result = run_tda_fixed_split(
                    config,
                    train_csv=stressed_train_csv,
                    valid_csv=Path(task.payload["valid_csv"]),
                    C=float(task.payload["best_params"]["C"]),
                    l1_ratio=float(task.payload["best_params"]["l1_ratio"]),
                    output_dir=output_dir,
                    split_name=f"{task.family}_{spec.name}",
                    meta={
                        "repeat": task.repeat,
                        "outer_fold": task.outer_fold,
                        "family": task.family,
                        "condition_name": task.condition_name,
                        "base_train_csv": task.payload["train_csv"],
                        "selection_policy": "fixed_reference_params",
                        "stress_type": "train_stress",
                        "spec": asdict(spec),
                    },
                    save_predictions=not metrics_only,
                )
                metrics = _augment_with_retention(dict(result.get("best_metrics", {})), clean_metrics)
                result["best_metrics"] = metrics
                result["stressed_train_csv"] = str(stressed_train_csv)
                _write_json(output_dir / "history.json", result)
            finally:
                if metrics_only and stressed_train_csv.exists():
                    stressed_train_csv.unlink()
            return _build_task_result(
                task=task,
                metrics=metrics,
                source_path=output_dir / "history.json",
                extra={
                    **base_extra,
                    "spec": asdict(spec),
                    "chosen_params": task.payload["best_params"],
                    "seed": task_seed,
                    "stressed_train_csv": None if metrics_only else str(stressed_train_csv),
                },
            )

        if task.handler == "deep_combo_train_eval":
            train_spec: TrainStressSpec = task.payload["train_spec"]
            eval_spec: EvalStressSpec = task.payload["eval_spec"]
            config = _clone_deep_config(task)
            train_result = run_train_stress(
                config=config,
                spec=train_spec,
                output_root=runtime_root,
                resume_existing=args.resume_existing,
                persist_stressed_split=True,
                save_checkpoint=True,
                save_predictions=False,
                base_train_csv=Path(task.payload["train_csv"]),
                valid_csv=Path(task.payload["valid_csv"]),
                clean_history_path=Path(task.payload["clean_history_path"]),
                fixed_selected_epoch=int(task.payload.get("selected_epoch", 0) or 0) or None,
                extra_meta={
                    "repeat": task.repeat,
                    "outer_fold": task.outer_fold,
                    "family": task.family,
                    "condition_name": task.condition_name,
                    "combo_stage": "train",
                },
            )
            combo_train_root = runtime_root / "train_stress" / train_spec.name
            combo_checkpoint = combo_train_root / "best_model.pt"
            stressed_train_csv = Path(train_result["stressed_train_csv"])
            eval_result = run_eval_stress(
                config=config,
                checkpoint_path=combo_checkpoint,
                spec=eval_spec,
                output_root=runtime_root,
                resume_existing=args.resume_existing,
                save_predictions=not metrics_only,
                train_csv=stressed_train_csv,
                valid_csv=Path(task.payload["valid_csv"]),
                clean_history_path=Path(task.payload["clean_history_path"]),
            )
            task_result = _build_task_result(
                task=task,
                metrics=dict(eval_result.get("metrics", {})),
                source_path=runtime_root / "eval_stress" / eval_spec.name / "result.json",
                extra={
                    **base_extra,
                    "train_spec": asdict(train_spec),
                    "eval_spec": asdict(eval_spec),
                    "selected_epoch": int(task.payload.get("selected_epoch", 0) or 0) or None,
                    "seed": task_seed,
                    "train_metrics": dict(train_result.get("best_metrics", {})),
                    "train_source_path": str(combo_train_root / "history.json"),
                    "checkpoint_path": str(combo_checkpoint),
                    "stressed_train_csv": str(stressed_train_csv),
                },
            )
            if metrics_only and combo_checkpoint.exists():
                combo_checkpoint.unlink()
            if metrics_only and stressed_train_csv.exists():
                stressed_train_csv.unlink()
            return task_result

        raise ValueError(f"Unsupported task handler: {task.handler}")

    print(
        json.dumps(
            {
                "output_dir": str(output_root),
                "selected_models": list(selected_models),
                "num_folds": len(folds),
                "total_tasks": len(tasks),
                "completed_before_start": completed_before_start,
                "pending_tasks": len(pending_tasks),
                "artifact_mode": args.artifact_mode,
            },
            ensure_ascii=False,
            indent=2,
        ),
        flush=True,
    )

    try:
        for task in pending_tasks:
            label = _task_label(task)
            tracker.log_start(label)
            try:
                task_result = _run_task(task)
                _write_json(_task_result_path(output_root, task), task_result)
                tracker.log_done(label)
            except Exception as exc:
                tracker.log_error(label, repr(exc))
                raise
            finally:
                if args.device == "cuda" and torch.cuda.is_available():
                    torch.cuda.empty_cache()
    finally:
        manifest = _write_summary_outputs(
            output_root=output_root,
            ablation_root=ablation_root,
            models=selected_models,
            folds=folds,
            expected_tasks=len(tasks),
        )
        tracker.finalize()
        print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
