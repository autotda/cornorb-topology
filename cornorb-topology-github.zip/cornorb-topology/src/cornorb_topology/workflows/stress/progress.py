from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

import pandas as pd

from orbscan_experiment.stress import (
    build_requested_clinical_modality_stress_suite,
    build_requested_combo_eval_suite,
    build_requested_combo_train_stress_suite,
    build_requested_image_input_stress_suite,
    build_requested_missing_view_stress_suite,
    build_requested_tda_feature_stress_suite,
    build_requested_train_stress_suite,
)


PRIMARY_TRAIN_MODELS = ("clinical_only", "tda_only", "image_only", "image_clinical_tda")
PRIMARY_IMAGE_MODELS = ("image_only", "image_clinical_tda")
PRIMARY_CLINICAL_MODELS = ("clinical_only", "image_clinical_tda")
PRIMARY_TDA_MODELS = ("tda_only", "image_clinical_tda")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Report progress for the extreme stress suite outputs.")
    parser.add_argument("--output-dir", default="runs/extreme_stress_v3", help="Stress output root.")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of a text table.")
    return parser.parse_args()


def _count_condition_dirs(path: Path) -> int:
    if not path.exists():
        return 0
    return sum(1 for child in path.iterdir() if child.is_dir())


def _count_combo_rows(output_dir: Path, model_name: str) -> int:
    combined_path = output_dir / "combo_extreme_combined.csv"
    if not combined_path.exists():
        return 0
    frame = pd.read_csv(combined_path)
    if "model_name" not in frame.columns:
        return 0
    return int((frame["model_name"].astype(str) == model_name).sum())


def _latest_file(path: Path) -> dict[str, str | int] | None:
    if not path.exists():
        return None
    files = [child for child in path.rglob("*") if child.is_file()]
    if not files:
        return None
    non_log_files = [child for child in files if child.suffix.lower() != ".log"]
    if non_log_files:
        files = non_log_files
    latest = max(files, key=lambda item: item.stat().st_mtime)
    return {
        "path": str(latest),
        "size_bytes": latest.stat().st_size,
        "modified": datetime.fromtimestamp(latest.stat().st_mtime).isoformat(timespec="seconds"),
    }


def build_progress(output_dir: Path) -> dict[str, object]:
    sections: list[dict[str, object]] = []

    train_expected = len(build_requested_train_stress_suite())
    for model_name in PRIMARY_TRAIN_MODELS:
        section_path = output_dir / model_name / "train_stress"
        sections.append(
            {
                "section": f"train::{model_name}",
                "done": _count_condition_dirs(section_path),
                "expected": train_expected,
                "path": str(section_path),
            }
        )

    image_expected = len(build_requested_image_input_stress_suite())
    for model_name in PRIMARY_IMAGE_MODELS:
        section_path = output_dir / model_name / "image_input" / "eval_stress"
        sections.append(
            {
                "section": f"image_input::{model_name}",
                "done": _count_condition_dirs(section_path),
                "expected": image_expected,
                "path": str(section_path),
            }
        )

    missing_expected = len(build_requested_missing_view_stress_suite())
    for model_name in PRIMARY_IMAGE_MODELS:
        section_path = output_dir / model_name / "missing_view" / "eval_stress"
        sections.append(
            {
                "section": f"missing_view::{model_name}",
                "done": _count_condition_dirs(section_path),
                "expected": missing_expected,
                "path": str(section_path),
            }
        )

    clinical_expected = len(build_requested_clinical_modality_stress_suite())
    for model_name in PRIMARY_CLINICAL_MODELS:
        section_path = output_dir / model_name / "clinical_modality" / "eval_stress"
        sections.append(
            {
                "section": f"clinical::{model_name}",
                "done": _count_condition_dirs(section_path),
                "expected": clinical_expected,
                "path": str(section_path),
            }
        )

    tda_expected = len(build_requested_tda_feature_stress_suite())
    for model_name in PRIMARY_TDA_MODELS:
        section_path = output_dir / model_name / "tda_feature" / "eval_stress"
        sections.append(
            {
                "section": f"tda::{model_name}",
                "done": _count_condition_dirs(section_path),
                "expected": tda_expected,
                "path": str(section_path),
            }
        )

    combo_train_expected = len(build_requested_combo_train_stress_suite())
    sections.extend(
        [
            {
                "section": "combo_train::clinical_only",
                "done": _count_condition_dirs(output_dir / "clinical_only" / "combo_train"),
                "expected": combo_train_expected,
                "path": str(output_dir / "clinical_only" / "combo_train"),
            },
            {
                "section": "combo_train::tda_only",
                "done": _count_condition_dirs(output_dir / "tda_only" / "combo_train"),
                "expected": combo_train_expected,
                "path": str(output_dir / "tda_only" / "combo_train"),
            },
            {
                "section": "combo_train::image_only",
                "done": _count_condition_dirs(output_dir / "image_only" / "combo_train" / "train_stress"),
                "expected": combo_train_expected,
                "path": str(output_dir / "image_only" / "combo_train" / "train_stress"),
            },
            {
                "section": "combo_train::image_clinical_tda",
                "done": _count_condition_dirs(output_dir / "image_clinical_tda" / "combo_train" / "train_stress"),
                "expected": combo_train_expected,
                "path": str(output_dir / "image_clinical_tda" / "combo_train" / "train_stress"),
            },
        ]
    )

    combo_eval_expected = len(build_requested_combo_eval_suite())
    sections.extend(
        [
            {
                "section": "combo_extreme::image_only",
                "done": _count_combo_rows(output_dir, "image_only"),
                "expected": combo_eval_expected,
                "path": str(output_dir / "combo_extreme_combined.csv"),
            },
            {
                "section": "combo_extreme::image_clinical_tda",
                "done": _count_combo_rows(output_dir, "image_clinical_tda"),
                "expected": combo_eval_expected + 1,
                "path": str(output_dir / "combo_extreme_combined.csv"),
            },
        ]
    )

    total_done = sum(int(section["done"]) for section in sections)
    total_expected = sum(int(section["expected"]) for section in sections)
    latest = _latest_file(output_dir)
    current_section = next(
        (
            section["section"]
            for section in sections
            if int(section["done"]) < int(section["expected"])
        ),
        "completed",
    )
    return {
        "output_dir": str(output_dir),
        "total_done": total_done,
        "total_expected": total_expected,
        "completion_ratio": 0.0 if total_expected == 0 else total_done / total_expected,
        "current_section": current_section,
        "sections": sections,
        "latest_file": latest,
    }


def _print_text(progress: dict[str, object]) -> None:
    print(f"output_dir: {progress['output_dir']}")
    print(
        "overall: "
        f"{progress['total_done']}/{progress['total_expected']} "
        f"({float(progress['completion_ratio']) * 100.0:.1f}%)"
    )
    print(f"current_section: {progress['current_section']}")
    latest_file = progress.get("latest_file")
    if isinstance(latest_file, dict):
        print(f"latest_file: {latest_file['path']}")
    print("")
    for section in progress["sections"]:
        print(f"{section['section']}: {section['done']}/{section['expected']}")


def main() -> None:
    args = parse_args()
    progress = build_progress(Path(args.output_dir))
    if args.json:
        print(json.dumps(progress, ensure_ascii=False, indent=2))
        return
    _print_text(progress)


if __name__ == "__main__":
    main()
