"""Strict-CV stress testing and progress reporting."""
