from __future__ import annotations

import argparse
from collections import Counter
import csv
import json
from pathlib import Path


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not {"patient_eye_id", "patient_code", "label"}.issubset(reader.fieldnames or []):
            raise ValueError(f"Required identity/label columns are missing: {path}")
        rows = list(reader)
    if not rows:
        raise ValueError(f"Empty split: {path}")
    return rows


def index_rows(rows: list[dict[str, str]]) -> dict[str, tuple[str, str]]:
    indexed = {}
    for row in rows:
        eye_id, patient, label = row["patient_eye_id"], row["patient_code"], row["label"]
        if not eye_id or not patient or label not in {"0", "1"}:
            raise ValueError("Empty identity or non-binary label in a primary split.")
        if eye_id in indexed:
            raise ValueError("Duplicate eye identity in a split.")
        indexed[eye_id] = (patient, label)
    return indexed


def check_partition(
    train: dict[str, tuple[str, str]],
    valid: dict[str, tuple[str, str]],
    reference: dict[str, tuple[str, str]],
) -> None:
    if not train or not valid:
        raise ValueError("Train and validation splits must both be non-empty.")
    if set(train) & set(valid):
        raise ValueError("Eye identity leakage between train and validation.")
    if {v[0] for v in train.values()} & {v[0] for v in valid.values()}:
        raise ValueError("Patient leakage between train and validation.")
    if {**train, **valid} != reference:
        raise ValueError("Partition coverage or identity/label consistency does not match its reference cohort.")


def validate_split_tree(root: Path, *, repeats=3, folds=5, inner_folds=4) -> dict[str, int]:
    if repeats < 1 or folds < 2 or inner_folds < 2:
        raise ValueError("Invalid repeat/fold counts.")
    development = index_rows(read_rows(root / "development_eyes.csv"))
    locked = index_rows(read_rows(root / "locked_test_eyes.csv"))
    check_partition(development, locked, {**development, **locked})
    checked_inner = 0
    for repeat in range(1, repeats + 1):
        seen_valid = Counter()
        for fold in range(1, folds + 1):
            directory = root / "nested_cv" / f"repeat_{repeat:02d}" / f"outer_fold_{fold:02d}"
            train = index_rows(read_rows(directory / "outer_train_eyes.csv"))
            valid = index_rows(read_rows(directory / "outer_valid_eyes.csv"))
            check_partition(train, valid, development)
            seen_valid.update(valid.keys())
            inner = read_rows(directory / "inner_folds_eyes.csv")
            if any("inner_fold" not in row or "split" not in row for row in inner):
                raise ValueError("Inner assignment columns are missing.")
            if {row["inner_fold"] for row in inner} != {str(i) for i in range(1, inner_folds + 1)}:
                raise ValueError("Unexpected inner fold inventory.")
            if {row["split"] for row in inner} != {"inner_train", "inner_valid"}:
                raise ValueError("Unexpected inner split labels.")
            inner_seen = Counter()
            for inner_fold in range(1, inner_folds + 1):
                assignments = [row for row in inner if row["inner_fold"] == str(inner_fold)]
                inner_train = index_rows([row for row in assignments if row["split"] == "inner_train"])
                inner_valid = index_rows([row for row in assignments if row["split"] == "inner_valid"])
                check_partition(inner_train, inner_valid, train)
                inner_seen.update(inner_valid.keys())
                checked_inner += 1
            if dict(inner_seen) != {eye_id: 1 for eye_id in train}:
                raise ValueError("Inner validation coverage is not exactly once per outer-training eye.")
        if dict(seen_valid) != {eye_id: 1 for eye_id in development}:
            raise ValueError("Outer validation coverage is not exactly once per development eye and repeat.")
    return {
        "development_eyes": len(development),
        "development_patients": len({v[0] for v in development.values()}),
        "locked_eyes": len(locked),
        "locked_patients": len({v[0] for v in locked.values()}),
        "outer_partitions_checked": repeats * folds,
        "inner_partitions_checked": checked_inner,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit patient-level split isolation and nested-CV coverage without loading images.")
    parser.add_argument("--splits-dir", type=Path, default=Path("experiment_setup/splits"))
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--inner-folds", type=int, default=4)
    args = parser.parse_args()
    try:
        summary = validate_split_tree(args.splits_dir, repeats=args.repeats, folds=args.folds, inner_folds=args.inner_folds)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    print(json.dumps({"status": "passed", **summary}, indent=2))
    return 0
