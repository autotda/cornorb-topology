import importlib
import unittest

from cornorb_topology.cli import WORKFLOWS, module_name


class WorkflowImportTests(unittest.TestCase):
    def test_all_workflow_modules_import(self):
        for command in WORKFLOWS:
            with self.subTest(command=command):
                workflow = importlib.import_module(module_name(command))
                self.assertTrue(callable(getattr(workflow, "main", None)))


if __name__ == "__main__":
    unittest.main()
