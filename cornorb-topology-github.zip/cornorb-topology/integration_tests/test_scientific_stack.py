from pathlib import Path
import tempfile
import unittest

import numpy as np
import pandas as pd
from PIL import Image
import torch

from gtda.homology import CubicalPersistence
from orbscan_experiment.dataset import DEFAULT_NUMERIC_CLINICAL_COLUMNS, OrbscanMultiviewDataset
from orbscan_experiment.models import DeepMultiviewFusionNet
from orbscan_experiment.tda import CubicalTDAConfig, prepare_orbscan_filtration
from orbscan_experiment.tda_baseline import compute_prediction_metrics


class ScientificStackTests(unittest.TestCase):
    def test_dataset_tda_and_model_contracts(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            paths = {}
            y, x = np.mgrid[:72, :72]
            base = np.clip(255 - 4 * np.sqrt((x - 40) ** 2 + (y - 31) ** 2), 0, 255).astype(np.uint8)
            for index, view in enumerate(("anterior", "posterior", "axial", "pachymetry")):
                rgb = np.stack((np.roll(base, index, axis=0), base, np.roll(base, index, axis=1)), axis=-1)
                path = root / f"synthetic_{view}.png"
                Image.fromarray(rgb).save(path)
                paths[f"image_{view}_path"] = str(path)

            row = {
                "patient_eye_id": "synthetic_OD",
                "patient_code": "synthetic",
                "eye": "OD",
                "label": 1,
                "gender": "f",
                **{column: float(index + 1) for index, column in enumerate(DEFAULT_NUMERIC_CLINICAL_COLUMNS)},
                **paths,
            }
            split = root / "split.csv"
            pd.DataFrame([row]).to_csv(split, index=False)
            tda_features = pd.DataFrame([{"patient_eye_id": "synthetic_OD", "axial_summary_h0_count": 2.0}])
            dataset = OrbscanMultiviewDataset(
                split,
                image_size=64,
                include_tda=True,
                tda_feature_frame=tda_features,
                tda_feature_columns=("axial_summary_h0_count",),
            )
            item = dataset[0]
            self.assertEqual(tuple(item["images"].shape), (4, 3, 64, 64))
            self.assertEqual(tuple(item["clinical"].shape), (12,))
            self.assertEqual(tuple(item["tda"].shape), (1,))
            self.assertTrue(torch.isfinite(item["images"]).all())

            config = CubicalTDAConfig(image_size=32, crop_ratio=0.84, mask_radius_ratio=0.48, debug_samples=0)
            fields = prepare_orbscan_filtration(paths["image_axial_path"], view="axial", eye="OD", config=config)
            filtration = fields["filtration"]
            self.assertEqual(filtration.shape, (32, 32))
            self.assertTrue(np.isfinite(filtration).all())
            diagram = CubicalPersistence(homology_dimensions=(0, 1), reduced_homology=True).fit_transform(filtration[None])
            self.assertEqual(diagram.shape[0], 1)
            self.assertTrue(np.isfinite(diagram[:, :, :2]).all())

            model = DeepMultiviewFusionNet(
                clinical_dim=12,
                tda_dim=1,
                num_views=4,
                pretrained_backbone=False,
                token_dim=64,
                num_heads=4,
                num_layers=1,
                dropout=0.0,
                freeze_backbone_epochs=0,
            ).eval()
            with torch.inference_mode():
                logits = model(item["images"].unsqueeze(0), item["clinical"].unsqueeze(0), item["tda"].unsqueeze(0))
            self.assertEqual(tuple(logits.shape), (1,))
            self.assertTrue(torch.isfinite(logits).all())

    def test_metric_contract(self):
        metrics = compute_prediction_metrics(
            labels=pd.Series([0, 0, 1, 1], dtype="int64"),
            probabilities=pd.Series([0.05, 0.30, 0.70, 0.95], dtype="float64"),
        )
        for name in ("auroc", "auprc", "balanced_accuracy", "mcc", "brier_score", "ece_10"):
            self.assertIn(name, metrics)
            self.assertTrue(np.isfinite(metrics[name]))


if __name__ == "__main__":
    unittest.main()
