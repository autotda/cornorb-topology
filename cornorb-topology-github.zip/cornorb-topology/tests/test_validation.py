import csv
from pathlib import Path
import tempfile
import unittest

from cornorb_topology.validation import check_partition, index_rows, validate_split_tree


def write_rows(path, rows, *, inner=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = ["patient_eye_id", "patient_code", "label"]
    if inner:
        columns += ["inner_fold", "split"]
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def synthetic_tree(root):
    development = [{"patient_eye_id": f"synthetic_{i}_{eye}", "patient_code": f"synthetic_{i}", "label": str(i % 2)} for i in range(8) for eye in ("OD", "OS")]
    locked = [{"patient_eye_id": "synthetic_holdout_OD", "patient_code": "synthetic_holdout", "label": "0"}]
    write_rows(root / "development_eyes.csv", development)
    write_rows(root / "locked_test_eyes.csv", locked)
    for outer in (1, 2):
        selected = {f"synthetic_{i}" for i in range((outer - 1) * 4, outer * 4)}
        valid = [r for r in development if r["patient_code"] in selected]
        train = [r for r in development if r["patient_code"] not in selected]
        directory = root / "nested_cv" / "repeat_01" / f"outer_fold_{outer:02d}"
        write_rows(directory / "outer_train_eyes.csv", train)
        write_rows(directory / "outer_valid_eyes.csv", valid)
        patients = sorted({r["patient_code"] for r in train})
        assignments = []
        for inner in (1, 2):
            inner_valid = set(patients[(inner - 1) * 2:inner * 2])
            assignments.extend({**row, "inner_fold": str(inner), "split": "inner_valid" if row["patient_code"] in inner_valid else "inner_train"} for row in train)
        write_rows(directory / "inner_folds_eyes.csv", assignments, inner=True)


class ValidationTests(unittest.TestCase):
    def test_fellow_eye_leakage_rejected(self):
        with self.assertRaisesRegex(ValueError, "Patient leakage"):
            check_partition({"a_OD": ("a", "0")}, {"a_OS": ("a", "0")}, {"a_OD": ("a", "0"), "a_OS": ("a", "0")})

    def test_duplicate_eye_rejected(self):
        row = {"patient_eye_id": "synthetic_OD", "patient_code": "synthetic", "label": "1"}
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            index_rows([row, row])

    def test_suspect_cannot_enter_binary_split(self):
        with self.assertRaisesRegex(ValueError, "non-binary"):
            index_rows([{"patient_eye_id": "synthetic_OD", "patient_code": "synthetic", "label": "-1"}])

    def test_changed_label_rejected(self):
        with self.assertRaisesRegex(ValueError, "consistency"):
            check_partition({"a": ("a", "1")}, {"b": ("b", "0")}, {"a": ("a", "0"), "b": ("b", "0")})

    def test_valid_nested_tree(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            synthetic_tree(root)
            result = validate_split_tree(root, repeats=1, folds=2, inner_folds=2)
            self.assertEqual(result["development_eyes"], 16)
            self.assertEqual(result["inner_partitions_checked"], 4)

    def test_locked_patient_leakage_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            synthetic_tree(root)
            write_rows(root / "locked_test_eyes.csv", [{"patient_eye_id": "other_OD", "patient_code": "synthetic_0", "label": "0"}])
            with self.assertRaisesRegex(ValueError, "Patient leakage"):
                validate_split_tree(root, repeats=1, folds=2, inner_folds=2)

    def test_inner_outer_leakage_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            synthetic_tree(root)
            path = root / "nested_cv/repeat_01/outer_fold_01/inner_folds_eyes.csv"
            with path.open(encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            rows[0]["patient_eye_id"] = "synthetic_0_OD"
            rows[0]["patient_code"] = "synthetic_0"
            write_rows(path, rows, inner=True)
            with self.assertRaises(ValueError):
                validate_split_tree(root, repeats=1, folds=2, inner_folds=2)


if __name__ == "__main__":
    unittest.main()
