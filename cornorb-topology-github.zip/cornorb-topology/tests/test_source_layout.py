import ast
from pathlib import Path, PureWindowsPath
import re
import unittest

from cornorb_topology.cli import config_arguments, load_config


ROOT = Path(__file__).resolve().parents[1]


class SourceLayoutTests(unittest.TestCase):
    def test_all_sources_compile(self):
        for path in (ROOT / "src").rglob("*.py"):
            with self.subTest(file=path.name):
                ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def test_no_personal_absolute_windows_paths(self):
        for path in (ROOT / "src").rglob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    self.assertFalse(PureWindowsPath(node.value).is_absolute(), f"Absolute Windows path in {path.name}")

    def test_examples_have_supported_commands_and_arguments(self):
        for path in (ROOT / "configs").glob("*.example.json"):
            with self.subTest(file=path.name):
                payload = load_config(path)
                self.assertIsInstance(config_arguments(payload["arguments"]), list)

    def test_no_data_or_checkpoints_in_source_tree(self):
        forbidden = {".csv", ".xlsx", ".pt", ".pth", ".ckpt", ".npy", ".npz", ".pdgm", ".zip"}
        for path in (ROOT / "src").rglob("*"):
            if path.is_file():
                self.assertNotIn(path.suffix.lower(), forbidden, f"Private/generated artifact in release: {path.name}")

    def test_license_and_github_description(self):
        self.assertTrue((ROOT / "LICENSE").read_text(encoding="utf-8").startswith("MIT License\n"))
        self.assertIn('license = "MIT"', (ROOT / "pyproject.toml").read_text(encoding="utf-8"))
        self.assertIn("license: MIT", (ROOT / "CITATION.cff").read_text(encoding="utf-8"))
        metadata = (ROOT / "docs/GITHUB_METADATA.md").read_text(encoding="utf-8")
        match = re.search(r"^> (.+)$", metadata, flags=re.MULTILINE)
        self.assertIsNotNone(match)
        self.assertEqual(len(match.group(1)), 348)
        self.assertLessEqual(len(match.group(1)), 350)


if __name__ == "__main__":
    unittest.main()
