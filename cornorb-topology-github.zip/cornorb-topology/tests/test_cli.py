from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from cornorb_topology.cli import config_arguments, load_config, main, module_name, WORKFLOWS


class CLITests(unittest.TestCase):
    def test_config_scalars_lists_and_flags(self):
        self.assertEqual(
            config_arguments({"image_size": 192, "views": ["axial", "posterior"], "resume": True, "no-amp": False, "unused": None}),
            ["--image-size", "192", "--views", "axial", "posterior", "--resume"],
        )

    def test_nested_config_value_rejected(self):
        with self.assertRaises(ValueError):
            config_arguments({"views": {"axial": True}})

    def test_prefixed_key_rejected(self):
        with self.assertRaises(ValueError):
            config_arguments({"--epochs": 2})

    def test_help_is_dependency_free(self):
        with patch("cornorb_topology.cli.importlib.import_module") as importer, redirect_stdout(io.StringIO()) as output:
            self.assertEqual(main(["--help"]), 0)
        importer.assert_not_called()
        self.assertIn("stress-cv", output.getvalue())

    def test_dry_run_does_not_import_or_train(self):
        with patch("cornorb_topology.cli.importlib.import_module") as importer, redirect_stdout(io.StringIO()) as output:
            main(["train", "--dry-run", "--device", "cpu", "--epochs", "2"])
        importer.assert_not_called()
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["arguments"], ["--device", "cpu", "--epochs", "2"])

    def test_config_override_order(self):
        with tempfile.TemporaryDirectory() as temporary:
            preset = Path(temporary) / "preset.json"
            preset.write_text(json.dumps({"command": "train", "arguments": {"epochs": 10}}))
            with redirect_stdout(io.StringIO()) as output:
                main(["--config", str(preset), "--dry-run", "--epochs", "2"])
            self.assertEqual(json.loads(output.getvalue())["arguments"], ["--epochs", "10", "--epochs", "2"])

    def test_wrong_preset_command_fails(self):
        with tempfile.TemporaryDirectory() as temporary:
            preset = Path(temporary) / "preset.json"
            preset.write_text(json.dumps({"command": "tda-cv", "arguments": {}}))
            with self.assertRaises(SystemExit) as error:
                main(["train", "--config", str(preset)])
            self.assertEqual(error.exception.code, 2)

    def test_invalid_config_shape(self):
        with tempfile.TemporaryDirectory() as temporary:
            preset = Path(temporary) / "preset.json"
            preset.write_text("[]")
            with self.assertRaises(ValueError):
                load_config(preset)

    def test_argv_restored_on_workflow_failure(self):
        before = sys.argv
        def fail():
            self.assertEqual(sys.argv[1:], ["--epochs", "1"])
            raise RuntimeError("synthetic failure")
        with patch("cornorb_topology.cli.importlib.import_module", return_value=SimpleNamespace(main=fail)):
            with self.assertRaises(RuntimeError):
                main(["train", "--epochs", "1"])
        self.assertIs(sys.argv, before)

    def test_all_registered_targets_exist(self):
        source = Path(__file__).resolve().parents[1] / "src"
        for name in WORKFLOWS:
            with self.subTest(command=name):
                self.assertTrue((source / (module_name(name).replace(".", "/") + ".py")).is_file())


if __name__ == "__main__":
    unittest.main()
